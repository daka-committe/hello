# `vivo_rms_active_request_reason` 使用说明

> 基于 `D:\31702\Vivo-System-App` 内 GameWatch / 智慧引擎 反编译源码整理。  
> 该键描述 **当前全局生效** 的 RMS 刷新率请求的 **reason 字符串**，适合用 SetEdit 或 adb **观察**，不建议当作可随意配置的开关。

---

## 1. 概述

| 项目 | 说明 |
|------|------|
| **键名** | `vivo_rms_active_request_reason` |
| **表** | `Settings.Secure`（`settings get secure` / SetEdit 的 Secure 分区） |
| **类型** | `String` |
| **含义** | 系统 RMS 在刷新率仲裁后，把 **当前胜出** 那条 `acquire` 请求的 **reason**（第 2 个参数字符串）写入此键 |
| **谁写入** | **系统 RMS / framework**（`ServiceManager.checkService("rms")` 一侧，**不在本仓库**） |
| **谁读取（本仓库）** | GameWatch：`C0887h0`（异常监控上下文）、`C0908y`（游戏状态 JSON 字段 `active_request`） |
| **GameWatch 是否写入** | **否**。GameWatch 只通过 `RefreshRateRequester.acquire(scene, reason, …)` 向 RMS 提交请求；Secure 键由 RMS 更新 |
| **为何变化很快** | 存的是 **实时胜出方**，不是历史。切应用、弹窗、分屏、游戏 SDK、温控、录屏、窗口 min/max fps 等都会 `acquire`/`release`，仲裁一变整串就换 |

**与 `RefreshRateRequester.setsCurReqReason` 的区别：** GameWatch 进程内还有 `sCurReqReason`（默认 `unknown`），在 **本进程** `acquire` 时更新，**不等于** Secure 里系统侧的全局 active reason。

---

## 2. 如何读取

### adb（推荐）

```bash
adb shell settings get secure vivo_rms_active_request_reason
```

空值或 `null` 表示当前无有效字符串（或未写入）。

### 连续观察（看变化）

```bash
adb shell "while true; do settings get secure vivo_rms_active_request_reason; sleep 0.5; done"
```

### SetEdit

在 **Secure** 分区搜索 `vivo_rms_active_request_reason`，只读当前值即可（见第 3 节写入风险）。

---

## 3. 如何写入

| 方式 | 本仓库行为 | 建议 |
|------|------------|------|
| GameWatch / 智慧引擎 | **无** `putString` 针对此键 | — |
| `adb shell settings put secure …` | 可强制写入，但 **RMS 会覆盖** | 仅临时实验 |
| SetEdit 修改 | 同上，下一帧仲裁可能立刻被盖掉 | **一般只读** |

**风险简述：**

- 写入 **不会** 等价于真正发起刷新率请求（真正逻辑在 RMS `acquire`）。
- 错误字符串 **不能** 让 GameWatch 按你填的 reason 去 `acquire`。
- 可能误导统计（`C0908y` 上报的 `active_request`）或与真实刷新率不一致。
- 需要 root / `WRITE_SECURE_SETTINGS` 才能改 Secure。

**结论：日常调试请只读；要影响刷新率应改游戏设置、温控策略或对应 App 行为，而不是改这个键。**

---

## 4. 完整格式语法（带 `:` 的前缀）

**通用规则：** 第一个 `:` 之前为 **类型前缀**；之后为 **载荷**，格式因前缀而异。  
**注意：** 多数 GameWatch 前缀 **不会** 把 FPS 写在 reason 里（FPS 在 Binder `acquire` 的数值参数里）；**例外** 是系统侧的 `windowMinFps` / `windowMaxFps`（实机可见 `|165`）。

| 前缀 | `:` 后模板（BNF） | 字段说明 | 示例 |
|------|-------------------|----------|------|
| `benchMark` | `<package>` | **仅包名**。无 `/`、无 `\|`。FPS 在 `acquire` 参数 i7，不在 reason。内部用 `pkg/sceneKey` 查表，**不**写入 reason | `benchMark:com.antutu.benchmark` |
| `gfx_game` | `99998\|<package>` | 固定字面量 **`99998`** + **`\|`** + **包名**。无 Activity。固定请求 60fps | `gfx_game:99998\|com.tencent.tmgp.sgame` |
| `gameSdk` | `<package>` | **仅包名**（GameSDK 路径，`f2301g==0`） | `gameSdk:com.miHoYo.Yuanshen` |
| `gameSdk_override` | `<package>` | 显示 FPS 被 override | `gameSdk_override:com.miHoYo.Yuanshen` |
| `gameSdk_vsyncImd` | `<package>` | 开启 vsync 立即模式 | `gameSdk_vsyncImd:com.example.game` |
| `gameSdk_override_vsyncImd` | `<package>` | override + vsyncImd | `gameSdk_override_vsyncImd:com.example.game` |
| `setting` | `<package>` | **仅包名**（非 SDK / 设置路径，`f2301g==1`） | `setting:com.example.game` |
| `setting_override` | `<package>` | 同 gameSdk_override，前缀为 setting | `setting_override:com.example.game` |
| `setting_vsyncImd` | `<package>` | 同 gameSdk_vsyncImd | `setting_vsyncImd:com.example.game` |
| `setting_override_vsyncImd` | `<package>` | 两者兼有 | `setting_override_vsyncImd:com.example.game` |
| `Thermal` | `<package>/<temperature>` | **包名** + **`/`** + **温度浮点**（`%f`）。`/` 后是温度，**不是** Activity | `Thermal:com.tencent.tmgp.sgame/41.250000` |
| `windowMinFps` | `<package>/<activity>\|<fps>` | **本仓库无构造代码**（framework/RMS）。**推断：** 包名 + **全限定 Activity** + **`\|`** + **数值**（多为 min fps/Hz 档位） | `windowMinFps:io.github.muntashirakon.setedit/io.github.muntashirakon.setedit.EditorActivity\|165` |
| `windowMaxFps` | `<package>/<activity>\|<fps>` | 全库 **无字面量**；按命名 **推断** 与 `windowMinFps` 对称，表示窗口 **最高** fps 偏好 | （推断）`windowMaxFps:com.foo/com.foo.MainActivity\|120` |

**gameSdk / setting 生成式（源码）：**

```text
String.format("%s%s%s:%s",
    (fromSdk ? "gameSdk" : "setting"),
    (override ? "_override" : ""),
    (vsyncImd ? "_vsyncImd" : ""),
    packageName);
```

来源：`GameWatch/sources/p054e0/C0406o.java`。

**分隔符速查：**

| 前缀 | 冒号后有 `/` | 冒号后有 `\|` | 第二冒号 |
|------|-------------|--------------|---------|
| benchMark | 否 | 否 | 否 |
| gfx_game | 否 | 是（`99998\|pkg`） | 否 |
| gameSdk / setting* | 否 | 否 | 否 |
| Thermal | 是（`pkg/temp`） | 否 | 否 |
| windowMinFps / MaxFps | 是（`pkg/activity`） | 是（`\|fps`） | 否 |

---

## 5. 固定无冒号 reason 列表

整段字符串就是 reason，**没有** `:`：

| reason 字面量 | 场景 | 来源 |
|---------------|------|------|
| `unknown` | 无有效请求 / GameWatch 本地默认 | `RefreshRateRequester.sCurReqReason` |
| `Carlife` | 车载 CarLife，60fps | `C0410s` |
| `screen_record` | 录屏刷新率 | `C0410s` |
| `CarlifeTouchTimeout` | CarLife 触控超时 30fps | `C0410s` |
| `game_interpolated` | 游戏插帧（MEMC） | `C0620l` |
| `VDialogEnter for SystemAnimation` | 系统对话框 **进入** 动画 | 智慧引擎 `DialogC1566d` → `C1387f.m5653a` |
| `VDialogExit for SystemAnimation` | 系统对话框 **退出** 动画 | 同上 |

**填写说明：** 这些值由对应模块在 `acquire` 时传入，**不是** 给用户手工拼进 SetEdit 的配置项。

---

## 6. gameSdk / setting 八变体详解

| 变体 | 何时出现（逻辑） | `:` 后填什么 |
|------|------------------|-------------|
| `gameSdk` | 游戏通过 **GameSDK** 上报 fps（`f2301g==0`），无 override、无 vsyncImd | **应用包名**，如 `com.tencent.tmgp.sgame` |
| `gameSdk_override` | 显示 fps 被算法 override（`z4==true`） | 同上，仅前缀不同 |
| `gameSdk_vsyncImd` | vsync 立即模式（`z5==true`） | 同上 |
| `gameSdk_override_vsyncImd` | override 与 vsyncImd 同时成立 | 同上 |
| `setting` | fps 来自 **设置/非 SDK** 路径（`f2301g==1`） | 同上 |
| `setting_override` | setting + override | 同上 |
| `setting_vsyncImd` | setting + vsyncImd | 同上 |
| `setting_override_vsyncImd` | setting + 两者兼有 | 同上 |

**包名怎么填：** 必须是 **Android 应用包名**（`applicationId`），与 `RunningAppProcessInfo.processName` 一致的那套，**不要**填 Activity 类名、不要带 `/`。

**不要填：** pid、uid、fps 数字（fps 在 RMS Binder 参数里，见第 10 节）。

---

## 7. gfx_game 的 `99998` 和 `|` 含义

**源码：** `C0405n.m2474j`：

```java
"gfx_game:99998|" + str   // str = 游戏包名
```

| 片段 | 含义 |
|------|------|
| `gfx_game` | 「游戏对战 / GameFighting」场景下的 gfx 刷新率请求 |
| `99998` | **固定魔数**（源码字面量），不是包名、不是 pid；可能为 RMS 内部子类型/通道 ID |
| `\|` | 分隔符，把魔数与包名分开 |
| `<package>` | 参与对战检测的 **游戏包名** |

**acquire 侧：** `APP_REQUEST_SCENE`，fps 固定 **60**，priority **41**，pid 为游戏进程。

**与 `windowMinFps` 的 `|` 不同：** `gfx_game` 是 `99998|包名`；`windowMinFps` 是 `包名/Activity|165`，语义和来源完全不同。

---

## 8. Thermal 的 `/` 含义

**源码：** `C0726f`：

```java
String.format("Thermal:%s/%f", packageName, temperature);
```

| 片段 | 含义 |
|------|------|
| `Thermal` | 温控降帧 / 限刷请求 |
| `:` 后第一段 | **包名**（被温控的游戏或应用） |
| `/` | 分隔 **包名** 与 **温度数值** |
| 温度 | `double`，如 `38.5`、`41.250000`（壳温/板温等，由 `ThermalFpsAdjuster` 传入） |

**易混：** 这里的 `/` **不是** `包名/Activity`。也不要写成 `Thermal:pkg|fps`。

**scene：** 配置项可能是 `FixRate` 或 `Power`（由温控配置 `f3860a` 决定），reason 字符串仍是 `Thermal:…`。

---

## 9. windowMinFps / windowMaxFps（系统侧）

**本仓库：** 无任何 `windowMinFps` / `windowMaxFps` 字符串构造；仅有常量 `PRIORITY_APP_REQUEST_FOR_WINDOW_PREFERRED = 10`（`RefreshRateRequester.java`），说明存在「窗口偏好」类请求，但格式在 **framework/RMS**。

### 实机样例拆解

```text
windowMinFps:io.github.muntashirakon.setedit/io.github.muntashirakon.setedit.EditorActivity|165
```

| 段 | 含义 |
|----|------|
| `windowMinFps` | 窗口侧 **最低** FPS / 刷新率偏好请求（名称来自系统，非 GameWatch） |
| `io.github.../EditorActivity` | **包名 / 全限定 Activity 类名**（谁在前台/谁持有该请求） |
| `\|165` | 与请求绑定的 **数值**；在 165Hz 机型上 **常对应 165**（具体以 RMS 实现为准） |

### 与 GameWatch reason 对比

| 项目 | windowMinFps | gameSdk / gfx_game |
|------|--------------|-------------------|
| 来源 | 系统 / WMS / SF | GameWatch |
| Activity | 通常 **有** | gameSdk **无**；gfx_game **无** |
| FPS 在 reason 末尾 | **常有** `\|数字` | GameWatch **一般没有** |
| 包名格式 | `pkg/Activity` | 仅 `pkg` 或 `99998\|pkg` |

**windowMaxFps：** 未在仓库出现，推断为 `pkg/Activity|maxFps`，与 Min 对称。

---

## 10. 与 `RefreshRateRequester.acquire` 参数关系

**签名（简化）：**

```text
acquire(String scene, String reason, int minFps, int maxFps, int fps, int dFps,
        int reqConfigBits, int flags, int priority, int timeoutMs, int pid, …)
```

| 参数 | 角色 |
|------|------|
| **scene**（第 1 参） | 场景名：`AppRequest`、`FixRate`、`Power`、`Animation` 等 — **不是** Secure 里那串 reason |
| **reason**（第 2 参） | 写入 RMS、并可能出现在 `vivo_rms_active_request_reason` 的字符串 |
| **fps**（第 5 参，代码里常为 i7） | 目标显示/刷新 FPS（如 60、90、120） |
| **pid**（第 11 参，代码里常为 i13） | 目标进程 pid |

### `|165` 是不是 reason 的一部分？

- **在 GameWatch 里：** **通常不是**。例如 `benchMark:pkg` 的 fps 在 **i7**；`gfx_game:99998|pkg` 里的 `|` 分隔的是 **99998 与包名**，不是 fps。
- **在实机 `windowMinFps:…|165` 里：** **`|165` 是 reason 字符串的一部分**，由 **RMS/框架** 在写入 Secure 时拼进 reason，**不是** GameWatch `acquire` 第 2 参的写法。
- 因此：看到 `|数字` 时，先根据前缀判断 — `gfx_game` → 魔数；`windowMinFps` → 多为 fps/Hz 档位。

### 各调用点对照

| 模块 | scene | reason 示例 | fps 参数 |
|------|-------|-------------|----------|
| `C0390c` | AppRequest | `benchMark:pkg` | 配置表整数 |
| `C0406o` | AppRequest | `gameSdk*:pkg` | 演算 `i19` |
| `C0405n` | AppRequest | `gfx_game:99998\|pkg` | 固定 60 |
| `C0726f` | FixRate/Power | `Thermal:pkg/temp` | 温控目标 fps |
| `C0410s` | FixRate | `screen_record` 等 | 60 / 30 等 |
| `DialogC1566d` | Animation | `VDialogEnter for SystemAnimation` | 500 |

---

## 11. 源码可枚举类型数量说明

| 统计维度 | 数量 | 说明 |
|----------|------|------|
| **本仓库可枚举的 reason 字面量/前缀** | **18** | 见下表 |
| **折叠后的「族」** | **约 12** | gameSdk×4、setting×4 各算一族等 |
| **运行时完整字符串** | **无限** | 包名 × Activity × 温度 × fps 档位组合 |
| **系统侧额外类型** | **≥1** | 至少包含已观测的 `windowMinFps`；`windowMaxFps` 等为推断 |

**18 项清单：**

1. `unknown`  
2. `Carlife`  
3. `screen_record`  
4. `CarlifeTouchTimeout`  
5. `game_interpolated`  
6. `VDialogExit for SystemAnimation`  
7. `VDialogEnter for SystemAnimation`  
8. `benchMark:*`  
9. `gfx_game:99998|*`  
10–13. `gameSdk` / `gameSdk_override` / `gameSdk_vsyncImd` / `gameSdk_override_vsyncImd`  
14–17. `setting` / `setting_override` / `setting_vsyncImd` / `setting_override_vsyncImd`  
18. `Thermal:*/*`  

**不在 18 项内、但实机常见：** `windowMinFps:*/*|*`（及可能的 `windowMaxFps`、视频通话等 — 需 framework/RMS 或继续抓机）。

---

## 12. 调试建议

1. **只读为主：** `settings get secure vivo_rms_active_request_reason`，配合第 4 节表解析前缀与载荷。  
2. **抓变化：** 循环 get + 同时操作（进游戏、开录屏、弹系统对话框、打开 SetEdit）看何时切换。  
3. **对照 GameWatch 日志：** 过滤 `GameFpsAdjuster`、`ThermalFpsAdjuster`、`GameFighting`、`BenchMarkAdjuster`，日志里的 reason 与 Secure 值应 **同类**（时间差可能有仲裁延迟）。  
4. **区分 scene 与 reason：** logcat 里 `AppRequest` 是场景，真正字符串是 `gameSdk:…` 这类。  
5. **不要手工 put 长期值：** 下一帧可能被 RMS 覆盖，且不能替代真实 `acquire`。  
6. **pkg 填法：** 有 `:` 的 GameWatch 类型 — 只填 **包名**；`windowMinFps` — **包名/Activity**；`Thermal` — **包名/温度**；`gfx_game` — **不要** 改成 `gfx_game:包名`（缺少 `99998|`）。  
7. **继续深挖系统侧：** 在设备 `framework.jar` / `services.jar` / `com.vivo.abe` 中搜 `vivo_rms_active_request_reason` 与 `windowMinFps`（本仓库不含 RMS 写入实现）。

---

## 附录：相关源码路径

| 文件 | 作用 |
|------|------|
| `GameWatch/.../RefreshRateRequester.java` | `acquire` / Binder transact 23/31/36 |
| `GameWatch/.../C0390c.java` | `benchMark:` |
| `GameWatch/.../C0405n.java` | `gfx_game:99998\|` |
| `GameWatch/.../C0406o.java` | `gameSdk` / `setting` 八变体 |
| `GameWatch/.../C0726f.java` | `Thermal:` |
| `GameWatch/.../C0410s.java` | Carlife / screen_record |
| `GameWatch/.../C0887h0.java` / `C0908y.java` | 读取 Secure |
| `智慧引擎/.../DialogC1566d.java` | VDialog Enter/Exit |
| `GameWatch/.../AbstractApplicationC0350b.java` | `m2160p()` → `Settings.Secure.getString` |

---

*文档版本：与仓库 GameWatch / 智慧引擎 快照一致；系统 RMS 行为以实机为准。*
