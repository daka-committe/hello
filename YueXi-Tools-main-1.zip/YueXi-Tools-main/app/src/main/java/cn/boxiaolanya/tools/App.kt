/**
 * Application 全局入口与进程级初始化。
 *
 * 职责：
 * 1. [CrashHandler] 注册未捕获异常日志
 * 2. [NotificationHelper.createNotificationChannels] 创建编译/RMS 等渠道
 * 3. 读取 DataStore [KEEP_ALIVE_ENABLED]（默认 true）决定是否 [KeepAliveService.start]
 * 4. Android P+ [HiddenApiBypass] 豁免 hidden API（ServiceManager、VivoPerf 等反射需要）
 *
 * [instance] 供无 Context 注入的模块弱引用全局 Application（慎用，优先传 Context）。
 */
package cn.boxiaolanya.tools

import android.app.Application
import android.os.Build
import androidx.datastore.preferences.core.booleanPreferencesKey
import cn.boxiaolanya.tools.service.KeepAliveService
import cn.boxiaolanya.tools.utils.CrashHandler
import cn.boxiaolanya.tools.utils.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.lsposed.hiddenapibypass.HiddenApiBypass
import cn.boxiaolanya.tools.ui.settings.dataStore

class App : Application() {

    companion object {
        /** 进程内单例，onCreate 时赋值 */
        lateinit var instance: App
            private set

        /** DataStore 键：是否在启动时自动拉起 KeepAliveService */
        val KEEP_ALIVE_ENABLED = booleanPreferencesKey("keep_alive_enabled")
    }

    /** 应用级协程域，SupervisorJob 防止子任务失败拖垮整个 scope */
    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        instance = this

        CrashHandler.init(this)
        NotificationHelper.createNotificationChannels(this)
        startKeepAliveServiceIfEnabled()

        // 空字符串 exemptions = 放宽所有 hidden API（与 LSPosed HiddenApiBypass 行为一致）
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            HiddenApiBypass.addHiddenApiExemptions("")
        }
    }

    /** 异步读 DataStore，避免 onCreate 主线程阻塞 */
    private fun startKeepAliveServiceIfEnabled() {
        applicationScope.launch {
            try {
                val preferences = dataStore.data.first()
                val enabled = preferences[KEEP_ALIVE_ENABLED] ?: true

                if (enabled) {
                    KeepAliveService.start(this@App)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
