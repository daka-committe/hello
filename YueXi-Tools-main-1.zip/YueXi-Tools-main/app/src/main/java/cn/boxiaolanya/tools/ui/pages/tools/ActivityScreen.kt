/**
 * 实验功能：通过 dumpsys 启动指定 Activity 组件。
 *
 * 用户输入包名 + Activity 类名，拼接为 component 后调用 [ActivityCommands.startActivity]。
 * 需 Shizuku；部分系统组件可能因权限或 exported 限制启动失败。
 *
 * @param shizukuGranted 未授权时禁用执行并提示
 * @param navController 返回栈
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.shell.ActivityCommands
import cn.boxiaolanya.tools.utils.ShizukuExec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ActivityScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val scope = rememberCoroutineScope()

    var pkg by remember { mutableStateOf("") }
    var activity by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    fun runCmd(cmd: String, desc: String) {
        scope.launch {
            isLoading = true
            output = withContext(Dispatchers.IO) {
                try {
                    val r = ShizukuExec.runShellCommand(cmd)
                    if (r.third) r.first.ifEmpty { "执行成功 (无输出)" } else "错误: ${r.second}"
                } catch (e: Exception) {
                    "异常: ${e.message}"
                }
            }
            isLoading = false
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
                )
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "Activity 管理",
                        description = "返回高级调试",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (!shizukuGranted) {
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Apps,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以启用 Activity 管理",
                            isError = true
                        ) {}
                    }
                }
            } else {
                SettingSplicedColumnGroup(title = "管理操作") {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = pkg,
                                onValueChange = { pkg = it },
                                label = { Text("应用包名") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                placeholder = { Text("com.android.updater") }
                            )
                            OutlinedTextField(
                                value = activity,
                                onValueChange = { activity = it },
                                label = { Text("Activity 完整路径") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                placeholder = { Text("com.miui.permcenter.root.RootAcquiredActivity") }
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        runCmd(
                                            ActivityCommands.PACKAGE_FILTER_BASE + " | grep 'filter' -B 1 | grep '$pkg/' | sed 's/.* //'",
                                            "获取列表"
                                        )
                                    },
                                    enabled = pkg.isNotBlank(),
                                    modifier = Modifier.weight(1f)
                                ) { Text("获取列表") }
                                Button(
                                    onClick = {
                                        runCmd(
                                            ActivityCommands.startActivity(
                                                if (activity.contains("/")) activity else "$pkg/$activity"
                                            ) + " 2>&1",
                                            "启动 Activity"
                                        )
                                    },
                                    enabled = pkg.isNotBlank() && activity.isNotBlank(),
                                    modifier = Modifier.weight(1f)
                                ) { Text("启动 Activity") }
                            }
                            OutlinedButton(
                                onClick = {
                                    runCmd(
                                        ActivityCommands.dumpsysActivity(
                                            if (activity.contains("/")) activity else "$pkg/$activity"
                                        ),
                                        "查询详情"
                                    )
                                },
                                enabled = pkg.isNotBlank() && activity.isNotBlank(),
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("查询详情") }
                        }
                    }
                }

                if (output.isNotBlank()) {
                    Spacer(modifier = Modifier.height(16.dp))

                    SettingSplicedColumnGroup(title = "输出结果") {
                        item {
                            Column(modifier = Modifier.padding(16.dp)) {
                                SelectionContainer {
                                    Text(
                                        text = output,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                        item {
                            BaseWidget(
                                icon = Icons.Default.Clear,
                            title = "清空输出",
                            description = "清空当前执行结果",
                                onClick = { output = "" }
                            ) {}
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }

    if (isLoading) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceBright
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("正在执行操作...", style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
    }
}
