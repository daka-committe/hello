/**
 * 实验功能： [ActivityCommands.killPackage] 结束指定包进程。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.shell.ActivityCommands
import cn.boxiaolanya.tools.utils.ShizukuExec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun KillScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val scope = rememberCoroutineScope()

    var pkg by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    fun runCmd(cmd: String) {
        scope.launch {
            isLoading = true
            output = withContext(Dispatchers.IO) {
                try {
                    val r = ShizukuExec.runShellCommand(cmd)
                    if (r.third) r.first.ifEmpty { "执行成功 (无输出)" } else "错误: ${r.second}"
                } catch (e: Exception) {
                    "异常: ${e.message}"
                }
            }
            isLoading = false
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
                )
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "进程管理",
                        description = "返回高级调试",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (!shizukuGranted) {
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Delete,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以启用进程管理",
                            isError = true
                        ) {}
                    }
                }
            } else {
                SettingSplicedColumnGroup(title = "终止操作") {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "全局终止将结束所有后台进程",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedTextField(
                                value = pkg,
                                onValueChange = { pkg = it },
                                label = { Text("目标包名 (单个终止时必填)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                placeholder = { Text("com.example.app") }
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { runCmd(ActivityCommands.KILL_ALL) },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.errorContainer,
                                        contentColor = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                ) { Text("全局终止") }
                                Button(
                                    onClick = { runCmd(ActivityCommands.killPackage(pkg)) },
                                    enabled = pkg.isNotBlank(),
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                                ) { Text("单个终止") }
                            }
                        }
                    }
                }

                if (output.isNotBlank()) {
                    Spacer(modifier = Modifier.height(16.dp))

                    SettingSplicedColumnGroup(title = "输出结果") {
                        item {
                            Column(modifier = Modifier.padding(16.dp)) {
                                SelectionContainer {
                                    Text(
                                        text = output,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                        item {
                            BaseWidget(
                                icon = Icons.Default.Clear,
                            title = "清空输出",
                            description = "清空当前执行结果",
                                onClick = { output = "" }
                            ) {}
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }

    if (isLoading) {
        Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
                ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceBright
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("正在执行操作...", style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
    }
}
