/**
 * 实验功能：按包名+类名启停 Service，使用 [ServiceControlCommands]。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.ShizukuExec
import cn.boxiaolanya.tools.utils.shell.ServiceControlCommands
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ServiceControlScreen(shizukuGranted: Boolean, navController: NavController) {
    val scope = rememberCoroutineScope()
    var output by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    fun runShell(cmd: String) { scope.launch { isLoading = true; output = withContext(Dispatchers.IO) { try { val r = ShizukuExec.runShellCommand(cmd); if (r.third) r.first.ifEmpty { "ok" } else "fail" } catch (e: Exception) { "fail" } }; isLoading = false } }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())) {
            Spacer(Modifier.height(16.dp))
            SettingSplicedColumnGroup { item { BaseWidget(icon = Icons.AutoMirrored.Filled.ArrowBack, title = "服务控制", description = "返回高级调试", onClick = { navController.navigateUp() }) {} } }
            Spacer(Modifier.height(8.dp))
            if (!shizukuGranted) { SettingSplicedColumnGroup(title = "授权中心") { item { BaseWidget(icon = Icons.Default.Speed, title = "Shizuku 未连接", isError = true) {} } } }
            else {
                var pkg by remember { mutableStateOf("") }
                var svc by remember { mutableStateOf("") }
                SettingSplicedColumnGroup(title = "服务启停") {
                    item {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = pkg, onValueChange = { pkg = it }, label = { Text("应用包名") }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("com.example.app") })
                            OutlinedTextField(value = svc, onValueChange = { svc = it }, label = { Text("服务完整类名") }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text(".MyService") })
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { runShell(ServiceControlCommands.start("$pkg/$svc")) }, modifier = Modifier.weight(1f), enabled = pkg.isNotBlank() && svc.isNotBlank()) { Text("启动服务") }
                                OutlinedButton(onClick = { runShell(ServiceControlCommands.stop("$pkg/$svc")) }, modifier = Modifier.weight(1f), enabled = pkg.isNotBlank() && svc.isNotBlank()) { Text("停止服务") }
                            }
                        }
                    }
                }
            }
            if (output.isNotBlank()) { Spacer(Modifier.height(16.dp)); SettingSplicedColumnGroup(title = "当前状态") { item { Column(Modifier.padding(16.dp)) { SelectionContainer { Text(output, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }; item { BaseWidget(icon = Icons.Default.Clear, title = "清空", onClick = { output = "" }) {} } } }
            Spacer(Modifier.height(WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }
    if (isLoading) { Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceBright), elevation = CardDefaults.cardElevation(4.dp)) {                     Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) { CircularProgressIndicator(Modifier.size(48.dp)); Spacer(Modifier.height(16.dp)); Text("请稍等...", style = MaterialTheme.typography.bodyLarge) } } } } }
}
