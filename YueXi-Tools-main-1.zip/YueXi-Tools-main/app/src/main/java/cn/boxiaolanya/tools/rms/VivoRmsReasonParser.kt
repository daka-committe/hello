/**
 * 解析 secure 键 `vivo_rms_active_request_reason` 的字符串格式。
 *
 * reason 大致分三类：
 * 1. **无冒号固定字面量**：unknown、Carlife、screen_record…
 * 2. **前缀:载荷**：benchMark:pkg、Thermal:pkg/temp、gameSdk_override:pkg…
 * 3. **复合载荷**：gfx_game:99998|pkg、windowMinFps:pkg/activity|fps
 *
 * 解析结果供 [cn.boxiaolanya.tools.ui.pages.tools.VivoRmsScreen] 展示摘要与警告；
 * [warnings] 列出格式可疑点，不阻断显示。
 */
package cn.boxiaolanya.tools.rms

/**
 * @param category 内部分类键，如 gameSdk_override_vsyncImd、Thermal、empty
 * @param summary 面向用户的一行中文摘要
 * @param variantFlags gameSdk/setting 变体的 override、vsyncImd 标记
 * @param isFixedLiteral 是否为文档枚举的无冒号常量
 */
data class RmsReasonParseResult(
    val raw: String,
    val category: String,
    val summary: String,
    val prefix: String? = null,
    val packageName: String? = null,
    val activity: String? = null,
    val temperature: Double? = null,
    val fpsOrMagic: String? = null,
    val variantFlags: List<String> = emptyList(),
    val isFixedLiteral: Boolean = false,
    val warnings: List<String> = emptyList(),
)

object VivoRmsReasonParser {

    /** 系统侧已知的无冒号 reason，不含包名 */
    private val FIXED_LITERALS = setOf(
        "unknown",
        "Carlife",
        "screen_record",
        "CarlifeTouchTimeout",
        "game_interpolated",
        "VDialogEnter for SystemAnimation",
        "VDialogExit for SystemAnimation",
    )

    /** gameSdk / setting 八变体前缀，匹配时需按长度降序（长前缀优先） */
    private val GAME_SDK_PREFIXES = listOf(
        "gameSdk_override_vsyncImd",
        "gameSdk_override",
        "gameSdk_vsyncImd",
        "gameSdk",
        "setting_override_vsyncImd",
        "setting_override",
        "setting_vsyncImd",
        "setting",
    )

    /**
     * 主入口：空值、固定字面量、冒号分隔、未知前缀分支。
     * @param rawInput secure 表读出的原始字符串，可为 null
     */
    fun parse(rawInput: String?): RmsReasonParseResult {
        val raw = rawInput?.trim().orEmpty()
        if (raw.isEmpty() || raw.equals("null", ignoreCase = true)) {
            return RmsReasonParseResult(
                raw = raw,
                category = "empty",
                summary = "当前无有效 reason（空值或未写入）",
                warnings = listOf(
                    "adb: content query --uri content://settings/secure --where \"name='vivo_rms_active_request_reason'\"",
                )
            )
        }

        // 无冒号：整串即 reason 本体
        if (!raw.contains(':')) {
            val known = raw in FIXED_LITERALS
            return RmsReasonParseResult(
                raw = raw,
                category = if (known) "fixed_literal" else "unknown_literal",
                summary = if (known) "固定无冒号 reason：$raw" else "未在文档枚举的无冒号字符串",
                isFixedLiteral = known,
            )
        }

        val colon = raw.indexOf(':')
        val prefix = raw.substring(0, colon)
        val payload = raw.substring(colon + 1)

        return when (prefix) {
            "benchMark" -> colonedPkgOnly(raw, prefix, payload, "跑分/基准包名请求")
            "gfx_game" -> parseGfxGame(raw, payload)
            "Thermal" -> parseThermal(raw, payload)
            "windowMinFps", "windowMaxFps" -> parseWindowFps(raw, prefix, payload)
            else -> {
                val sdk = GAME_SDK_PREFIXES.firstOrNull { prefix == it }
                if (sdk != null) {
                    parseGameSdkVariant(raw, sdk, payload)
                } else {
                    RmsReasonParseResult(
                        raw = raw,
                        category = "custom_prefix",
                        summary = "自定义前缀：$prefix",
                        prefix = prefix,
                        packageName = payload.takeIf { it.isNotBlank() },
                        warnings = listOf("可能为系统侧未收录类型，以实机 RMS 为准")
                    )
                }
            }
        }
    }

    /** benchMark:com.example.app — 冒号后应仅为包名 */
    private fun colonedPkgOnly(
        raw: String,
        prefix: String,
        payload: String,
        scene: String,
    ): RmsReasonParseResult {
        val warnings = mutableListOf<String>()
        if (payload.contains('/') || payload.contains('|')) {
            warnings += "benchMark 的冒号后应仅为包名，不应含 / 或 |"
        }
        return RmsReasonParseResult(
            raw = raw,
            category = prefix,
            summary = "$scene · 包名 $payload",
            prefix = prefix,
            packageName = payload,
            warnings = warnings,
        )
    }

    /** gfx_game:99998|package — 魔数 99998 为文档固定值 */
    private fun parseGfxGame(raw: String, payload: String): RmsReasonParseResult {
        val warnings = mutableListOf<String>()
        val parts = payload.split('|', limit = 2)
        if (parts.size != 2 || parts[0] != "99998") {
            warnings += "gfx_game 标准格式为 gfx_game:99998|<package>"
        }
        return RmsReasonParseResult(
            raw = raw,
            category = "gfx_game",
            summary = "游戏对战 gfx 请求 · 魔数 ${parts.getOrNull(0)} · 包名 ${parts.getOrNull(1) ?: payload}",
            prefix = "gfx_game",
            packageName = parts.getOrNull(1),
            fpsOrMagic = parts.getOrNull(0),
            warnings = warnings,
        )
    }

    /** Thermal:pkg/38.5 — 温度段为浮点字符串 */
    private fun parseThermal(raw: String, payload: String): RmsReasonParseResult {
        val slash = payload.lastIndexOf('/')
        val warnings = mutableListOf<String>()
        if (slash <= 0) {
            warnings += "Thermal 应为 Thermal:<package>/<temperature>"
            return RmsReasonParseResult(
                raw = raw,
                category = "Thermal",
                summary = "温控 reason 格式异常",
                prefix = "Thermal",
                warnings = warnings,
            )
        }
        val pkg = payload.substring(0, slash)
        val tempStr = payload.substring(slash + 1)
        val temp = tempStr.toDoubleOrNull()
        if (temp == null) warnings += "温度段无法解析为浮点数：$tempStr"
        return RmsReasonParseResult(
            raw = raw,
            category = "Thermal",
            summary = "温控限刷 · $pkg · ${temp ?: tempStr}℃",
            prefix = "Thermal",
            packageName = pkg,
            temperature = temp,
            warnings = warnings,
        )
    }

    /** windowMinFps:pkg/activity|120 — 窗口 FPS 偏好（Min/Max 格式推断相同） */
    private fun parseWindowFps(raw: String, prefix: String, payload: String): RmsReasonParseResult {
        val pipe = payload.lastIndexOf('|')
        val warnings = mutableListOf<String>()
        if (pipe <= 0) {
            warnings += "$prefix 推断格式为 <package>/<activity>|<fps>"
            return RmsReasonParseResult(
                raw = raw,
                category = prefix,
                summary = "窗口 FPS 偏好 · 载荷异常",
                prefix = prefix,
                warnings = warnings,
            )
        }
        val path = payload.substring(0, pipe)
        val fps = payload.substring(pipe + 1)
        val slash = path.indexOf('/')
        val pkg = if (slash > 0) path.substring(0, slash) else path
        val act = if (slash > 0) path.substring(slash + 1) else null
        val label = if (prefix == "windowMinFps") "窗口最低 FPS/Hz" else "窗口最高 FPS/Hz（推断）"
        return RmsReasonParseResult(
            raw = raw,
            category = prefix,
            summary = "$label · $pkg${act?.let { "/$it" } ?: ""} · |$fps",
            prefix = prefix,
            packageName = pkg,
            activity = act,
            fpsOrMagic = fps,
            warnings = warnings,
        )
    }

    /** gameSdk / setting 变体：冒号后仅包名，前缀体现 override 与 vsyncImd */
    private fun parseGameSdkVariant(raw: String, prefix: String, payload: String): RmsReasonParseResult {
        val flags = mutableListOf<String>()
        when {
            prefix.contains("override") -> flags += "override"
            else -> {}
        }
        when {
            prefix.contains("vsyncImd") -> flags += "vsyncImd"
            else -> {}
        }
        val family = if (prefix.startsWith("gameSdk")) "GameSDK 路径" else "设置/非 SDK 路径"
        val warnings = mutableListOf<String>()
        if (payload.contains('/') || payload.contains('|')) {
            warnings += "gameSdk/setting 变体的冒号后应仅为包名"
        }
        return RmsReasonParseResult(
            raw = raw,
            category = prefix,
            summary = "$family · $prefix · $payload",
            prefix = prefix,
            packageName = payload,
            variantFlags = flags,
            warnings = warnings,
        )
    }

    /** VivoRmsScreen「格式参考」列表的数据源 */
    fun referenceEntries(): List<Pair<String, String>> = listOf(
        "benchMark:<package>" to "仅包名，FPS 在 acquire 参数",
        "gfx_game:99998|<package>" to "固定魔数 99998 + 包名，60fps",
        "gameSdk[:_override][:_vsyncImd]:<package>" to "八变体，仅包名",
        "setting[:_override][:_vsyncImd]:<package>" to "八变体，仅包名",
        "Thermal:<package>/<temp>" to "包名/温度浮点",
        "windowMinFps:<pkg>/<activity>|<fps>" to "系统侧窗口最低偏好",
        "windowMaxFps:<pkg>/<activity>|<fps>" to "系统侧窗口最高偏好（推断）",
        "unknown / Carlife / screen_record / …" to "无冒号固定字面量",
    )
}
