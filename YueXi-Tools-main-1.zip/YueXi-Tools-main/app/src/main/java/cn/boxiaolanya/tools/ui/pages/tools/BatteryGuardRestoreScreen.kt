/**
 * 电量守护恢复：PEMR 统一配置更新 + 省电模式变更广播组合。
 *
 * 在 [BatteryGuardScreen] 基础上增加 pemr config update 等恢复步骤。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.shell.BatteryGuardCommands
import cn.boxiaolanya.tools.utils.ShizukuExec
import kotlinx.coroutines.launch

@Composable
fun BatteryGuardRestoreScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var selectedMode by remember { mutableStateOf("normal") }
    var isExecuting by remember { mutableStateOf(false) }
    var lastResult by remember { mutableStateOf<RestoreResult?>(null) }

    fun executeRestore() {
        if (!shizukuGranted) {
            scope.launch {
                snackbarHostState.showSnackbar("需授予 Shizuku 权限")
            }
            return
        }

        scope.launch {
            isExecuting = true
            val outputBuilder = StringBuilder()
            val success: Boolean

            if (selectedMode == "normal") {
                val cmds = listOf(
                    BatteryGuardCommands.REFRESH_CONFIG,
                    BatteryGuardCommands.RESTORE_PEM_SERVICE,
                    BatteryGuardCommands.IQOO_POWER_SAVE_CHANGED,
                    BatteryGuardCommands.RESTORE_POWER_SERVICE,
                    BatteryGuardCommands.PEMR_CONFIG_UPDATE,
                )
                for (cmd in cmds) {
                    val (out, ok) = ShizukuExec.runShLine(cmd)
                    outputBuilder.appendLine(out)
                    if (!ok) {
                        outputBuilder.appendLine("命令执行失败: $cmd")
                    }
                }
                success = true
            } else {
                val (out1, ok1) = ShizukuExec.runCommandWithOutput("pm", "clear", "com.iqoo.powersaving")
                outputBuilder.appendLine(out1)
                val (out2, ok2) = ShizukuExec.runCommandWithOutput("pm", "clear", "com.vivo.pem")
                outputBuilder.appendLine(out2)
                val (out3, ok3) = ShizukuExec.runCommandWithOutput("pm", "clear", "com.vivo.daemonService")
                outputBuilder.appendLine(out3)

                kotlinx.coroutines.delay(2000)

                val cmds = listOf(
                    BatteryGuardCommands.REFRESH_CONFIG,
                    BatteryGuardCommands.RESTORE_PEM_SERVICE,
                    BatteryGuardCommands.IQOO_POWER_SAVE_CHANGED,
                    BatteryGuardCommands.RESTORE_POWER_SERVICE,
                    BatteryGuardCommands.PEMR_CONFIG_UPDATE,
                )
                for (cmd in cmds) {
                    val (out, ok) = ShizukuExec.runShLine(cmd)
                    outputBuilder.appendLine(out)
                    if (!ok) {
                        outputBuilder.appendLine("命令执行失败: $cmd")
                    }
                }
                success = ok1 && ok2 && ok3
            }

            lastResult = RestoreResult(success, outputBuilder.toString())
            isExecuting = false
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
                )
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "恢复系统更新后耗电异常",
                        description = "返回电量守护",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            if (!shizukuGranted) {
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Clear,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以使用此功能",
                            isError = true
                        ) {}
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "选择恢复模式") {
                    item {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .selectable(
                                        selected = selectedMode == "normal",
                                        onClick = { selectedMode = "normal" },
                                        role = Role.RadioButton
                                    )
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedMode == "normal",
                                    onClick = null
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text("普通恢复", style = MaterialTheme.typography.bodyLarge)
                                    Text(
                                        "只发送刷新命令不清除数据",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .selectable(
                                        selected = selectedMode == "force",
                                        onClick = { selectedMode = "force" },
                                        role = Role.RadioButton
                                    )
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedMode == "force",
                                    onClick = null
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text("强制恢复", style = MaterialTheme.typography.bodyLarge)
                                    Text(
                                        "清除后重新初始化（推荐优先尝试）",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "操作") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.PlayArrow,
                            title = "执行恢复",
                            description = "执行所选模式的恢复命令",
                            onClick = { executeRestore() }
                        ) {
                            if (isExecuting) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    strokeWidth = 2.dp
                                )
                            }
                        }
                    }
                }
            }

            lastResult?.let { result ->
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "执行结果") {
                    item {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = if (result.success) "执行完成" else "执行异常",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (result.success) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = result.output,
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }

    if (isExecuting) {
        Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
                ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceBright
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(48.dp),
                            strokeWidth = 4.dp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "正在执行恢复...",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }
}

data class RestoreResult(
    val success: Boolean,
    val output: String
)
