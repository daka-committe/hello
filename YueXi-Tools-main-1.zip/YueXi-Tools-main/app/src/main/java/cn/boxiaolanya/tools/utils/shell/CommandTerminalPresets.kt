package cn.boxiaolanya.tools.utils.shell

object CommandTerminalPresets {
    val PM_LIST: String get() = ShellObf.s("term.pm_list")
    val DUMPSYS_BATTERY: String get() = ShellObf.s("term.battery")
    val GETPROP: String get() = ShellObf.s("term.getprop")
    val LOGCAT_TAIL: String get() = ShellObf.s("term.logcat_tail")
    val PS_A: String get() = ShellObf.s("term.ps_a")
    val CAT_MEMINFO: String get() = ShellObf.s("term.meminfo")
}
