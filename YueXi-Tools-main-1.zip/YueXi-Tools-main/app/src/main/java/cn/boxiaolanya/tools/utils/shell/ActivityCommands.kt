/**
 * Activity / 进程 / 服务 / 崩溃 相关 Shell 命令。
 */
package cn.boxiaolanya.tools.utils.shell

object ActivityCommands {

    val PACKAGE_FILTER_BASE: String
        get() = ShellObf.s("act.grep_filter")

    private val DUMPSYS_START_ACTIVITY get() = ShellObf.s("act.start_activity")
    private val DUMPSYS_ACTIVITY get() = ShellObf.s("act.dumpsys_activity")
    private val START_SERVICE get() = ShellObf.s("act.start_service")
    private val STOP_SERVICE get() = ShellObf.s("act.stop_service")
    private val KILL_PKG get() = ShellObf.s("act.kill_pkg")
    private val AM_CRASH get() = ShellObf.s("act.am_crash")

    val KILL_ALL: String
        get() = ShellObf.s("act.kill_all")

    fun startActivity(component: String): String = DUMPSYS_START_ACTIVITY + component

    fun dumpsysActivity(component: String): String = DUMPSYS_ACTIVITY + component

    fun killPackage(packageName: String): String = KILL_PKG + packageName

    fun crashPackage(packageName: String): String = AM_CRASH + packageName

    fun startService(component: String): String = START_SERVICE + component

    fun stopService(component: String): String = STOP_SERVICE + component

    fun startActivityViaDumpsys(component: String): String = DUMPSYS_START_ACTIVITY + component
}
