/**
 * 经 [ContentResolver] 直接读写 `content://settings/{secure,system,global}`。
 *
 * ## 为什么不用 Settings.Secure.putString？
 * 部分 vivo / iQOO ROM 对标准 Settings API 有额外校验或写入延迟；
 * 直接对 settings Provider 做 insert 有时比 putString 更容易生效（与社区 adb content 写法一致）。
 *
 * ## 权限
 * 写操作需要 [SecureSettingsAccess.WRITE_SECURE_SETTINGS]；
 * 通常由 [SettingsPermissionBootstrap] 经 Shizuku 自动 pm grant。
 *
 * ## 调用链
 * UI → [SettingsContentAccess]（协程 + 权限文案）→ 本对象（同步 CRUD）→ ContentResolver
 *
 * @see SettingsContentAccess
 * @see SecureSettingsAccess
 */
package cn.boxiaolanya.tools.utils

import android.content.ContentValues
import android.content.Context
import android.net.Uri

object SettingsResolverAccess {

    /**
     * 单次写入结果。
     * @param ok 是否未抛异常且 insert 调用完成
     * @param detail 成功时为策略名，失败时为 SecurityException 或异常消息
     */
    data class PutResult(val ok: Boolean, val detail: String)

    /** 是否已持有 WRITE_SECURE_SETTINGS（三表写入共用此权限）。 */
    fun canWrite(context: Context): Boolean =
        SecureSettingsAccess.isWriteSecureGranted(context)

    /**
     * 读取指定表中的 settings 键值。
     *
     * @param table secure / system / global 之一
     * @param key settings 项 name，如 `vivo_rms_active_request_reason`
     * @return 有效字符串；键不存在、cursor 为空、或值为字面量 `"null"` 时返回 null
     */
    fun get(context: Context, table: SettingsContentAccess.Table, key: String): String? {
        val resolver = context.contentResolver
        val uri = Uri.parse(table.uri)
        resolver.query(uri, arrayOf("value"), "name=?", arrayOf(key), null).use { cursor ->
            if (cursor == null || !cursor.moveToFirst()) return null
            val idx = cursor.getColumnIndex("value")
            if (idx < 0) return null
            val raw = cursor.getString(idx) ?: return null
            // ROM 有时把空值存成字符串 "null"
            if (raw.equals("null", ignoreCase = true)) return null
            return raw
        }
    }

    /**
     * 写入单个 settings 项（当前策略：ContentResolver.insert）。
     *
     * 注意：insert 可能在键已存在时产生重复行或触发 Provider 的 upsert 逻辑，依 ROM 实现而定；
     * VIVO-RMS 等场景通过 [putBurst] 多次 insert 提高覆盖成功率。
     */
    fun put(context: Context, table: SettingsContentAccess.Table, key: String, value: String): PutResult =
        putSetEditInsert(context, table, key, value)

    /**
     * 通过 insert(name, value) 行写入 settings Provider。
     * 捕获 SecurityException 以便上层展示「需要 adb 授权」类文案。
     */
    private fun putSetEditInsert(
        context: Context,
        table: SettingsContentAccess.Table,
        key: String,
        value: String,
    ): PutResult {
        val resolver = context.contentResolver
        val uri = Uri.parse(table.uri)
        return try {
            val row = ContentValues(2).apply {
                put("name", key)
                put("value", value)
            }
            resolver.insert(uri, row)
            PutResult(true, "ContentResolver.insert")
        } catch (e: SecurityException) {
            PutResult(false, "SecurityException: ${e.message}")
        } catch (e: Exception) {
            PutResult(false, e.message ?: "insert failed")
        }
    }

    /**
     * 连续 [times] 次写入同一键值，用于 RMS 等需要「连写覆盖」的场景。
     *
     * @param times 实际次数限制在 1..64，防止 UI 误填过大
     * @return [SettingsContentAccess.BurstResult] 汇总成功次数与最后一次 detail
     */
    fun putBurst(
        context: Context,
        table: SettingsContentAccess.Table,
        key: String,
        value: String,
        times: Int,
    ): SettingsContentAccess.BurstResult {
        val n = times.coerceIn(1, 64)
        var okCount = 0
        var lastMsg = ""
        for (i in 0 until n) {
            val r = put(context, table, key, value)
            if (r.ok) okCount++
            lastMsg = r.detail
        }
        return SettingsContentAccess.BurstResult(okCount, n, okCount == n, lastMsg)
    }
}
