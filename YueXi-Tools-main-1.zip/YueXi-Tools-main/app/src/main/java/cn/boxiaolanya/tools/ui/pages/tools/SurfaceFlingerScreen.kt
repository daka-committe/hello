/**
 * SurfaceFlinger：dumpsys 与 [SettingsOptimizerCommands.LATENCY_CLEAR] 延迟清除。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.GameCubeManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SurfaceFlingerScreen(shizukuGranted: Boolean, navController: NavController) {
    val scope = rememberCoroutineScope()
    var output by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    fun invoke(block: () -> String) { scope.launch { isLoading = true; output = withContext(Dispatchers.IO) { try { block() } catch (e: Exception) { "fail" } }; isLoading = false } }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())) {
            Spacer(Modifier.height(16.dp))
            SettingSplicedColumnGroup { item { BaseWidget(icon = Icons.AutoMirrored.Filled.ArrowBack, title = "隐私保护", description = "返回高级调试", onClick = { navController.navigateUp() }) {} } }
            Spacer(Modifier.height(8.dp))
            if (!shizukuGranted) {
                SettingSplicedColumnGroup(title = "授权中心") { item { BaseWidget(icon = Icons.Default.Speed, title = "Shizuku 未连接", isError = true) {} } }
            } else {
                val sfOk = remember { GameCubeManager.SurfaceFlinger.isAvailable }
                SettingSplicedColumnGroup(title = "SurfaceFlinger 隐私保护") {
                    item {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(if (sfOk) "SurfaceFlinger 服务已就绪" else "服务不可用", style = MaterialTheme.typography.bodySmall, color = if (sfOk) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                            Button(onClick = { invoke { GameCubeManager.SurfaceFlinger.toggle(true) } }, modifier = Modifier.fillMaxWidth()) { Text("启用保护") }
                            OutlinedButton(onClick = { invoke { GameCubeManager.SurfaceFlinger.toggle(false) } }, modifier = Modifier.fillMaxWidth()) { Text("停用保护") }
                        }
                    }
                }
            }
            if (output.isNotBlank()) {
                Spacer(Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "当前状态") {
                    item { Column(Modifier.padding(16.dp)) { SelectionContainer { Text(output, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
                    item { BaseWidget(icon = Icons.Default.Clear, title = "清空", onClick = { output = "" }) {} }
                }
            }
            Spacer(Modifier.height(WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }
    if (isLoading) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceBright), elevation = CardDefaults.cardElevation(4.dp)) {
                    Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) { CircularProgressIndicator(Modifier.size(48.dp)); Spacer(Modifier.height(16.dp)); Text("请稍等...", style = MaterialTheme.typography.bodyLarge) }
                }
            }
        }
    }
}
