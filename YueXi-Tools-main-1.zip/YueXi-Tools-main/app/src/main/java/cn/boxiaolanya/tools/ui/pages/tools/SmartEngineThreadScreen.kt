/**
 * 智慧引擎线程异常上报：拼接 EXCEPTION_THREAD 系列 extra 的广播。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.shell.ProcQueries
import cn.boxiaolanya.tools.utils.shell.SmartEngineCommands
import cn.boxiaolanya.tools.utils.ShizukuExec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SmartEngineThreadScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var packageName by remember { mutableStateOf("") }
    var isFetching by remember { mutableStateOf(false) }
    var isSubmitting by remember { mutableStateOf(false) }
    var threadList by remember { mutableStateOf<List<ThreadItem>>(emptyList()) }
    var lastResult by remember { mutableStateOf<ThreadResult?>(null) }

    fun fetchThreads() {
        if (packageName.isBlank()) {
            scope.launch { snackbarHostState.showSnackbar("请输入应用包名") }
            return
        }
        if (!shizukuGranted) {
            scope.launch { snackbarHostState.showSnackbar("需授予 Shizuku 权限") }
            return
        }

        scope.launch {
            isFetching = true
            lastResult = null
            val pkg = packageName.trim()
            val threads = getAppThreads(pkg)
            threadList = threads.map { ThreadItem(it.tid, it.name, it.pid, false) }
            isFetching = false
            if (threads.isEmpty()) {
                snackbarHostState.showSnackbar("未找到运行中的线程，请确认包名是否正确或应用是否在运行")
            }
        }
    }

    fun submitException() {
        val selected = threadList.filter { it.selected }
        if (selected.isEmpty()) {
            scope.launch { snackbarHostState.showSnackbar("请至少选择一个线程") }
            return
        }
        if (!shizukuGranted) {
            scope.launch { snackbarHostState.showSnackbar("需授予 Shizuku 权限") }
            return
        }

        scope.launch {
            isSubmitting = true
            val size = selected.size
            val pkg = packageName.trim()
            val cmd = buildString {
                append(SmartEngineCommands.EXCEPTION_THREAD_PREFIX)
                append(size)
                selected.forEachIndexed { index, item ->
                    append(SmartEngineCommands.EXCEPTION_THREAD_PID)
                    append(index)
                    append(" ")
                    append(item.tid)
                    append(SmartEngineCommands.EXCEPTION_THREAD_NAME)
                    append(index)
                    append(" ")
                    append(pkg)
                }
            }
            val (output, success) = ShizukuExec.runShLine(cmd)
            lastResult = ThreadResult(selected.size, success)
            isSubmitting = false
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "线程异常上报",
                        description = "返回智慧引擎",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            if (!shizukuGranted) {
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Clear,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以使用此功能",
                            isError = true
                        ) {}
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "输入包名") {
                    item {
                        Column(modifier = Modifier.padding(16.dp)) {
                            OutlinedTextField(
                                value = packageName,
                                onValueChange = { packageName = it },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("输入应用包名，如 com.example.app") },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                keyboardActions = KeyboardActions(
                                    onSend = { if (!isFetching) fetchThreads() }
                                ),
                                trailingIcon = {
                                    IconButton(
                                        onClick = { fetchThreads() },
                                        enabled = !isFetching && packageName.isNotBlank()
                                    ) {
                                        if (isFetching) {
                                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                        } else {
                                            Icon(Icons.Default.Search, "获取线程")
                                        }
                                    }
                                }
                            )
                        }
                    }
                }

                if (threadList.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))

                    SettingSplicedColumnGroup(title = "线程列表 (已选 ${threadList.count { it.selected }})") {
                        item {
                            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                                threadList.forEachIndexed { index, item ->
                                    ThreadRow(
                                        item = item,
                                        onToggle = {
                                            threadList = threadList.toMutableList().apply {
                                                set(index, get(index).copy(selected = !get(index).selected))
                                            }
                                        }
                                    )
                                    if (index < threadList.lastIndex) {
                                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    SettingSplicedColumnGroup {
                        item {
                            Button(
                                onClick = { submitException() },
                                enabled = !isSubmitting && threadList.any { it.selected },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                                    .height(48.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                if (isSubmitting) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                } else {
                                    Icon(Icons.Default.Warning, null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("上报异常线程")
                                }
                            }
                        }
                    }
                }
            }

            lastResult?.let { result ->
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "执行结果") {
                    item {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = if (result.success) "成功" else "错误",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (result.success) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }
}

@Composable
private fun ThreadRow(item: ThreadItem, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .toggleable(
                value = item.selected,
                onValueChange = { onToggle() }
            )
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Checkbox(
            checked = item.selected,
            onCheckedChange = null
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.name,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 3
            )
            Text(
                text = "TID: ${item.tid}  |  PID: ${item.pid}",
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

data class ThreadItem(
    val tid: Int,
    val name: String,
    val pid: Int,
    val selected: Boolean
)

data class ThreadResult(
    val count: Int,
    val success: Boolean
)

data class RawThreadInfo(
    val tid: Int,
    val name: String,
    val pid: Int
)

suspend fun getAppThreads(packageName: String): List<RawThreadInfo> = withContext(Dispatchers.IO) {
    val pidInt = ProcQueries.pidOfPackage(packageName) ?: return@withContext emptyList()
    val pid = pidInt.toString()

    val (taskOut, taskSuccess) = ShizukuExec.runCommandWithOutput("ls", "/proc/$pid/task")
    if (!taskSuccess) return@withContext emptyList()

    val tids = taskOut.split("\n").map { it.trim() }.filter { it.isNotBlank() }

    tids.mapNotNull { tidStr ->
        val tid = tidStr.toIntOrNull() ?: return@mapNotNull null
        val (nameOut, nameSuccess) = ShizukuExec.runCommandWithOutput("cat", "/proc/$pid/task/$tidStr/comm")
        if (nameSuccess) {
            RawThreadInfo(tid, nameOut.trim(), pid.toIntOrNull() ?: 0)
        } else null
    }
}
