/**
 * fuelsummary_uc.xml 解析与序列化：仅暴露可编辑的数值槽位，结构标签与 name 属性只读。
 */
package cn.boxiaolanya.tools.fuel

import android.content.Context
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.InputStream
import java.io.StringReader

const val FUEL_SUMMARY_ASSET = "fuelsummary_uc.xml"

sealed class FuelEditableField {
    abstract val sectionKey: String
    abstract val displayLabel: String

    data class LoneInteger(
        override val sectionKey: String,
        override val displayLabel: String,
        var valueText: String,
    ) : FuelEditableField()

    data class TokenRow(
        override val sectionKey: String,
        override val displayLabel: String,
        val isHexRow: Boolean,
        val tokens: MutableList<String>,
    ) : FuelEditableField()
}

data class FuelSummaryDraft(
    var configVersionText: String,
    val fields: MutableList<FuelEditableField>,
)

object FuelSummaryXmlCodec {

    fun loadFromAssets(context: Context): FuelSummaryDraft {
        context.assets.open(FUEL_SUMMARY_ASSET).use { stream ->
            return parse(stream)
        }
    }

    fun parse(input: InputStream): FuelSummaryDraft {
        val parser = XmlPullParserFactory.newInstance().newPullParser().apply {
            setInput(input, "utf-8")
        }
        return readDocument(parser)
    }

    fun parse(text: String): FuelSummaryDraft {
        val parser = XmlPullParserFactory.newInstance().newPullParser().apply {
            setInput(StringReader(text))
        }
        return readDocument(parser)
    }

    fun serialize(draft: FuelSummaryDraft): String {
        val version = draft.configVersionText.trim().ifEmpty { "11" }
        val bySection = draft.fields.groupBy { it.sectionKey }

        return buildString {
            appendLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>")
            appendLine("<CONFIG")
            appendLine("    name=\"fuelsummary_uc\"")
            appendLine("    version=\"$version\">")

            sectionOrder.forEach { sectionKey ->
                val block = bySection[sectionKey].orEmpty()
                if (block.isEmpty()) return@forEach

                appendLine("    <$sectionKey>")
                block.forEach { field ->
                    when (field) {
                        is FuelEditableField.LoneInteger -> {
                            appendLine("        <integer name=\"${field.displayLabel}\">${field.valueText.trim()}</integer>")
                        }

                        is FuelEditableField.TokenRow -> {
                            val joined = field.tokens.joinToString(" ") { it.trim() }
                            val tag = if (field.isHexRow) "hex-array" else {
                                if (field.displayLabel.startsWith("integer-array")) "integer-array"
                                else "item"
                            }
                            if (tag == "item") {
                                appendLine("        <item name=\"${field.displayLabel}\">$joined</item>")
                            } else {
                                appendLine("        <$tag>$joined</$tag>")
                            }
                        }
                    }
                }
                appendLine("    </$sectionKey>")
            }

            appendLine("</CONFIG>")
        }
    }

    fun validate(draft: FuelSummaryDraft): String? {
        if (draft.configVersionText.trim().toIntOrNull() == null) {
            return "CONFIG version 须为整数"
        }

        draft.fields.forEach { field ->
            when (field) {
                is FuelEditableField.LoneInteger -> {
                    if (field.valueText.trim().toIntOrNull() == null) {
                        return "${field.displayLabel} 须为整数"
                    }
                }

                is FuelEditableField.TokenRow -> {
                    field.tokens.forEachIndexed { index, token ->
                        val trimmed = token.trim()
                        if (trimmed.isEmpty()) {
                            return "${field.displayLabel} 第 ${index + 1} 项不能为空"
                        }
                        if (field.isHexRow) {
                            if (!HEX_TOKEN.matches(trimmed)) {
                                return "${field.displayLabel} 第 ${index + 1} 项须为两位十六进制"
                            }
                        } else if (!SIGNED_NUMERIC_TOKEN.matches(trimmed)) {
                            return "${field.displayLabel} 第 ${index + 1} 项数值格式无效"
                        }
                    }
                }
            }
        }
        return null
    }

    private val sectionOrder = listOf(
        "normal_params",
        "driver_params",
        "charging_params",
        "battery_curve",
    )

    private val HEX_TOKEN = Regex("^[0-9A-Fa-f]{2}$")
    private val SIGNED_NUMERIC_TOKEN = Regex("^\\(-?\\d+\\)$|^-?\\d+$")

    private fun readDocument(parser: XmlPullParser): FuelSummaryDraft {
        var configVersion = "11"
        val fields = mutableListOf<FuelEditableField>()
        var currentSection: String? = null
        var integerArrayOrdinal = 0

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                when (parser.name) {
                    "CONFIG" -> {
                        configVersion = parser.getAttributeValue(null, "version") ?: "11"
                        integerArrayOrdinal = 0
                    }

                    "normal_params", "driver_params", "charging_params", "battery_curve" -> {
                        currentSection = parser.name
                        integerArrayOrdinal = 0
                    }

                    "integer" -> {
                        val section = currentSection ?: continue
                        val name = parser.getAttributeValue(null, "name") ?: "integer"
                        val body = readText(parser)
                        fields += FuelEditableField.LoneInteger(section, name, body.trim())
                    }

                    "item" -> {
                        val section = currentSection ?: continue
                        val name = parser.getAttributeValue(null, "name") ?: "item"
                        val body = readText(parser)
                        fields += FuelEditableField.TokenRow(
                            sectionKey = section,
                            displayLabel = name,
                            isHexRow = false,
                            tokens = splitNumericTokens(body).toMutableList(),
                        )
                    }

                    "integer-array" -> {
                        val section = currentSection ?: continue
                        integerArrayOrdinal++
                        val body = readText(parser)
                        fields += FuelEditableField.TokenRow(
                            sectionKey = section,
                            displayLabel = "integer-array #$integerArrayOrdinal",
                            isHexRow = false,
                            tokens = splitNumericTokens(body).toMutableList(),
                        )
                    }

                    "hex-array" -> {
                        val section = currentSection ?: continue
                        integerArrayOrdinal++
                        val body = readText(parser)
                        fields += FuelEditableField.TokenRow(
                            sectionKey = section,
                            displayLabel = "hex-array #$integerArrayOrdinal",
                            isHexRow = true,
                            tokens = body.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.toMutableList(),
                        )
                    }
                }
            }
            event = parser.next()
        }

        return FuelSummaryDraft(configVersionText = configVersion, fields = fields)
    }

    private fun readText(parser: XmlPullParser): String {
        if (parser.next() != XmlPullParser.TEXT) return ""
        return parser.text.orEmpty()
    }

    fun splitNumericTokens(raw: String): List<String> {
        val tokens = mutableListOf<String>()
        var cursor = 0
        val source = raw.trim()

        while (cursor < source.length) {
            if (source[cursor].isWhitespace()) {
                cursor++
                continue
            }

            if (source[cursor] == '(') {
                val closeAt = source.indexOf(')', cursor)
                if (closeAt < 0) break
                tokens += source.substring(cursor, closeAt + 1)
                cursor = closeAt + 1
                continue
            }

            val start = cursor
            while (cursor < source.length && !source[cursor].isWhitespace()) {
                cursor++
            }
            tokens += source.substring(start, cursor)
        }

        return tokens
    }
}
