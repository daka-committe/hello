package cn.boxiaolanya.tools.utils.shell

/**
 * 敏感 Shell / adb 类命令统一入口；Release 包内不保留明文模板。
 */
object ShellObf {
    fun s(key: String): String = ShellObfTable.get(key)
}

object ShellTokens {
    val sh: String get() = ShellObf.s("token.sh")
    val dashC: String get() = ShellObf.s("token.dash_c")
    val pidof: String get() = ShellObf.s("token.pidof")
    val pm: String get() = ShellObf.s("token.pm")
    val grant: String get() = ShellObf.s("token.grant")
    val logcat: String get() = ShellObf.s("token.logcat")
}
