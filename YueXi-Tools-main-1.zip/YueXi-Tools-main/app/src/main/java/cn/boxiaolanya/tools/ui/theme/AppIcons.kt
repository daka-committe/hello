/**
 * Material 图标扩展与功能页图标映射。
 */
package cn.boxiaolanya.tools.ui.theme

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.HdrOn
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.outlined.Android
import androidx.compose.material.icons.outlined.BugReport
import androidx.compose.material.icons.outlined.FlashOn
import androidx.compose.material.icons.outlined.Gamepad
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Science
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.HdrOn
import androidx.compose.material.icons.outlined.BatteryFull
import androidx.compose.ui.graphics.vector.ImageVector

object AppIcons {
    val Settings = Icons.Filled.Settings
    val SettingsOutlined = Icons.Outlined.Settings
    val Terminal = Icons.Filled.Terminal
    val TerminalOutlined = Icons.Outlined.Terminal
    val Gamepad = Icons.Filled.Gamepad
    val GamepadOutlined = Icons.Outlined.Gamepad
    val Star = Icons.Filled.Star
    val StarOutlined = Icons.Outlined.Star
    val Tune = Icons.Filled.Tune
    val TuneOutlined = Icons.Outlined.Tune
    val Lock = Icons.Filled.Lock
    val LockOutlined = Icons.Outlined.Lock
    val Refresh = Icons.Filled.Refresh
    val RefreshOutlined = Icons.Outlined.Refresh
    val FlashOn = Icons.Filled.FlashOn
    val FlashOnOutlined = Icons.Outlined.FlashOn
    val Bolt = Icons.Filled.FlashOn
    val Palette = Icons.Filled.Palette
    val PaletteOutlined = Icons.Outlined.Palette
    val BugReport = Icons.Filled.BugReport
    val BugReportOutlined = Icons.Outlined.BugReport
    val Android = Icons.Filled.Android
    val AndroidOutlined = Icons.Outlined.Android
    val Science = Icons.Filled.Science
    val ScienceOutlined = Icons.Outlined.Science
    val HdrOn = Icons.Filled.HdrOn
    val HdrOnOutlined = Icons.Outlined.HdrOn
    val BatteryFull = Icons.Filled.BatteryFull
    val BatteryFullOutlined = Icons.Outlined.BatteryFull
    val VolumeUp = Icons.Filled.VolumeUp
    val VolumeUpOutlined = Icons.Outlined.VolumeUp
    val Shield = Icons.Filled.Shield
    val ShieldOutlined = Icons.Outlined.Shield
}
