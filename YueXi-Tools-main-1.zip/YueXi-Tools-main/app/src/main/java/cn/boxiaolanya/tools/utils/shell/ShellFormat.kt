/**
 * Shell 命令模板占位符替换。
 *
 * 模板中使用 `%s`（字符串）与 `%d`（整数）占位；同一参数会同时替换两种占位符，
 * 便于模板混写 `--es foo %s` 与 `--ei bar %d`。
 *
 * [fmt2]/[fmt3] 按出现顺序 replaceFirst，避免全局 replace 打乱多个参数顺序。
 */
package cn.boxiaolanya.tools.utils.shell

object ShellFormat {

    fun fmt(tmpl: String, arg: String): String =
        tmpl.replace("%s", arg).replace("%d", arg)

    fun fmt2(tmpl: String, arg1: String, arg2: String): String {
        var s = tmpl.replaceFirst("%s", arg1).replaceFirst("%d", arg1)
        s = s.replaceFirst("%s", arg2).replaceFirst("%d", arg2)
        return s
    }

    fun fmt3(tmpl: String, arg1: String, arg2: String, arg3: String): String {
        var s = tmpl.replaceFirst("%s", arg1).replaceFirst("%d", arg1)
        s = s.replaceFirst("%s", arg2).replaceFirst("%d", arg2)
        return s.replaceFirst("%s", arg3).replaceFirst("%d", arg3)
    }
}
