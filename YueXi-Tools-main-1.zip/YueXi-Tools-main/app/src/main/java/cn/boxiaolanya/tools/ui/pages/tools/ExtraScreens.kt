/**
 * 部分工具页的共享 Composable（如云控停止页）。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.GameCubeManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun VBoostScreen(shizukuGranted: Boolean, navController: NavController) {
    val scope = rememberCoroutineScope()
    var output by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    fun invoke(block: () -> String) { scope.launch { isLoading = true; output = withContext(Dispatchers.IO) { try { block() } catch (e: Exception) { "fail" } }; isLoading = false } }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())) {
            Spacer(Modifier.height(16.dp))
            SettingSplicedColumnGroup { item { BaseWidget(icon = Icons.AutoMirrored.Filled.ArrowBack, title = "VBoost 加速", description = "返回高级调试", onClick = { navController.navigateUp() }) {} } }
            Spacer(Modifier.height(8.dp))
            if (!shizukuGranted) { SettingSplicedColumnGroup(title = "授权中心") { item { BaseWidget(icon = Icons.Default.Speed, title = "Shizuku 未连接", isError = true) {} } } }
            else {
                val ok = remember { GameCubeManager.VBoost.isAvailable }
                var featId by remember { mutableStateOf("3") }
                SettingSplicedColumnGroup(title = "VBoost 控制") {
                    item {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(if (ok) "VBoost 服务已就绪" else "VBoost 服务不可用", style = MaterialTheme.typography.bodySmall, color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                            OutlinedTextField(value = featId, onValueChange = { featId = it }, label = { Text("Feature ID (0-7)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { invoke { GameCubeManager.VBoost.invoke(featId.toIntOrNull() ?: 3, 1) } }, modifier = Modifier.weight(1f)) { Text("查询状态") }
                                Button(onClick = { invoke { GameCubeManager.VBoost.invoke(featId.toIntOrNull() ?: 3, 2, level = 1, timeout = 3000) } }, modifier = Modifier.weight(1f)) { Text("设置参数") }
                            }
                        }
                    }
                }
            }
            if (output.isNotBlank()) { Spacer(Modifier.height(16.dp)); SettingSplicedColumnGroup(title = "当前状态") { item { Column(Modifier.padding(16.dp)) { SelectionContainer { Text(output, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }; item { BaseWidget(icon = Icons.Default.Clear, title = "清空", onClick = { output = "" }) {} } } }
            Spacer(Modifier.height(WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }
    if (isLoading) { Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceBright), elevation = CardDefaults.cardElevation(4.dp)) { Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) { CircularProgressIndicator(Modifier.size(48.dp)); Spacer(Modifier.height(16.dp)); Text("请稍等...", style = MaterialTheme.typography.bodyLarge) } } } } }
}
