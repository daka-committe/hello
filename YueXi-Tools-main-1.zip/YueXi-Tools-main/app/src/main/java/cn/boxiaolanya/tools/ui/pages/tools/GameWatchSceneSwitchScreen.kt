/**
 * GameWatch 场景状态： [GameWatchCommands.sceneStatus] 切换 packageName/status。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.shell.GameWatchCommands
import cn.boxiaolanya.tools.utils.ShizukuExec
import kotlinx.coroutines.launch

data class SceneOption(val value: Int, val label: String)

data class PackageSceneEntry(
    var packageName: String = "",
    var sceneStatus: Int = 1
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameWatchSceneSwitchScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var isExecuting by remember { mutableStateOf(false) }
    var lastResult by remember { mutableStateOf<GameWatchConfigResult?>(null) }
    var packageEntries by remember { mutableStateOf(listOf(PackageSceneEntry())) }

    val sceneOptions = listOf(
        SceneOption(0, "退出场景"),
        SceneOption(1, "进入场景"),
        SceneOption(2, "加载中")
    )

    fun addEntry() {
        packageEntries = packageEntries + PackageSceneEntry()
    }

    fun removeEntry(index: Int) {
        if (packageEntries.size > 1) {
            packageEntries = packageEntries.toMutableList().apply { removeAt(index) }
        }
    }

    fun updateEntry(index: Int, packageName: String, sceneStatus: Int) {
        packageEntries = packageEntries.toMutableList().apply {
            this[index] = this[index].copy(packageName = packageName, sceneStatus = sceneStatus)
        }
    }

    fun executeEntry(index: Int) {
        if (!shizukuGranted) {
            scope.launch { snackbarHostState.showSnackbar("需授予 Shizuku 权限") }
            return
        }
        val entry = packageEntries[index]
        if (entry.packageName.isBlank()) {
            scope.launch { snackbarHostState.showSnackbar("请输入包名") }
            return
        }

        scope.launch {
            isExecuting = true
            val command = GameWatchCommands.sceneStatus(entry.packageName, entry.sceneStatus.toString())
            val (output, success) = ShizukuExec.runShLine(command)
            lastResult = GameWatchConfigResult(success, output)
            isExecuting = false
        }
    }

    fun executeAll() {
        if (!shizukuGranted) {
            scope.launch { snackbarHostState.showSnackbar("需授予 Shizuku 权限") }
            return
        }
        val validEntries = packageEntries.filter { it.packageName.isNotBlank() }
        if (validEntries.isEmpty()) {
            scope.launch { snackbarHostState.showSnackbar("请至少填写一个包名") }
            return
        }

        scope.launch {
            isExecuting = true
            var allSuccess = true
            var combinedOutput = ""
            for (entry in validEntries) {
                val command = GameWatchCommands.sceneStatus(entry.packageName, entry.sceneStatus.toString())
                val (output, success) = ShizukuExec.runShLine(command)
                allSuccess = allSuccess && success
                combinedOutput += "[${entry.packageName}] $output\n"
            }
            lastResult = GameWatchConfigResult(allSuccess, combinedOutput)
            isExecuting = false
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
                )
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "场景切换",
                        description = "返回 GameWatch",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            if (!shizukuGranted) {
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Clear,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以使用此功能",
                            isError = true
                        ) {}
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "场景切换列表") {
                    packageEntries.forEachIndexed { index, entry ->
                        item {
                            PackageSceneRow(
                                index = index,
                                entry = entry,
                                sceneOptions = sceneOptions,
                                onUpdate = { pkg, status -> updateEntry(index, pkg, status) },
                                onExecute = { executeEntry(index) },
                                onRemove = { removeEntry(index) },
                                canRemove = packageEntries.size > 1
                            )
                        }
                    }
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { addEntry() },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("添加")
                            }
                            Button(
                                onClick = { executeAll() },
                                modifier = Modifier.weight(1f),
                                enabled = packageEntries.any { it.packageName.isNotBlank() }
                            ) { Text("全部执行") }
                        }
                    }
                }
            }

            lastResult?.let { result ->
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "执行结果") {
                    item {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = if (result.success) "成功" else "错误",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (result.success) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                            if (result.output.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                SelectionContainer {
                                    Text(
                                        text = result.output,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }

    if (isExecuting) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceBright
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(48.dp),
                            strokeWidth = 4.dp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "正在执行...",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PackageSceneRow(
    index: Int,
    entry: PackageSceneEntry,
    sceneOptions: List<SceneOption>,
    onUpdate: (String, Int) -> Unit,
    onExecute: () -> Unit,
    onRemove: () -> Unit,
    canRemove: Boolean
) {
    var sceneExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("条目 ${index + 1}", style = MaterialTheme.typography.labelMedium)
            if (canRemove) {
                IconButton(onClick = onRemove) {
                    Icon(Icons.Default.Delete, "删除", tint = MaterialTheme.colorScheme.error)
                }
            }
        }

        OutlinedTextField(
            value = entry.packageName,
            onValueChange = { onUpdate(it, entry.sceneStatus) },
            label = { Text("应用包名") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("com.tencent.tmgp.sgame") }
        )

        ExposedDropdownMenuBox(
            expanded = sceneExpanded,
            onExpandedChange = { sceneExpanded = !sceneExpanded }
        ) {
            OutlinedTextField(
                value = sceneOptions.find { it.value == entry.sceneStatus }?.label ?: "",
                onValueChange = {},
                readOnly = true,
                label = { Text("场景状态") },
                modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable, true),
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = sceneExpanded) }
            )
            ExposedDropdownMenu(
                expanded = sceneExpanded,
                onDismissRequest = { sceneExpanded = false }
            ) {
                sceneOptions.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option.label) },
                        onClick = {
                            onUpdate(entry.packageName, option.value)
                            sceneExpanded = false
                        }
                    )
                }
            }
        }

        OutlinedButton(
            onClick = onExecute,
            modifier = Modifier.fillMaxWidth(),
            enabled = entry.packageName.isNotBlank()
        ) { Text("执行此条目") }
    }
}
