/**
 * ABE/厂商服务诊断：ServiceManager、系统属性、Binder 探测。
 */
package cn.boxiaolanya.tools.utils

import android.os.Build
import android.os.IBinder
import android.os.Parcel

object AbeDiagnostics {

    val VIVO_SERVICES = mapOf(
        "vivo_daemon.service" to "vivo 守护进程(Shell)",
        "vivo_art_keeper_service" to "ART 编译优化",
        "gamewatch_server" to "游戏加速(Watch)",
        "vboost" to "VBoost 性能加速",
        "rms" to "资源管理系统(RMS)",
        "rms_statistics" to "RMS 统计",
        "vivo_event_service" to "vivo 事件服务",
        "SurfaceFlinger" to "SurfaceFlinger",
        "vcode" to "vivo 设备编码",
    )

    val VIVO_PERF_PROPERTIES = mapOf(
        "persist.vivo.power.ctrl" to "电源控制(0=省电 1=均衡 2=性能)",
        "persist.vivo.game.ctrl" to "游戏模式控制(0=关 1=开)",
        "persist.vivo.epm.switch" to "EPM 策略开关(0=关 1=开)",
        "persist.vivo.background.ctrl" to "后台控制(0=无限制 1=限制)",
        "persist.vivo.vivo_daemon" to "vivo 守护进程版本",
        "ro.vivo.product.solution" to "平台方案(qcom/mtk)",
        "debug.sf.hw" to "SF 硬件渲染",
        "debug.composition.type" to "合成类型(gpu/c2c/dmd)",
    )

    fun serviceManagerGetService(name: String): IBinder? {
        return try {
            val sm = Class.forName("android.os.ServiceManager")
            val m = sm.getDeclaredMethod("getService", String::class.java)
            m.invoke(null, name) as? IBinder
        } catch (_: Exception) { null }
    }

    fun serviceManagerCheckService(name: String): IBinder? {
        return try {
            val sm = Class.forName("android.os.ServiceManager")
            val m = sm.getDeclaredMethod("checkService", String::class.java)
            m.invoke(null, name) as? IBinder
        } catch (_: Exception) { null }
    }

    fun listServices(): List<String> {
        return try {
            val sm = Class.forName("android.os.ServiceManager")
            val m = sm.getDeclaredMethod("listServices")
            @Suppress("UNCHECKED_CAST")
            (m.invoke(null) as? Array<String>)?.toList() ?: emptyList()
        } catch (_: Exception) { emptyList() }
    }

    fun getSystemProperty(name: String, default: String = ""): String {
        return try {
            val clz = Class.forName("android.os.SystemProperties")
            val m = clz.getDeclaredMethod("get", String::class.java, String::class.java)
            m.invoke(null, name, default) as? String ?: default
        } catch (_: Exception) { default }
    }

    fun setSystemProperty(name: String, value: String): String {
        return try {
            val clz = Class.forName("android.os.SystemProperties")
            val m = clz.getDeclaredMethod("set", String::class.java, String::class.java)
            m.invoke(null, name, value)
            "ok"
        } catch (e: Exception) { "fail: ${e.message}" }
    }

    fun epmGetInstance(): Any? {
        return try {
            val clz = Class.forName("vivo.app.epm.ExceptionPolicyManager")
            clz.getDeclaredMethod("getInstance").invoke(null)
        } catch (_: Exception) { null }
    }

    fun epmGetInstanceName(): String {
        val inst = epmGetInstance()
        return inst?.javaClass?.name ?: "unavailable"
    }

    fun epmGetSwitchState(name: String): String {
        val instance = epmGetInstance() ?: return "EPM not available"
        return try {
            val clz = Class.forName("vivo.app.epm.ExceptionPolicyManager")
            val m = clz.getDeclaredMethod("getSwitchState", String::class.java)
            val result = m.invoke(instance, name) ?: return "null"
            val sc = Class.forName("vivo.app.epm.Switch")
            val getName = sc.getDeclaredMethod("getName")
            val isEnable = sc.getDeclaredMethod("isEnable")
            val isDefaultEnable = sc.getDeclaredMethod("isDefaultEnable")
            val defValue = sc.getDeclaredMethod("getDefValue")
            "name=${getName.invoke(result)} " +
                "enable=${isEnable.invoke(result)} " +
                "defaultEnable=${isDefaultEnable.invoke(result)} " +
                "defValue=${defValue.invoke(result)}"
        } catch (e: Exception) { "error: ${e.message}" }
    }

    fun epmGetSwitchState2(name: String, defPkg: String): String {
        val instance = epmGetInstance() ?: return "EPM not available"
        return try {
            val clz = Class.forName("vivo.app.epm.ExceptionPolicyManager")
            val m = clz.getDeclaredMethod("getSwitchState", String::class.java, String::class.java)
            val result = m.invoke(instance, name, defPkg) ?: return "null"
            val sc = Class.forName("vivo.app.epm.Switch")
            val getName = sc.getDeclaredMethod("getName")
            val isEnable = sc.getDeclaredMethod("isEnable")
            val isDefaultEnable = sc.getDeclaredMethod("isDefaultEnable")
            val defValue = sc.getDeclaredMethod("getDefValue")
            "name=${getName.invoke(result)} " +
                "enable=${isEnable.invoke(result)} " +
                "defaultEnable=${isDefaultEnable.invoke(result)} " +
                "defValue=${defValue.invoke(result)}"
        } catch (e: Exception) { "error: ${e.message}" }
    }

    fun epmReportEvent(eventType: Int, time: Long, extra: String) {
        val instance = epmGetInstance() ?: return
        try {
            val clz = Class.forName("vivo.app.epm.ExceptionPolicyManager")
            val m = clz.getDeclaredMethod("reportEvent", Int::class.javaPrimitiveType,
                Long::class.javaPrimitiveType, String::class.java)
            m.invoke(instance, eventType, time, extra)
        } catch (_: Exception) {}
    }

    fun epmReportEventWithContentValues(eventType: Int, time: Long, vararg pairs: Pair<String, String>) {
        val instance = epmGetInstance() ?: return
        try {
            val cv = Class.forName("android.content.ContentValues").getConstructor().newInstance() as? Any ?: return
            val putMethod = cv.javaClass.getDeclaredMethod("put", String::class.java, String::class.java)
            for ((k, v) in pairs) putMethod.invoke(cv, k, v)
            val clz = Class.forName("vivo.app.epm.ExceptionPolicyManager")
            val m = clz.getDeclaredMethod("reportEvent", Int::class.javaPrimitiveType,
                Long::class.javaPrimitiveType, Class.forName("android.content.ContentValues"))
            m.invoke(instance, eventType, time, cv)
        } catch (_: Exception) {}
    }

    fun checkBinderAlive(name: String): Triple<String, Boolean, String> {
        return try {
            val binder = serviceManagerCheckService(name)
            if (binder == null) Triple(name, false, "not registered")
            else {
                val alive = binder.isBinderAlive
                val cls = binder.javaClass.name
                Triple(name, alive, "$cls | ${if (alive) "alive" else "dead"}")
            }
        } catch (e: Exception) { Triple(name, false, "error: ${e.message}") }
    }

    fun transactBinder(name: String, code: Int, descriptor: String = "", payload: Parcel.() -> Unit = {}): String {
        return try {
            val binder = serviceManagerCheckService(name) ?: return "service not found"
            val data = Parcel.obtain()
            val reply = Parcel.obtain()
            if (descriptor.isNotEmpty()) data.writeInterfaceToken(descriptor)
            payload(data)
            val ok = binder.transact(code, data, reply, 0)
            val info = buildString {
                append("transact($code) ")
                append(if (ok) "OK" else "FAILED")
                if (reply.dataSize() > 0) {
                    append(" | reply=${reply.dataSize()}B")
                    reply.setDataPosition(0)
                    try { reply.readException(); append(" | no_exception") } catch (_: Exception) {
                        try { append(" | first_int=${reply.readInt()}") } catch (_: Exception) {}
                    }
                }
            }
            data.recycle(); reply.recycle()
            info
        } catch (e: Exception) { "error: ${e.message}" }
    }

    fun getInterfaceDescriptor(binder: IBinder): String? {
        return try {
            val m = binder.javaClass.getDeclaredMethod("getInterfaceDescriptor")
            if (!m.isAccessible) m.isAccessible = true
            m.invoke(binder) as? String
        } catch (_: Exception) { null }
    }

    class ServiceInfo(val name: String, val binder: IBinder?, val descriptor: String?, val alive: Boolean, val className: String?)

    fun inspectService(name: String): ServiceInfo {
        val binder = serviceManagerCheckService(name)
        if (binder == null) return ServiceInfo(name, null, null, false, null)
        val desc = getInterfaceDescriptor(binder)
        return ServiceInfo(name, binder, desc, binder.isBinderAlive, binder.javaClass.name)
    }

    val EPM_SWITCH_NAMES = listOf(
        "persist.vivo.epm.switch",
        "persist.vivo.epm.debug",
        "persist.vivo.power.ctrl",
        "persist.vivo.game.ctrl",
        "persist.vivo.background.ctrl",
    )

    fun applyPerfProfile(level: Int): String {
        val sb = StringBuilder()
        sb.appendLine("应用性能配置: level=$level")
        when (level) {
            0 -> {
                sb.appendLine("省电模式")
                setSystemProperty("persist.vivo.power.ctrl", "0")
                epmReportEvent(1001, System.currentTimeMillis(), "power_save_mode=1")
            }
            1 -> {
                sb.appendLine("均衡模式")
                setSystemProperty("persist.vivo.power.ctrl", "1")
            }
            2 -> {
                sb.appendLine("性能模式")
                setSystemProperty("persist.vivo.power.ctrl", "2")
                setSystemProperty("persist.vivo.game.ctrl", "1")
                epmReportEvent(1002, System.currentTimeMillis(), "game_mode=1")
            }
        }
        sb.appendLine("persist.vivo.power.ctrl -> ${getSystemProperty("persist.vivo.power.ctrl")}")
        return sb.toString()
    }

    fun setAnimationScales(scale: Float): String {
        return try {
            val clz = Class.forName("android.os.ServiceManager")
            val m = clz.getDeclaredMethod("getService", String::class.java)
            val windowManager = m.invoke(null, "window") as? IBinder ?: return "fail: no window service"
            val data = Parcel.obtain()
            data.writeInterfaceToken("android.view.IWindowManager")
            data.writeFloat(scale)
            windowManager.transact(10009, data, null, 0)
            data.recycle()
            "动画缩放已设为 $scale"
        } catch (e: Exception) { "fail: ${e.message}" }
    }
}
