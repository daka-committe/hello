/**
 * 高级调试入口：列出 Activity/Kill/Crash/网络策略/Perf/SF 等实验项。
 *
 * 子路由在 [cn.boxiaolanya.tools.ui.pages.Screen] 中定义。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.pages.Screen
import cn.boxiaolanya.tools.ui.theme.AppIcons
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup

@Composable
fun ExperimentalScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "高级调试",
                        description = "返回悦玺工具箱",
                        onClick = { navController.navigateUp() }) {}
                }
            }

            if (!shizukuGranted) {
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(icon = Icons.Default.Apps, title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以启用高级调试功能", isError = true) {}
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "游戏加速") {
                    item {
                        BaseWidget(
                            iconSpec = AppIcons.Gamepad,
                            title = "GameWatch",
                            description = "场景切换/画质/帧率/Binder IPC",
                            onClick = { navController.navigate(Screen.GameWatch.route) }
                        ) {}
                    }
                    item {
                        BaseWidget(
                            iconSpec = AppIcons.Bolt,
                            title = "性能调度",
                            description = "CPU/GPU 频率与调度优化",
                            onClick = { navController.navigate(Screen.ExperimentalPerf.route) }
                        ) {}
                    }
                    item {
                        BaseWidget(
                            icon = Icons.Default.BatteryAlert,
                            title = "Doze 白名单",
                            description = "管理设备 Doze 模式应用白名单",
                            onClick = { navController.navigate(Screen.ExperimentalDeviceIdle.route) }
                        ) {}
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "智慧引擎") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.AutoAwesome,
                            title = "智慧引擎",
                            description = "功耗与配置管理",
                            onClick = { navController.navigate(Screen.SmartEngine.route) }
                        ) {}
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "系统工具") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.CloudOff,
                            title = "去云控",
                            description = "切断 vivo 云控通道",
                            onClick = { navController.navigate(Screen.CloudControl.route) }
                        ) {}
                    }
                    item {
                        BaseWidget(icon = Icons.Default.PlayArrow, title = "Activity 服务控制",
                            description = "dumpsys 启停服务/Activity",
                            onClick = { navController.navigate(Screen.ExperimentalActivityService.route) }) {}
                    }
                    item {
                        BaseWidget(icon = Icons.Default.Notifications, title = "vivo 事件监听",
                            description = "Binder IPC 监听系统事件",
                            onClick = { navController.navigate(Screen.ExperimentalEventMonitor.route) }) {}
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "开发者工具") {
                    item {
                        BaseWidget(icon = Icons.Default.BugReport, title = "崩溃模拟",
                            description = "向目标应用发送崩溃指令",
                            onClick = { navController.navigate(Screen.ExperimentalCrash.route) }) {}
                    }
                    item {
                        BaseWidget(iconSpec = AppIcons.Lock, title = "隐私保护",
                            description = "SurfaceFlinger 游戏防窥模式",
                            onClick = { navController.navigate(Screen.ExperimentalSF.route) }) {}
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }
}
