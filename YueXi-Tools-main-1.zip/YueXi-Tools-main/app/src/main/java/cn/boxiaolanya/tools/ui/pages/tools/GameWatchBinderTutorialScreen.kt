/**
 * GameWatch Binder 教程：从 assets 加载 Markdown（GameWatch-Binder.md）渲染。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import org.commonmark.ext.gfm.tables.TablesExtension
import org.commonmark.node.*
import org.commonmark.parser.Parser
import java.io.BufferedReader
import java.io.InputStreamReader

@Composable
fun GameWatchBinderTutorialScreen(
    navController: NavController
) {
    val context = LocalContext.current
    var markdownContent by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        try {
            val inputStream = context.assets.open("GameWatch-Binder.md")
            val reader = BufferedReader(InputStreamReader(inputStream))
            val content = reader.readText()
            reader.close()
            markdownContent = content
        } catch (e: Exception) {
            error = e.message
        }
        isLoading = false
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())
        ) {
            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "Binder IPC 教程",
                        description = "返回",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            when {
                isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
                error != null -> {
                    Box(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "加载失败: $error",
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
                markdownContent != null -> {
                    val parser = remember {
                        Parser.builder()
                            .extensions(listOf(TablesExtension.create()))
                            .build()
                    }
                    val document = remember(markdownContent) { parser.parse(markdownContent!!) }
                    val blocks = remember(document) { parseDocument(document) }

                    SelectionContainer {
                        Column(
                            modifier = Modifier.fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 16.dp)
                        ) {
                            Spacer(modifier = Modifier.height(8.dp))
                            MdBlocksRenderer(blocks = blocks)
                            Spacer(modifier = Modifier.height(
                                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
                        }
                    }
                }
            }
        }
    }
}

private sealed class MdBlock {
    data class Heading(val text: String, val level: Int) : MdBlock()
    data class Paragraph(val inlines: List<MdInline>) : MdBlock()
    data class UnorderedList(val items: List<List<MdInline>>) : MdBlock()
    data class OrderedList(val items: List<List<MdInline>>) : MdBlock()
    data class Blockquote(val blocks: List<MdBlock>) : MdBlock()
    data class CodeBlock(val code: String, val language: String) : MdBlock()
    data class InlineCode(val code: String) : MdBlock()
    data class Table(
        val header: List<List<List<MdInline>>>,
        val rows: List<List<List<MdInline>>>
    ) : MdBlock()
    data object HorizontalRule : MdBlock()
    data class Link(val text: String, val href: String) : MdBlock()
    data class Image(val alt: String, val src: String) : MdBlock()
}

private sealed class MdInline {
    data class Text(val text: String) : MdInline()
    data class Bold(val text: String) : MdInline()
    data class Italic(val text: String) : MdInline()
    data class BoldItalic(val text: String) : MdInline()
    data class Strikethrough(val text: String) : MdInline()
    data class Code(val code: String) : MdInline()
    data class Link(val text: String, val href: String) : MdInline()
    data object Break : MdInline()
    data object SoftBreak : MdInline()
}

@Composable
private fun MdBlocksRenderer(blocks: List<MdBlock>) {
    Column(modifier = Modifier.fillMaxWidth()) {
        blocks.forEach { block ->
            when (block) {
                is MdBlock.Heading -> {
                    val style = when (block.level) {
                        1 -> MaterialTheme.typography.headlineMedium
                        2 -> MaterialTheme.typography.titleLarge
                        3 -> MaterialTheme.typography.titleMedium
                        4 -> MaterialTheme.typography.titleSmall
                        5 -> MaterialTheme.typography.bodyLarge
                        else -> MaterialTheme.typography.bodyMedium
                    }
                    val spaceTop = when (block.level) {
                        1 -> 16.dp; 2 -> 14.dp; 3 -> 12.dp; 4 -> 10.dp; 5 -> 8.dp; else -> 6.dp
                    }
                    val spaceBottom = when (block.level) {
                        1 -> 8.dp; 2 -> 6.dp; 3 -> 4.dp; 4 -> 4.dp; 5 -> 4.dp; else -> 4.dp
                    }
                    Spacer(modifier = Modifier.height(spaceTop))
                    Text(
                        text = block.text,
                        style = style,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(spaceBottom))
                }
                is MdBlock.Paragraph -> {
                    Spacer(modifier = Modifier.height(4.dp))
                    MdInlineText(inlines = block.inlines)
                    Spacer(modifier = Modifier.height(4.dp))
                }
                is MdBlock.UnorderedList -> {
                    Spacer(modifier = Modifier.height(4.dp))
                    block.items.forEach { item ->
                        Row(modifier = Modifier.padding(start = 8.dp)) {
                            Text("\u2022 ", style = MaterialTheme.typography.bodyMedium)
                            MdInlineText(inlines = item, modifier = Modifier.weight(1f))
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }
                is MdBlock.OrderedList -> {
                    Spacer(modifier = Modifier.height(4.dp))
                    block.items.forEachIndexed { index, item ->
                        Row(modifier = Modifier.padding(start = 8.dp)) {
                            Text("${index + 1}. ", style = MaterialTheme.typography.bodyMedium)
                            MdInlineText(inlines = item, modifier = Modifier.weight(1f))
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }
                is MdBlock.Blockquote -> {
                    Spacer(modifier = Modifier.height(4.dp))
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            MdBlocksRenderer(blocks = block.blocks)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }
                is MdBlock.CodeBlock -> {
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFF1E1E1E)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .horizontalScroll(rememberScrollState())
                                .padding(12.dp)
                        ) {
                            Text(
                                text = block.code,
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                color = Color(0xFFD4D4D4)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
                is MdBlock.InlineCode -> {
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .background(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = MaterialTheme.shapes.small
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = block.code,
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }
                is MdBlock.Table -> {
                    Spacer(modifier = Modifier.height(8.dp))
                    MdTable(block)
                    Spacer(modifier = Modifier.height(8.dp))
                }
                is MdBlock.HorizontalRule -> {
                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(modifier = Modifier.height(12.dp))
                }
                is MdBlock.Link -> {
                    Text(
                        text = block.text,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        textDecoration = TextDecoration.Underline,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                is MdBlock.Image -> {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "[${block.alt}]",
                        style = MaterialTheme.typography.bodyMedium,
                        fontStyle = FontStyle.Italic,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }
        }
    }
}

@Composable
private fun MdInlineText(
    inlines: List<MdInline>,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.onSurface
) {
    val mono = androidx.compose.ui.text.font.FontFamily.Monospace
    val codeBg = MaterialTheme.colorScheme.surfaceVariant
    val linkColor = MaterialTheme.colorScheme.primary
    val bodySmallSize = MaterialTheme.typography.bodySmall.fontSize
    val str = remember(inlines, color, codeBg, linkColor, bodySmallSize) {
        buildAnnotatedString {
            inlines.forEach { element ->
                when (element) {
                    is MdInline.Text -> {
                        withStyle(SpanStyle(color = color)) {
                            append(element.text)
                        }
                    }
                    is MdInline.Bold -> {
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = color)) {
                            append(element.text)
                        }
                    }
                    is MdInline.Italic -> {
                        withStyle(SpanStyle(fontStyle = FontStyle.Italic, color = color)) {
                            append(element.text)
                        }
                    }
                    is MdInline.BoldItalic -> {
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic, color = color)) {
                            append(element.text)
                        }
                    }
                    is MdInline.Strikethrough -> {
                        withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough, color = color)) {
                            append(element.text)
                        }
                    }
                    is MdInline.Code -> {
                        withStyle(SpanStyle(
                            fontFamily = mono,
                            fontSize = bodySmallSize,
                            background = codeBg,
                            color = color
                        )) {
                            append(element.code)
                        }
                    }
                    is MdInline.Link -> {
                        withStyle(SpanStyle(
                            color = linkColor,
                            textDecoration = TextDecoration.Underline
                        )) {
                            append(element.text)
                        }
                    }
                    is MdInline.Break -> {
                        append("\n")
                    }
                    is MdInline.SoftBreak -> {
                        append(" ")
                    }
                }
            }
        }
    }
    Text(
        text = str,
        style = MaterialTheme.typography.bodyMedium,
        modifier = modifier
    )
}

@Composable
private fun MdTable(table: MdBlock.Table) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            table.header.forEachIndexed { rowIndex, row ->
                MdTableRow(row = row, isHeader = true)
                if (rowIndex == 0) {
                    Spacer(modifier = Modifier.height(4.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline, thickness = 1.dp)
                }
            }
            table.rows.forEachIndexed { rowIndex, row ->
                MdTableRow(row = row, isHeader = false)
            }
        }
    }
}

@Composable
private fun MdTableRow(row: List<List<MdInline>>, isHeader: Boolean) {
    Row(modifier = Modifier.fillMaxWidth()) {
        row.forEachIndexed { colIndex, cellList ->
            val isLastColumn = colIndex == row.lastIndex
            Box(
                modifier = Modifier
                    .weight(1f)
                    .then(
                        if (isLastColumn) Modifier else Modifier.padding(end = 8.dp)
                    )
                    .background(
                        if (isHeader) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                        else Color.Transparent,
                        shape = MaterialTheme.shapes.extraSmall
                    )
                    .padding(4.dp)
            ) {
                MdInlineText(
                    inlines = cellList,
                    color = if (isHeader) MaterialTheme.colorScheme.onPrimaryContainer
                            else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

private fun parseDocument(document: Node): List<MdBlock> {
    val blocks = mutableListOf<MdBlock>()
    var child = document.firstChild
    while (child != null) {
        val block = parseNode(child)
        if (block != null) blocks.add(block)
        child = child.next
    }
    return blocks
}

private fun parseNode(node: Node): MdBlock? {
    return when (node) {
        is Heading -> MdBlock.Heading(
            text = collectText(node),
            level = node.level
        )
        is Paragraph -> {
            val inlines = collectInline(node)
            if (inlines.isEmpty()) null else MdBlock.Paragraph(inlines)
        }
        is BulletList -> {
            val items = mutableListOf<List<MdInline>>()
            var child = node.firstChild
            while (child != null) {
                if (child is ListItem) {
                    val itemInlines = collectInline(child)
                    if (itemInlines.isNotEmpty()) items.add(itemInlines)
                }
                child = child.next
            }
            if (items.isEmpty()) null else MdBlock.UnorderedList(items)
        }
        is OrderedList -> {
            val items = mutableListOf<List<MdInline>>()
            var child = node.firstChild
            while (child != null) {
                if (child is ListItem) {
                    val itemInlines = collectInline(child)
                    if (itemInlines.isNotEmpty()) items.add(itemInlines)
                }
                child = child.next
            }
            if (items.isEmpty()) null else MdBlock.OrderedList(items)
        }
        is FencedCodeBlock -> MdBlock.CodeBlock(
            code = node.literal.trimEnd('\n'),
            language = node.info ?: ""
        )
        is IndentedCodeBlock -> MdBlock.CodeBlock(
            code = node.literal.trimEnd('\n'),
            language = ""
        )
        is ThematicBreak -> MdBlock.HorizontalRule
        is BlockQuote -> {
            val subBlocks = mutableListOf<MdBlock>()
            var child = node.firstChild
            while (child != null) {
                val parsed = parseNode(child)
                if (parsed != null) subBlocks.add(parsed)
                child = child.next
            }
            if (subBlocks.isEmpty()) null else MdBlock.Blockquote(subBlocks)
        }
        is Code -> MdBlock.InlineCode(code = node.literal)
        is Link -> MdBlock.Link(text = collectText(node), href = node.destination ?: "")
        is Image -> MdBlock.Image(alt = node.title ?: "", src = node.destination ?: "")
        is org.commonmark.ext.gfm.tables.TableBlock -> {
            val header = mutableListOf<List<List<MdInline>>>()
            val rows = mutableListOf<List<List<MdInline>>>()
            var child = node.firstChild
            while (child != null) {
                when (child) {
                    is org.commonmark.ext.gfm.tables.TableHead -> {
                        var row = child.firstChild
                        while (row != null) {
                            if (row is org.commonmark.ext.gfm.tables.TableRow) {
                                val cells = mutableListOf<List<MdInline>>()
                                var cell = row.firstChild
                                while (cell != null) {
                                    if (cell is org.commonmark.ext.gfm.tables.TableCell) {
                                        cells.add(collectInline(cell))
                                    }
                                    cell = cell.next
                                }
                                if (cells.isNotEmpty()) header.add(cells)
                            }
                            row = row.next
                        }
                    }
                    is org.commonmark.ext.gfm.tables.TableBody -> {
                        var row = child.firstChild
                        while (row != null) {
                            if (row is org.commonmark.ext.gfm.tables.TableRow) {
                                val cells = mutableListOf<List<MdInline>>()
                                var cell = row.firstChild
                                while (cell != null) {
                                    if (cell is org.commonmark.ext.gfm.tables.TableCell) {
                                        cells.add(collectInline(cell))
                                    }
                                    cell = cell.next
                                }
                                if (cells.isNotEmpty()) rows.add(cells)
                            }
                            row = row.next
                        }
                    }
                }
                child = child.next
            }
            if (header.isEmpty() && rows.isEmpty()) return null
            if (header.isEmpty() && rows.isNotEmpty()) {
                MdBlock.Table(header = rows, rows = emptyList())
            } else {
                MdBlock.Table(header = header, rows = rows)
            }
        }
        else -> null
    }
}

private fun collectText(node: Node): String {
    val sb = StringBuilder()
    collectTextRecursive(node, sb)
    return sb.toString().trim()
}

private fun collectTextRecursive(node: Node, sb: StringBuilder) {
    if (node is Text) {
        sb.append(node.literal)
    }
    if (node is SoftLineBreak) {
        sb.append(" ")
    }
    if (node is HardLineBreak) {
        sb.append("\n")
    }
    if (node is Code) {
        sb.append(node.literal)
    }
    var child = node.firstChild
    while (child != null) {
        collectTextRecursive(child, sb)
        child = child.next
    }
}

private fun collectInline(node: Node): List<MdInline> {
    val items = mutableListOf<MdInline>()
    collectInlineRecursive(node, items)
    return items
}

private fun collectInlineRecursive(node: Node, items: MutableList<MdInline>) {
    when (node) {
        is Text -> {
            items.add(MdInline.Text(node.literal))
        }
        is SoftLineBreak -> {
            items.add(MdInline.SoftBreak)
        }
        is HardLineBreak -> {
            items.add(MdInline.Break)
        }
        is Code -> {
            items.add(MdInline.Code(node.literal))
        }
        is Emphasis -> {
            val text = collectText(node)
            if (text.isNotBlank()) {
                items.add(MdInline.Italic(text))
            }
        }
        is StrongEmphasis -> {
            val text = collectText(node)
            if (text.isNotBlank()) {
                items.add(MdInline.Bold(text))
            }
        }
        is Link -> {
            val text = collectText(node)
            if (text.isNotBlank()) {
                items.add(MdInline.Link(text = text, href = node.destination ?: ""))
            }
        }
        is Image -> {
        }
        else -> {
            var child = node.firstChild
            while (child != null) {
                collectInlineRecursive(child, items)
                child = child.next
            }
        }
    }
}
