/**
 * VIVO-RMS 监控使用的 secure settings 键名。
 * 与 [VivoRmsScreen]、[VivoRmsMonitorService] 配合读写 active request reason。
 */
package cn.boxiaolanya.tools.utils.shell

import cn.boxiaolanya.tools.utils.SettingsContentAccess

object VivoRmsCommands {
    const val SECURE_KEY = "vivo_rms_active_request_reason"
    val SECURE_TABLE = SettingsContentAccess.Table.SECURE
}
