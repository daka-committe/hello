/**
 * 自定义 Shell 终端：用户输入整行命令或点选 [CommandTerminalPresets]。
 *
 * 经 [ShizukuExec.runShellCommand] 执行；展示 stdout/stderr 与成功标志。
 * 等效 adb shell 权限，误操作可能导致系统不稳定。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.shell.CommandTerminalPresets
import cn.boxiaolanya.tools.utils.ShizukuExec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun CommandScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var command by remember { mutableStateOf("") }
    var isExecuting by remember { mutableStateOf(false) }
    val commandHistory = remember { mutableStateListOf<CommandResult>() }

    fun executeCommand() {
        if (command.isBlank()) return
        if (!shizukuGranted) {
            scope.launch {
                snackbarHostState.showSnackbar("需授予 Shizuku 权限")
            }
            return
        }

        val cmd = command.trim()
        command = ""

        scope.launch {
            isExecuting = true
            val result = executeShellCommand(cmd)
            commandHistory.add(CommandResult(cmd, result.first, result.second, result.third))
            isExecuting = false
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
                )
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "Shell 命令行",
                        description = "返回悦玺工具箱",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (!shizukuGranted) {
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Clear,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以启用 Shell 命令行",
                            isError = true
                        ) {}
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

                SettingSplicedColumnGroup(title = "命令输入") {
                item {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        OutlinedTextField(
                            value = command,
                            onValueChange = { command = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("输入 Shell 指令...") },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            keyboardOptions = KeyboardOptions(
                                imeAction = ImeAction.Send
                            ),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (command.isNotBlank() && shizukuGranted && !isExecuting) {
                                        executeCommand()
                                    }
                                }
                            ),
                            trailingIcon = {
                                IconButton(
                                    onClick = { executeCommand() },
                                    enabled = !isExecuting && command.isNotBlank() && shizukuGranted
                                ) {
                                    if (isExecuting) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(20.dp),
                                            strokeWidth = 2.dp
                                        )
                                    } else {
                                        Icon(Icons.AutoMirrored.Filled.Send, "执行")
                                    }
                                }
                            }
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            AssistChip(
                                onClick = { command = CommandTerminalPresets.PM_LIST },
                                enabled = shizukuGranted,
                                label = { Text("应用列表") }
                            )
                            AssistChip(
                                onClick = { command = CommandTerminalPresets.DUMPSYS_BATTERY },
                                enabled = shizukuGranted,
                                label = { Text("电池信息") }
                            )
                            AssistChip(
                                onClick = { command = CommandTerminalPresets.GETPROP },
                                enabled = shizukuGranted,
                                label = { Text("系统属性查询") }
                            )
                            AssistChip(
                                onClick = { command = CommandTerminalPresets.LOGCAT_TAIL },
                                enabled = shizukuGranted,
                                label = { Text("日志") }
                            )
                            AssistChip(
                                onClick = { command = CommandTerminalPresets.PS_A },
                                enabled = shizukuGranted,
                                label = { Text("进程") }
                            )
                            AssistChip(
                                onClick = { command = CommandTerminalPresets.CAT_MEMINFO },
                                enabled = shizukuGranted,
                                label = { Text("内存") }
                            )
                        }
                    }
                }
            }

            if (commandHistory.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "执行历史") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Clear,
                            title = "清除历史",
                            description = "清空所有执行记录",
                            onClick = { commandHistory.clear() }
                        ) {}
                    }

                    commandHistory.asReversed().forEach { result ->
                        item {
                            CommandResultItem(result = result)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }

    if (isExecuting) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceBright
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(48.dp),
                            strokeWidth = 4.dp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "正在执行指令...",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CommandResultItem(result: CommandResult) {
    Column(
        modifier = Modifier.padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (result.success) Icons.Default.PlayArrow else Icons.Default.Clear,
                contentDescription = null,
                tint = if (result.success) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "$ ${result.command}",
                style = MaterialTheme.typography.titleSmall,
                fontFamily = FontFamily.Monospace
            )
        }

        if (result.output.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            SelectionContainer {
                Text(
                    text = result.output,
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    color = if (result.success)
                        MaterialTheme.colorScheme.onSurface
                    else
                        MaterialTheme.colorScheme.onErrorContainer
                )
            }
        }

        if (result.error.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = result.error,
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}

data class CommandResult(
    val command: String,
    val output: String,
    val error: String,
    val success: Boolean
)

suspend fun executeShellCommand(command: String): Triple<String, String, Boolean> = withContext(Dispatchers.IO) {
    ShizukuExec.runShellCommand(command)
}
