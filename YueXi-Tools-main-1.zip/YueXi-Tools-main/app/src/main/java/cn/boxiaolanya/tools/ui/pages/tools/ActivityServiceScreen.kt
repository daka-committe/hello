/**
 * 实验功能：Activity / Service 的 dumpsys 调试入口。
 *
 * 支持 start-activity、start-service、stop-service、dumpsys activity 等命令组合。
 * 使用 [ActivityCommands] 与 [ServiceControlCommands]。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.shell.ActivityCommands
import cn.boxiaolanya.tools.utils.ShizukuExec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ActivityServiceScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val scope = rememberCoroutineScope()
    var output by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var target by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(0) }

    val hints = listOf(
        "com.vivo.abe/com.vivo.core.AbeCoreService",
        "com.vivo.abe/.KeepAliveService",
    )

    fun execute() {
        if (target.isBlank()) return
        scope.launch {
            isLoading = true
            output = withContext(Dispatchers.IO) {
                if (!shizukuGranted) return@withContext "需要 Shizuku 权限"
                val cmd = when (mode) {
                    0 -> ActivityCommands.startService(target)
                    1 -> ActivityCommands.stopService(target)
                    2 -> ActivityCommands.startActivityViaDumpsys(target)
                    else -> return@withContext "未知模式"
                }
                val (out, err, success) = ShizukuExec.runShellCommand(cmd)
                if (success) "成功" else "错误"
            }
            isLoading = false
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            SettingSplicedColumnGroup {
                item {
                    BaseWidget(icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "Activity 服务控制",
                        description = "返回高级调试",
                        onClick = { navController.navigateUp() }) {}
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            SettingSplicedColumnGroup(title = "操作模式") {
                item {
                    Column(modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = mode == 0,
                                onClick = { mode = 0 },
                                label = { Text("start-service") },
                                leadingIcon = { Icon(Icons.Default.PlayArrow, null, Modifier.size(16.dp)) },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = mode == 1,
                                onClick = { mode = 1 },
                                label = { Text("stop-service") },
                                leadingIcon = { Icon(Icons.Default.Stop, null, Modifier.size(16.dp)) },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = mode == 2,
                                onClick = { mode = 2 },
                                label = { Text("start-activity") },
                                leadingIcon = { Icon(Icons.Default.PlayArrow, null, Modifier.size(16.dp)) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            SettingSplicedColumnGroup(title = "目标组件") {
                item {
                    Column(modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        val label = when (mode) {
                            0 -> "com.package/.ServiceName"
                            1 -> "com.package/.ServiceName"
                            2 -> "com.package/.ActivityName"
                            else -> ""
                        }
                        OutlinedTextField(
                            value = target,
                            onValueChange = { target = it },
                            label = { Text(label) },
                            placeholder = { Text(hints[0]) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { execute() },
                                modifier = Modifier.weight(1f),
                                enabled = target.isNotBlank() && !isLoading
                            ) { Text("执行") }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            SettingSplicedColumnGroup(title = "快捷填充") {
                item {
                    Column(modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        hints.forEach { hint ->
                            OutlinedButton(onClick = { target = hint },
                                modifier = Modifier.fillMaxWidth()) { Text(hint) }
                        }
                    }
                }
            }

            if (output.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                SettingSplicedColumnGroup(title = "输出") {
                    item {
                        Column(modifier = Modifier.padding(16.dp)) {
                            SelectionContainer {
                                Text(text = output, style = MaterialTheme.typography.bodySmall,
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    item {
                        BaseWidget(icon = Icons.Default.Clear, title = "清空", onClick = { output = "" }) {}
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }

    if (isLoading) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        }
    }
}
