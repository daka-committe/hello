/**
 * 电量守护：触发 PEM 配置刷新与 iqoo 省电变更广播。
 *
 * 用于系统更新后异常耗电的修复入口；命令见 [BatteryGuardCommands]。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.pages.Screen
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup

@Composable
fun BatteryGuardScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "电量守护",
                        description = "返回高级调试",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            if (!shizukuGranted) {
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Apps,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以启用电量守护功能",
                            isError = true
                        ) {}
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "系统更新耗电修复") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Refresh,
                            title = "恢复系统更新后耗电异常",
                            description = "解决系统更新后的耗电异常问题",
                            onClick = { navController.navigate(Screen.BatteryGuardRestore.route) }
                        ) {}
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "PEM 命令") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.SystemUpdate,
                            title = "触发系统升级优化检查",
                            description = "系统升级优化检查",
                            onClick = { navController.navigate(Screen.PemSystemUpgradeCheck.route) }
                        ) {}
                    }
                    item {
                        BaseWidget(
                            icon = Icons.Default.Cloud,
                            title = "触发云端数据采集",
                            description = "云端数据采集",
                            onClick = { navController.navigate(Screen.PemCloudAction.route) }
                        ) {}
                    }
                    item {
                        BaseWidget(
                            icon = Icons.Default.Thermostat,
                            title = "模拟插件引擎发送温度状态",
                            description = "插件引擎温度状态",
                            onClick = { navController.navigate(Screen.PemTempStateChange.route) }
                        ) {}
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }
}
