/**
 * settings 三表（secure / system / global）的协程层封装。
 *
 * 在 [SettingsResolverAccess] 之上提供：
 * - IO 线程调度（避免主线程 query/insert）
 * - 统一的权限不足文案
 * - [putBurst] 批量写入入口
 *
 * 主要消费者：
 * - [cn.boxiaolanya.tools.ui.pages.tools.SettingsOptimizerScreen] 系统设置优化
 * - [cn.boxiaolanya.tools.rms.VivoRmsRepository] VIVO-RMS reason 读写
 */
package cn.boxiaolanya.tools.utils

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object SettingsContentAccess {

    /**
     * Android Settings Provider 的三张表，uri 与 adb `content query` 一致。
     */
    enum class Table(val uri: String) {
        /** 需 WRITE_SECURE_SETTINGS；含 vivo_rms_active_request_reason 等 */
        SECURE("content://settings/secure"),
        /** 部分厂商扩展项在 system 表 */
        SYSTEM("content://settings/system"),
        /** 全局配置，如 artpp_enabled */
        GLOBAL("content://settings/global"),
    }

    /**
     * [putBurst] 执行后的汇总。
     * @param successCount insert 未抛异常的次数
     * @param attemptCount 计划次数（已 coerce）
     * @param allOk successCount == attemptCount
     * @param lastMessage 最后一次写入的 detail，便于日志展示
     */
    data class BurstResult(
        val successCount: Int,
        val attemptCount: Int,
        val allOk: Boolean,
        val lastMessage: String,
    )

    /**
     * 将 Shell / UI 中的 namespace 字符串映射到 [Table]。
     * @return 无法识别时 null（如 typo "secur"）
     */
    fun tableForNamespace(namespace: String): Table? = when (namespace.lowercase()) {
        "secure" -> Table.SECURE
        "system" -> Table.SYSTEM
        "global" -> Table.GLOBAL
        else -> null
    }

    fun canWrite(context: Context): Boolean = SettingsResolverAccess.canWrite(context)

    /**
     * 异步读取 settings 值。
     * @return Pair(值或 null, 查询过程是否未抛异常)；SecurityException 时 second 为 false
     */
    suspend fun get(context: Context, table: Table, key: String): Pair<String?, Boolean> =
        withContext(Dispatchers.IO) {
            try {
                Pair(SettingsResolverAccess.get(context, table, key), true)
            } catch (_: SecurityException) {
                Pair(null, false)
            } catch (_: Exception) {
                Pair(null, false)
            }
        }

    /**
     * 异步写入单个 settings 项。
     * 无 WRITE_SECURE_SETTINGS 时直接返回失败 Pair，不发起 insert。
     */
    suspend fun put(context: Context, table: Table, key: String, value: String): Pair<String, Boolean> =
        withContext(Dispatchers.IO) {
            if (!canWrite(context)) {
                return@withContext Pair("需要 WRITE_SECURE_SETTINGS（与 VIVO-RMS 相同）", false)
            }
            val r = SettingsResolverAccess.put(context, table, key, value)
            Pair(r.detail, r.ok)
        }

    /**
     * 异步 burst 写入；RMS 界面「连写 N 次」走此入口。
     */
    suspend fun putBurst(context: Context, table: Table, key: String, value: String, times: Int): BurstResult =
        withContext(Dispatchers.IO) {
            if (!canWrite(context)) {
                val n = times.coerceIn(1, 64)
                return@withContext BurstResult(0, n, false, "需要 WRITE_SECURE_SETTINGS（与 VIVO-RMS 相同）")
            }
            SettingsResolverAccess.putBurst(context, table, key, value, times)
        }
}
