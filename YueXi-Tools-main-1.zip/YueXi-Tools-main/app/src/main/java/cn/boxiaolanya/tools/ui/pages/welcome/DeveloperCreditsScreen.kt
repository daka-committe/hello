package cn.boxiaolanya.tools.ui.pages.welcome

import android.graphics.BitmapFactory
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private const val ASSET_DEVELOPER = "fengqinglianyin.jpg"
private const val ASSET_TESTER = "yingying.jpg"

private data class TeamMember(
    val role: String,
    val name: String,
    val assetPath: String,
    val tips: List<String>,
)

private val teamMembers = listOf(
    TeamMember(
        role = "开发者",
        name = "风情恋吟",
        assetPath = ASSET_DEVELOPER,
        tips = listOf(
            "（请输入文本....）",
        ),
    ),
    TeamMember(
        role = "测试",
        name = "༄ઉ莹莹ঞ࿐",
        assetPath = ASSET_TESTER,
        tips = listOf(
            "测试......",
        ),
    ),
)

@Composable
fun DeveloperCreditsScreen(onEnterApp: () -> Unit) {
    val statusBarPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navBarPadding = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    var showHeader by remember { mutableStateOf(false) }
    var showCards by remember { mutableStateOf(false) }
    var showNote by remember { mutableStateOf(false) }
    var showButton by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        showHeader = true
        delay(120)
        showCards = true
        delay(180)
        showNote = true
        delay(140)
        showButton = true
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = statusBarPadding)
                .padding(bottom = navBarPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp),
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                CreditsEnterBlock(
                    visible = showHeader,
                    enterFromBottom = false,
                    fromStart = true,
                ) {
                    Text(
                        text = "开发团队",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = "感谢以下成员对本项目的支持",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp, bottom = 16.dp),
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    teamMembers.forEachIndexed { index, member ->
                        CreditsEnterBlock(
                            visible = showCards,
                            fromStart = index == 0,
                            modifier = Modifier.weight(1f),
                        ) {
                            TeamMemberCard(member = member)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                CreditsEnterBlock(
                    visible = showNote,
                    enterFromBottom = true,
                    fromStart = true,
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                        ),
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Text(
                                text = "致谢说明",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                text = "本页展示核心贡献者。点击「进入工具箱」开始使用全部功能。",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }

            CreditsEnterBlock(
                visible = showButton,
                enterFromBottom = true,
                fromStart = true,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Button(
                    onClick = onEnterApp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                ) {
                    Text("进入工具箱")
                }
            }
        }
    }
}

@Composable
private fun CreditsEnterBlock(
    visible: Boolean,
    modifier: Modifier = Modifier,
    fromStart: Boolean = true,
    enterFromBottom: Boolean = false,
    content: @Composable () -> Unit,
) {
    val horizontalEnter = slideInHorizontally(
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow,
        ),
        initialOffsetX = { fullWidth ->
            if (fromStart) -fullWidth / 5 else fullWidth / 5
        },
    )
    val verticalEnter = slideInVertically(
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow,
        ),
        initialOffsetY = { it / 4 },
    )
    val fadeScaleEnter = fadeIn(
        spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow,
        ),
    ) + scaleIn(
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow,
        ),
        initialScale = 0.92f,
    )

    AnimatedVisibility(
        visible = visible,
        enter = fadeScaleEnter +
            if (enterFromBottom) verticalEnter else horizontalEnter,
        modifier = modifier,
    ) {
        content()
    }
}

@Composable
private fun TeamMemberCard(member: TeamMember, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                text = member.role,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary,
            )
            Text(
                text = member.name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            AssetImage(
                assetPath = member.assetPath,
                imageHeight = 108.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp)),
                contentScale = ContentScale.Crop,
            )
            Text(
                text = "Tips · 评价",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp),
            )
            member.tips.forEachIndexed { index, tip ->
                TipsLine(
                    text = tip,
                    visibleDelayIndex = index,
                )
            }
        }
    }
}

@Composable
private fun TipsLine(text: String, visibleDelayIndex: Int) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(visibleDelayIndex) {
        delay(280L + visibleDelayIndex * 80L)
        visible = true
    }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(spring(stiffness = Spring.StiffnessMediumLow)) + slideInVertically(
            animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
            initialOffsetY = { it / 6 },
        ),
    ) {
        Text(
            text = "· $text",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun AssetImage(
    assetPath: String,
    modifier: Modifier = Modifier,
    imageHeight: Dp = 220.dp,
    contentScale: ContentScale = ContentScale.Crop,
) {
    val context = LocalContext.current
    var bitmap by remember(assetPath) { mutableStateOf<ImageBitmap?>(null) }
    var failed by remember(assetPath) { mutableStateOf(false) }

    LaunchedEffect(assetPath) {
        failed = false
        bitmap = withContext(Dispatchers.IO) {
            try {
                context.assets.open(assetPath).use { stream ->
                    BitmapFactory.decodeStream(stream)?.asImageBitmap()
                }
            } catch (_: Exception) {
                null
            }
        }
        if (bitmap == null) failed = true
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(imageHeight)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        AnimatedVisibility(
            visible = bitmap != null,
            enter = fadeIn(spring(stiffness = Spring.StiffnessMediumLow)) + scaleIn(
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                initialScale = 0.88f,
            ),
        ) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap!!,
                    contentDescription = assetPath,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = contentScale,
                )
            }
        }
        AnimatedVisibility(
            visible = failed,
            enter = fadeIn(spring(stiffness = Spring.StiffnessMediumLow)),
        ) {
            Text(
                text = "图片加载失败",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
            )
        }
        AnimatedVisibility(
            visible = bitmap == null && !failed,
            enter = fadeIn(spring(stiffness = Spring.StiffnessMediumLow)),
        ) {
            Text(
                text = "加载中…",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
