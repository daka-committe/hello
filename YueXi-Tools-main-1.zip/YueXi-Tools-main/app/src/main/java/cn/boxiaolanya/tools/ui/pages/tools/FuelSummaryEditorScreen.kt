/**
 * fuelsummary_uc.xml 数值编辑：上为完整配置名与说明，下为数值输入。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.fuel.FUEL_SUMMARY_ASSET
import cn.boxiaolanya.tools.fuel.FuelEditableField
import cn.boxiaolanya.tools.fuel.FuelSummaryDraft
import cn.boxiaolanya.tools.fuel.FuelSummaryFieldGuide
import cn.boxiaolanya.tools.fuel.FuelSummaryXmlCodec
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun FuelSummaryEditorScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var isLoading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var draft by remember { mutableStateOf<FuelSummaryDraft?>(null) }
    var editorRevision by remember { mutableIntStateOf(0) }
    var pendingExportXml by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/xml"),
    ) { targetUri ->
        val xmlPayload = pendingExportXml
        pendingExportXml = null

        if (targetUri == null || xmlPayload == null) return@rememberLauncherForActivityResult

        scope.launch {
            val written = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openOutputStream(targetUri)?.use { stream ->
                        stream.write(xmlPayload.toByteArray(Charsets.UTF_8))
                        true
                    } ?: false
                }.getOrDefault(false)
            }

            snackbarHostState.showSnackbar(
                if (written) "已保存为 $FUEL_SUMMARY_ASSET" else "保存失败，请重试",
            )
        }
    }

    fun reloadFromAssets() {
        scope.launch {
            isLoading = true
            loadError = null

            val loaded = withContext(Dispatchers.IO) {
                runCatching { FuelSummaryXmlCodec.loadFromAssets(context) }
            }

            loaded.fold(
                onSuccess = { draft = it },
                onFailure = { loadError = it.message ?: "读取内置配置失败" },
            )
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        reloadFromAssets()
    }

    fun commitExport() {
        val activeDraft = draft ?: return

        val validationFault = FuelSummaryXmlCodec.validate(activeDraft)
        if (validationFault != null) {
            scope.launch { snackbarHostState.showSnackbar(validationFault) }
            return
        }

        pendingExportXml = FuelSummaryXmlCodec.serialize(activeDraft)
        exportLauncher.launch(FUEL_SUMMARY_ASSET)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            color = MaterialTheme.colorScheme.surface,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(
                        top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding(),
                    ),
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup {
                    item {
                        BaseWidget(
                            icon = Icons.AutoMirrored.Filled.ArrowBack,
                            title = "电量摘要配置",
                            description = "改完可导出成文件，自行替换到系统目录",
                            onClick = { navController.navigateUp() },
                        ) {}
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                SettingSplicedColumnGroup(title = "操作") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.FileDownload,
                            title = "导出配置文件",
                            description = "检查数字无误后，选择保存位置",
                            enabled = draft != null && !isLoading,
                            onClick = { commitExport() },
                        ) {}
                    }
                    item {
                        BaseWidget(
                            icon = Icons.Default.RestartAlt,
                            title = "恢复默认",
                            description = "重新载入应用自带的原始数值",
                            enabled = !isLoading,
                            onClick = { reloadFromAssets() },
                        ) {}
                    }
                }

                when {
                    isLoading -> LoadingBlock()
                    loadError != null -> ErrorBlock(loadError.orEmpty())
                    draft != null -> EditorBody(
                        draft = draft!!,
                        revisionAnchor = editorRevision,
                        onVersionEdited = { text ->
                            draft!!.configVersionText = text
                            editorRevision++
                        },
                        onValueEdited = { editorRevision++ },
                        onExport = { commitExport() },
                    )
                }

                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun EditorBody(
    draft: FuelSummaryDraft,
    revisionAnchor: Int,
    onVersionEdited: (String) -> Unit,
    onValueEdited: () -> Unit,
    onExport: () -> Unit,
) {
    @Suppress("UNUSED_VARIABLE")
    val revisionTick = revisionAnchor

    Spacer(modifier = Modifier.height(12.dp))

    SectionIntro(title = "文件总览", summary = "最外层只有版本号可以改，名字固定为 fuelsummary_uc。")

    FuelConfigEditCard(
        configPath = "CONFIG / name=fuelsummary_uc / version",
        friendlyName = FuelSummaryFieldGuide.guideForConfigVersion().friendlyName,
        intro = FuelSummaryFieldGuide.guideForConfigVersion().intro,
        valueText = draft.configVersionText,
        valueLabel = "版本号",
        keyboardType = KeyboardType.Number,
        onValueEdited = onVersionEdited,
    )

    FuelSummaryFieldGuide.sectionGuides.forEach { (sectionKey, sectionGuide) ->
        val sectionFields = draft.fields.filter { it.sectionKey == sectionKey }
        if (sectionFields.isEmpty()) return@forEach

        Spacer(modifier = Modifier.height(16.dp))
        SectionIntro(title = sectionGuide.title, summary = sectionGuide.summary)

        sectionFields.forEach { field ->
            when (field) {
                is FuelEditableField.LoneInteger -> {
                    val guide = FuelSummaryFieldGuide.resolve(sectionKey, field.displayLabel)

                    FuelConfigEditCard(
                        configPath = FuelSummaryFieldGuide.fullConfigPath(
                            sectionKey,
                            field.displayLabel,
                            slotIndex = null,
                        ),
                        friendlyName = guide.friendlyName,
                        intro = guide.intro,
                        valueText = field.valueText,
                        valueLabel = "填写数值",
                        keyboardType = KeyboardType.Number,
                        onValueEdited = {
                            field.valueText = it
                            onValueEdited()
                        },
                    )
                }

                is FuelEditableField.TokenRow -> {
                    field.tokens.forEachIndexed { slotIndex, _ ->
                        val guide = resolveTokenGuide(field, sectionKey, slotIndex)

                        FuelConfigEditCard(
                            configPath = FuelSummaryFieldGuide.fullConfigPath(
                                sectionKey,
                                field.displayLabel,
                                slotIndex = slotIndex,
                            ),
                            friendlyName = guide.friendlyName,
                            intro = guide.intro,
                            valueText = field.tokens[slotIndex],
                            valueLabel = "填写数值",
                            keyboardType = if (field.isHexRow) {
                                KeyboardType.Ascii
                            } else {
                                KeyboardType.Number
                            },
                            onValueEdited = { freshToken ->
                                field.tokens[slotIndex] = freshToken
                                onValueEdited()
                            },
                        )
                    }
                }
            }
        }
    }

    Spacer(modifier = Modifier.height(16.dp))

    Button(
        onClick = onExport,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
    ) {
        Text("导出配置文件")
    }
}

private fun resolveTokenGuide(
    field: FuelEditableField.TokenRow,
    sectionKey: String,
    slotIndex: Int,
) = if (field.isHexRow) {
    FuelSummaryFieldGuide.guideForHexArray(slotIndex, field.tokens.size)
} else {
    FuelSummaryFieldGuide.resolve(sectionKey, field.displayLabel, slotIndex)
}

@Composable
private fun SectionIntro(title: String, summary: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = summary,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun FuelConfigEditCard(
    configPath: String,
    friendlyName: String,
    intro: String,
    valueText: String,
    valueLabel: String,
    keyboardType: KeyboardType,
    onValueEdited: (String) -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
        ) {
            Text(
                text = "配置项",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = configPath,
                style = MaterialTheme.typography.bodyMedium,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.onSurface,
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = friendlyName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = intro,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f),
            )
            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = valueText,
                onValueChange = onValueEdited,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text(valueLabel) },
                keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            )
        }
    }
}

@Composable
private fun LoadingBlock() {
    Spacer(modifier = Modifier.height(48.dp))

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CircularProgressIndicator()
        Spacer(modifier = Modifier.height(12.dp))
        Text("正在读取配置…", style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun ErrorBlock(message: String) {
    Spacer(modifier = Modifier.height(24.dp))

    Text(
        text = message,
        modifier = Modifier.padding(horizontal = 20.dp),
        color = MaterialTheme.colorScheme.error,
    )
}
