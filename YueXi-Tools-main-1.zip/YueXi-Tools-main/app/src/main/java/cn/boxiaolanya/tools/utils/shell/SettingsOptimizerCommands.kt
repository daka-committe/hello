/**
 * 系统设置优化页使用的 settings 键名与 dumpsys 命令常量。
 */
package cn.boxiaolanya.tools.utils.shell

import cn.boxiaolanya.tools.utils.SettingsContentAccess

object SettingsOptimizerCommands {

    data class SettingSpec(val table: SettingsContentAccess.Table, val key: String)

    val BBK_UPDATE = SettingSpec(SettingsContentAccess.Table.SYSTEM, "bbk_update_notice")
    val AI_TURBO = SettingSpec(SettingsContentAccess.Table.SYSTEM, "ai_turbo_enabled")
    val ARTPP = SettingSpec(SettingsContentAccess.Table.GLOBAL, "artpp_enabled")
    val MATCH_FRAME_RATE = SettingSpec(SettingsContentAccess.Table.GLOBAL, "match_content_frame_rate")
    val NATIVE_FLAGS_HEALTH = SettingSpec(SettingsContentAccess.Table.GLOBAL, "native_flags_health_check_enabled")
    val BIG_DATA_SWITCH = SettingSpec(SettingsContentAccess.Table.SYSTEM, "big_data_switch")
    val ABE_UNIFIED_SWITCH = SettingSpec(SettingsContentAccess.Table.SECURE, "abe_unified_switch")
    val GAMECUBE_VERSION_NO = SettingSpec(SettingsContentAccess.Table.GLOBAL, "gamecube_version_no")

    val DUMPSYS: String get() = ShellObf.s("opt.dumpsys_prefix")
    val SURFACE_FLINGER: String get() = ShellObf.s("opt.surface_flinger")
    val LATENCY_CLEAR: String get() = ShellObf.s("opt.latency_clear")
    val SET_GAMECUBE_VERSION: String get() = ShellObf.s("perf.set_gamecube_version")
}
