/**
 * 系统设置优化：读写 [SettingsOptimizerCommands] 定义的 hidden settings 项。
 *
 * 经 [SettingsContentAccess]；开关类 UI 使用 setting 组件库。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSwitchWidget
import cn.boxiaolanya.tools.rms.VivoRmsRepository
import cn.boxiaolanya.tools.utils.SecureSettingsAccess
import cn.boxiaolanya.tools.utils.SettingsContentAccess
import cn.boxiaolanya.tools.utils.SettingsPermissionBootstrap
import cn.boxiaolanya.tools.utils.ShizukuHelper
import cn.boxiaolanya.tools.utils.shell.SettingsOptimizerCommands
import cn.boxiaolanya.tools.utils.shell.ShellFormat
import cn.boxiaolanya.tools.utils.ShizukuExec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsOptimizerScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var updateNoticeEnabled by remember { mutableStateOf(false) }
    var aiTurboEnabled by remember { mutableStateOf(false) }
    var artppEnabled by remember { mutableStateOf(false) }
    var matchFrameRateEnabled by remember { mutableStateOf(false) }
    var nativeFlagsHealthCheckEnabled by remember { mutableStateOf(false) }
    var bigDataSwitchEnabled by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var canUse by remember { mutableStateOf(SettingsContentAccess.canWrite(context)) }

    suspend fun refreshPermissionAndStates() {
        if (ShizukuHelper.isGranted()) {
            SettingsPermissionBootstrap.ensure(context)
        }
        canUse = SettingsContentAccess.canWrite(context)
        val states = getAllSettingsState(context)
        updateNoticeEnabled = states[0]
        aiTurboEnabled = states[1]
        artppEnabled = states[2]
        matchFrameRateEnabled = states[3]
        nativeFlagsHealthCheckEnabled = states[4]
        bigDataSwitchEnabled = states[5]
    }

    LaunchedEffect(Unit) {
        isLoading = true
        refreshPermissionAndStates()
        isLoading = false
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
                )
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "系统设置优化",
                        description = "返回悦玺工具箱",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (!canUse) {
                SettingSplicedColumnGroup(title = "写入权限") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Settings,
                            title = "与 VIVO-RMS 相同授权",
                            description = "需要 WRITE_SECURE_SETTINGS。进入 App 时 Shizuku 会自动 pm grant。\n${SecureSettingsAccess.adbGrantCommand(context.packageName)}",
                            isError = true,
                        ) {}
                    }
                }
            }

            SettingSplicedColumnGroup(title = "系统优化") {
                    item {
                        SettingSwitchWidget(
                            title = "系统更新提示",
                            description = if (updateNoticeEnabled) "已隐藏系统更新红点" else "显示系统更新红点",
                            checked = updateNoticeEnabled,
                            isM3E = true,
                            iconPlaceholder = false,
                            onCheckedChange = { checked ->
                                isLoading = true
                                scope.launch {
                                    val result = putSetting(
                                        context,
                                        SettingsOptimizerCommands.BBK_UPDATE,
                                        if (checked) "0" else "1",
                                    )
                                    isLoading = false
                                    if (result) {
                                        updateNoticeEnabled = checked
                                        snackbarHostState.showSnackbar(
                                            if (checked) "已隐藏系统更新红点" else "已显示系统更新红点"
                                        )
                                    } else {
                                        snackbarHostState.showSnackbar(
                                            writeFailHint(SettingsOptimizerCommands.BBK_UPDATE),
                                        )
                                    }
                                }
                            }
                        )
                    }
                    item {
                        SettingSwitchWidget(
                            title = "AI 加速引擎",
                            description = if (aiTurboEnabled) "AI 加速已启用" else "AI 加速已停用",
                            checked = aiTurboEnabled,
                            isM3E = true,
                            iconPlaceholder = false,
                            onCheckedChange = { checked ->
                                isLoading = true
                                scope.launch {
                                    val result = putSetting(
                                        context,
                                        SettingsOptimizerCommands.AI_TURBO,
                                        if (checked) "1" else "0",
                                    )
                                    isLoading = false
                                    if (result) {
                                        aiTurboEnabled = checked
                                        snackbarHostState.showSnackbar(
                                            if (checked) "AI 加速已启用" else "AI 加速已停用"
                                        )
                                    } else {
                                        snackbarHostState.showSnackbar(
                                            writeFailHint(SettingsOptimizerCommands.AI_TURBO),
                                        )
                                    }
                                }
                            }
                        )
                    }
                    item {
                        SettingSwitchWidget(
                            title = "ART 编译优化",
                            description = if (artppEnabled) "ART 编译优化已启用" else "ART 编译优化已停用",
                            checked = artppEnabled,
                            isM3E = true,
                            iconPlaceholder = false,
                            onCheckedChange = { checked ->
                                isLoading = true
                                scope.launch {
                                    val result = putSetting(
                                        context,
                                        SettingsOptimizerCommands.ARTPP,
                                        if (checked) "1" else "0",
                                    )
                                    isLoading = false
                                    if (result) {
                                        artppEnabled = checked
                                        snackbarHostState.showSnackbar(
                                            if (checked) "ART 编译优化已启用" else "ART 编译优化已停用"
                                        )
                                    } else {
                                        snackbarHostState.showSnackbar(
                                            writeFailHint(SettingsOptimizerCommands.ARTPP),
                                        )
                                    }
                                }
                            }
                        )
                    }
                    item {
                        SettingSwitchWidget(
                            title = "屏幕刷新率匹配",
                            description = if (matchFrameRateEnabled) "屏幕刷新率匹配已启用" else "屏幕刷新率匹配已停用",
                            checked = matchFrameRateEnabled,
                            isM3E = true,
                            iconPlaceholder = false,
                            onCheckedChange = { checked ->
                                isLoading = true
                                scope.launch {
                                    val result = putSetting(
                                        context,
                                        SettingsOptimizerCommands.MATCH_FRAME_RATE,
                                        if (checked) "1" else "0",
                                    )
                                    isLoading = false
                                    if (result) {
                                        matchFrameRateEnabled = checked
                                        snackbarHostState.showSnackbar(
                                            if (checked) "屏幕刷新率匹配已启用" else "屏幕刷新率匹配已停用"
                                        )
                                    } else {
                                        snackbarHostState.showSnackbar(
                                            writeFailHint(SettingsOptimizerCommands.MATCH_FRAME_RATE),
                                        )
                                    }
                                }
                            }
                        )
                    }
                    item {
                        SettingSwitchWidget(
                            title = "Native Flags 检查",
                            description = if (nativeFlagsHealthCheckEnabled) "Native Flags 健康检查已启用" else "Native Flags 健康检查已停用",
                            checked = nativeFlagsHealthCheckEnabled,
                            isM3E = true,
                            iconPlaceholder = false,
                            onCheckedChange = { checked ->
                                isLoading = true
                                scope.launch {
                                    val result = putSetting(
                                        context,
                                        SettingsOptimizerCommands.NATIVE_FLAGS_HEALTH,
                                        if (checked) "1" else "0",
                                    )
                                    isLoading = false
                                    if (result) {
                                        nativeFlagsHealthCheckEnabled = checked
                                        snackbarHostState.showSnackbar(
                                            if (checked) "Native Flags 检查已启用" else "Native Flags 检查已停用"
                                        )
                                    } else {
                                        snackbarHostState.showSnackbar(
                                            writeFailHint(SettingsOptimizerCommands.NATIVE_FLAGS_HEALTH),
                                        )
                                    }
                                }
                            }
                        )
                    }
                    item {
                        SettingSwitchWidget(
                            title = "大数据收集",
                            description = if (bigDataSwitchEnabled) "大数据收集已禁用" else "大数据收集已启用",
                            checked = bigDataSwitchEnabled,
                            isM3E = true,
                            iconPlaceholder = false,
                            onCheckedChange = { checked ->
                                isLoading = true
                                scope.launch {
                                    val result = putSetting(
                                        context,
                                        SettingsOptimizerCommands.BIG_DATA_SWITCH,
                                        if (checked) "0" else "1",
                                    )
                                    isLoading = false
                                    if (result) {
                                        bigDataSwitchEnabled = checked
                                        snackbarHostState.showSnackbar(if (checked) "大数据收集已禁用" else "大数据收集已启用")
                                    } else {
                                        snackbarHostState.showSnackbar(
                                            writeFailHint(SettingsOptimizerCommands.BIG_DATA_SWITCH),
                                        )
                                    }
                                }
                            }
                        )
                    }
                    item {
                        BaseWidget(
                            title = "重置帧率统计",
                            description = "清空 SurfaceFlinger 帧率统计数据",
                            iconPlaceholder = false,
                            onClick = {
                                scope.launch {
                                    isLoading = true
                                    val result = executeDumpsysCommand(
                                        SettingsOptimizerCommands.SURFACE_FLINGER,
                                        SettingsOptimizerCommands.LATENCY_CLEAR
                                    )
                                    isLoading = false
                                    snackbarHostState.showSnackbar(
                                        if (result) "帧率统计已重置" else "dumpsys 命令执行失败"
                                    )
                                }
                            }
                        ) {}
                    }
                }

            SettingSplicedColumnGroup(title = "游戏魔盒") {
                    item {
                        BaseWidget(
                            title = "修改游戏魔盒版本号",
                            description = "将 gamecube_version_no 设置为 999999",
                            iconPlaceholder = false,
                            onClick = {
                                scope.launch {
                                    isLoading = true
                                    val cmd = ShellFormat.fmt(SettingsOptimizerCommands.SET_GAMECUBE_VERSION, "999999")
                                    val result = withContext(Dispatchers.IO) {
                                        try {
                                            val (output, success) = ShizukuExec.runCommandWithOutput(cmd)
                                            success
                                        } catch (e: Exception) {
                                            false
                                        }
                                    }
                                    isLoading = false
                                    if (result) {
                                        snackbarHostState.showSnackbar("游戏魔盒版本号已修改为 999999")
                                    } else {
                                        snackbarHostState.showSnackbar("修改失败，请确认 Shizuku 权限已授予")
                                    }
                                }
                            }
                        ) {}
                    }
                }

            Spacer(modifier = Modifier.height(WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }

    if (isLoading) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceBright
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(48.dp),
                            strokeWidth = 4.dp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "正在执行操作...",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }
}

private fun writeFailHint(spec: SettingsOptimizerCommands.SettingSpec): String {
    val table = when (spec.table) {
        SettingsContentAccess.Table.SYSTEM -> "system"
        SettingsContentAccess.Table.GLOBAL -> "global"
        SettingsContentAccess.Table.SECURE -> "secure"
    }
    return "写入失败（$table/${spec.key}），请确认对应权限已授予"
}

private suspend fun putSetting(
    context: android.content.Context,
    spec: SettingsOptimizerCommands.SettingSpec,
    value: String,
): Boolean {
    if (!SettingsContentAccess.canWrite(context)) return false
    val burst = SettingsContentAccess.putBurst(
        context,
        spec.table,
        spec.key,
        value,
        VivoRmsRepository.DEFAULT_BURST_COUNT,
    )
    return burst.allOk
}

private suspend fun executeDumpsysCommand(vararg args: String): Boolean = withContext(Dispatchers.IO) {
    try {
        val cmdArray = listOf(SettingsOptimizerCommands.DUMPSYS) + args
        val result = ShizukuExec.runCommandWithOutput(*cmdArray.toTypedArray())
        result.second
    } catch (e: Exception) {
        false
    }
}

private suspend fun getAllSettingsState(context: android.content.Context): List<Boolean> = withContext(Dispatchers.IO) {
    listOf(
        getSettingState(context, SettingsOptimizerCommands.BBK_UPDATE, false),
        getSettingState(context, SettingsOptimizerCommands.AI_TURBO, false),
        getSettingState(context, SettingsOptimizerCommands.ARTPP, false),
        getSettingState(context, SettingsOptimizerCommands.MATCH_FRAME_RATE, false),
        getSettingState(context, SettingsOptimizerCommands.NATIVE_FLAGS_HEALTH, false),
        getSettingState(context, SettingsOptimizerCommands.BIG_DATA_SWITCH, false),
    )
}

private suspend fun getSettingState(
    context: android.content.Context,
    spec: SettingsOptimizerCommands.SettingSpec,
    defaultValue: Boolean,
): Boolean {
    return try {
        val (value, ok) = SettingsContentAccess.get(context, spec.table, spec.key)
        if (ok) {
            val v = value?.trim().orEmpty()
            v == "1" || v.equals("true", ignoreCase = true)
        } else {
            defaultValue
        }
    } catch (_: Exception) {
        defaultValue
    }
}
