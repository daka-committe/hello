/**
 * VIVO-RMS 主界面：reason 构造/解析、burst 写入、读回验证、后台 [VivoRmsMonitorService]。
 *
 * 状态来自 [VivoRmsRuntime] StateFlow；配置持久化在 DataStore。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.edit
import androidx.navigation.NavController
import cn.boxiaolanya.tools.rms.RmsBuilderKind
import cn.boxiaolanya.tools.rms.RmsReadMode
import cn.boxiaolanya.tools.rms.VivoRmsReasonBuilder
import cn.boxiaolanya.tools.rms.VivoRmsRepository
import cn.boxiaolanya.tools.rms.VivoRmsRuntime
import cn.boxiaolanya.tools.service.VivoRmsMonitorService
import cn.boxiaolanya.tools.ui.settings.AppDataStore
import cn.boxiaolanya.tools.ui.settings.dataStore
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.SecureSettingsAccess
import cn.boxiaolanya.tools.utils.SettingsPermissionBootstrap
import cn.boxiaolanya.tools.utils.ShizukuHelper
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
/**
 * VIVO-RMS 主界面根 Composable。
 *
 * 表单字段与 DataStore 双向同步；[builtReason] 实时预览；
 * 「单次连写」走 Repository，「后台循环」启停 [VivoRmsMonitorService]。
 */
fun VivoRmsScreen(
    @Suppress("UNUSED_PARAMETER") shizukuGranted: Boolean,
    navController: NavController,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // --- 写入模板表单状态（与 DataStore 键一一对应）---
    var packageName by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(RmsBuilderKind.GAME_SDK) }
    var kindExpanded by remember { mutableStateOf(false) }
    var useOverride by remember { mutableStateOf(false) }
    var useVsync by remember { mutableStateOf(false) }
    var temperature by remember { mutableStateOf("38.0") }
    var activity by remember { mutableStateOf("") }
    var fps by remember { mutableStateOf("120") }
    var intervalMs by remember { mutableFloatStateOf(VivoRmsRuntime.DEFAULT_INTERVAL_MS.toFloat()) }
    var burstCount by remember { mutableFloatStateOf(VivoRmsRepository.DEFAULT_BURST_COUNT.toFloat()) }
    var bgLoop by remember { mutableStateOf(false) }
    var writingOnce by remember { mutableStateOf(false) }

    // --- 后台 Service 写入结果，供只读展示 ---
    val latest by VivoRmsRuntime.latest.collectAsState()
    val matched by VivoRmsRuntime.packageMatched.collectAsState()
    val pollCount by VivoRmsRuntime.pollCount.collectAsState()
    val lastError by VivoRmsRuntime.lastError.collectAsState()
    val serviceRunning by VivoRmsRuntime.serviceRunning.collectAsState()
    val lastBurstOk by VivoRmsRuntime.lastBurstOk.collectAsState()
    val lastBurstTotal by VivoRmsRuntime.lastBurstTotal.collectAsState()

    var readMode by remember { mutableStateOf(VivoRmsRepository.readMode(context)) }
    val canUse = readMode != RmsReadMode.NONE

    // 进入页：Shizuku grant secure 权限并刷新 readMode
    LaunchedEffect(Unit) {
        if (ShizukuHelper.isGranted()) {
            SettingsPermissionBootstrap.ensure(context)
        }
        readMode = VivoRmsRepository.readMode(context)
    }

    // 表单变更时实时预览即将写入 secure 的 reason 字符串
    val builtReason = remember(packageName, kind, useOverride, useVsync, temperature, activity, fps) {
        VivoRmsReasonBuilder.build(kind, packageName, useOverride, useVsync, activity, temperature, fps)
    }

    // 从 DataStore 恢复上次配置；若用户曾开启后台监控则自动 start Service
    LaunchedEffect(Unit) {
        val prefs = context.dataStore.data.first()
        packageName = prefs[AppDataStore.RMS_TARGET_PACKAGE] ?: ""
        kind = VivoRmsReasonBuilder.kindFromStored(prefs[AppDataStore.RMS_REASON_KIND] ?: "")
        useOverride = prefs[AppDataStore.RMS_USE_OVERRIDE] ?: false
        useVsync = prefs[AppDataStore.RMS_USE_VSYNC] ?: false
        intervalMs = (prefs[AppDataStore.RMS_POLL_INTERVAL_MS] ?: VivoRmsRuntime.DEFAULT_INTERVAL_MS).toFloat()
        burstCount = (prefs[AppDataStore.RMS_BURST_WRITE_COUNT] ?: VivoRmsRepository.DEFAULT_BURST_COUNT).toFloat()
        temperature = prefs[AppDataStore.RMS_THERMAL_TEMP] ?: "38.0"
        activity = prefs[AppDataStore.RMS_ACTIVITY] ?: ""
        fps = prefs[AppDataStore.RMS_FPS] ?: "120"
        bgLoop = prefs[AppDataStore.RMS_BG_MONITOR_ENABLED] ?: false
        VivoRmsRuntime.setWatchPackage(packageName)
        VivoRmsRuntime.setServiceRunning(VivoRmsMonitorService.isRunning(context))
        if (bgLoop && canUse && !VivoRmsMonitorService.isRunning(context)) {
            VivoRmsMonitorService.start(context)
        }
    }

    fun persistConfig() {
        scope.launch {
            context.dataStore.edit { prefs ->
                prefs[AppDataStore.RMS_TARGET_PACKAGE] = packageName.trim()
                prefs[AppDataStore.RMS_REASON_KIND] = kind.name
                prefs[AppDataStore.RMS_USE_OVERRIDE] = useOverride
                prefs[AppDataStore.RMS_USE_VSYNC] = useVsync
                prefs[AppDataStore.RMS_POLL_INTERVAL_MS] = intervalMs.toLong()
                prefs[AppDataStore.RMS_BURST_WRITE_COUNT] = burstCount.toInt()
                prefs[AppDataStore.RMS_THERMAL_TEMP] = temperature
                prefs[AppDataStore.RMS_ACTIVITY] = activity
                prefs[AppDataStore.RMS_FPS] = fps
                prefs[AppDataStore.RMS_BG_MONITOR_ENABLED] = bgLoop
            }
            VivoRmsRuntime.setWatchPackage(packageName)
        }
    }

    fun setBackgroundLoop(on: Boolean) {
        bgLoop = on
        persistConfig()
        if (!canUse) return
        if (on) {
            VivoRmsMonitorService.start(context)
        } else {
            VivoRmsMonitorService.stop(context)
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()),
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "VIVO-RMS",
                        description = "循环 content 连写 active request reason",
                        onClick = { navController.navigateUp() },
                    ) {}
                }
            }

            if (!canUse) {
                Spacer(modifier = Modifier.height(12.dp))
                SettingSplicedColumnGroup {
                    item {
                        Text(
                            modifier = Modifier.padding(16.dp),
                            text = "需要 adb 授予 WRITE_SECURE_SETTINGS，写入方式与 SetEdit 相同：ContentResolver.insert(content://settings/secure)。\n${SecureSettingsAccess.adbGrantCommand(context.packageName)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            SettingSplicedColumnGroup(title = "目标应用") {
                item {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = packageName,
                            onValueChange = {
                                packageName = it
                                persistConfig()
                            },
                            label = { Text("包名") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            placeholder = { Text("com.tencent.tmgp.sgame") },
                            enabled = canUse,
                        )
                        ExposedDropdownMenuBox(
                            expanded = kindExpanded,
                            onExpandedChange = { kindExpanded = it },
                        ) {
                            OutlinedTextField(
                                value = kind.label,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Reason 类型") },
                                modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable, true),
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(kindExpanded) },
                                enabled = canUse,
                            )
                            ExposedDropdownMenu(expanded = kindExpanded, onDismissRequest = { kindExpanded = false }) {
                                RmsBuilderKind.entries.forEach { k ->
                                    DropdownMenuItem(
                                        text = { Text(k.label) },
                                        onClick = {
                                            kind = k
                                            kindExpanded = false
                                            persistConfig()
                                        },
                                    )
                                }
                            }
                        }
                        if (kind == RmsBuilderKind.GAME_SDK || kind == RmsBuilderKind.SETTING) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = useOverride, onCheckedChange = { useOverride = it; persistConfig() }, enabled = canUse)
                                Text("override", style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.weight(1f))
                                Checkbox(checked = useVsync, onCheckedChange = { useVsync = it; persistConfig() }, enabled = canUse)
                                Text("vsyncImd", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        if (kind == RmsBuilderKind.THERMAL) {
                            OutlinedTextField(
                                value = temperature,
                                onValueChange = { temperature = it; persistConfig() },
                                label = { Text("温度") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                enabled = canUse,
                            )
                        }
                        if (kind == RmsBuilderKind.WINDOW_MIN || kind == RmsBuilderKind.WINDOW_MAX) {
                            OutlinedTextField(
                                value = activity,
                                onValueChange = { activity = it; persistConfig() },
                                label = { Text("Activity（可空）") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                enabled = canUse,
                            )
                            OutlinedTextField(
                                value = fps,
                                onValueChange = { fps = it; persistConfig() },
                                label = { Text("FPS/Hz") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                enabled = canUse,
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            SettingSplicedColumnGroup(title = "写入目标 Reason") {
                item {
                    Column(Modifier.padding(16.dp)) {
                        SelectionContainer {
                            Text(
                                builtReason.ifBlank { "请先填写包名" },
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            SettingSplicedColumnGroup(title = "连写参数") {
                item {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        val modeHint = when (readMode) {
                            RmsReadMode.CONTENT_RESOLVER -> "SetEdit · ContentResolver.insert"
                            RmsReadMode.NONE -> "未授予 WRITE_SECURE_SETTINGS"
                        }
                        Text(
                            "通道：$modeHint · 单次连写 ${burstCount.toInt()} 次",
                            style = MaterialTheme.typography.labelMedium,
                        )
                        Slider(
                            value = burstCount,
                            onValueChange = {
                                burstCount = it
                                persistConfig()
                            },
                            valueRange = VivoRmsRepository.MIN_BURST_COUNT.toFloat()..VivoRmsRepository.MAX_BURST_COUNT.toFloat(),
                            steps = VivoRmsRepository.MAX_BURST_COUNT - VivoRmsRepository.MIN_BURST_COUNT - 1,
                            enabled = canUse,
                        )
                        Text(
                            "循环间隔 ${intervalMs.toLong()} ms",
                            style = MaterialTheme.typography.labelMedium,
                        )
                        Slider(
                            value = intervalMs,
                            onValueChange = {
                                intervalMs = it
                                persistConfig()
                            },
                            valueRange = 200f..3000f,
                            steps = 27,
                            enabled = canUse,
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("后台循环连写")
                                Text(
                                    if (serviceRunning) {
                                        "服务运行中 · 上次 $lastBurstOk/$lastBurstTotal"
                                    } else {
                                        "每轮连写 ${burstCount.toInt()} 次后读回校验"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Switch(
                                checked = bgLoop && serviceRunning,
                                onCheckedChange = { setBackgroundLoop(it) },
                                enabled = canUse && builtReason.isNotBlank(),
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    if (builtReason.isBlank()) return@Button
                                    writingOnce = true
                                    scope.launch {
                                        try {
                                            val config = VivoRmsRepository.loadWriteConfig(context).copy(
                                                packageName = packageName.trim(),
                                                kind = kind,
                                                useOverride = useOverride,
                                                useVsync = useVsync,
                                                temperature = temperature,
                                                activity = activity,
                                                fps = fps,
                                                burstCount = burstCount.toInt(),
                                            )
                                            val result = VivoRmsRepository.writeBurstAndVerify(context, config)
                                            VivoRmsRuntime.publishWriteCycle(result, packageName.trim())
                                        } finally {
                                            writingOnce = false
                                        }
                                    }
                                },
                                enabled = canUse && builtReason.isNotBlank() && !writingOnce,
                            ) { Text(if (writingOnce) "连写中…" else "连写一次") }
                            OutlinedButton(
                                onClick = {
                                    scope.launch {
                                        val snap = VivoRmsRepository.snapshot(context)
                                        VivoRmsRuntime.publish(snap, packageName.trim(), appendHistory = true)
                                    }
                                },
                                enabled = canUse && !writingOnce,
                            ) { Text("仅读取") }
                            OutlinedButton(onClick = { VivoRmsRuntime.clearHistory() }) { Text("清空") }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            SettingSplicedColumnGroup(title = "当前系统值") {
                item {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            "循环 $pollCount 轮 · 上次连写 $lastBurstOk/$lastBurstTotal",
                            style = MaterialTheme.typography.labelSmall,
                        )
                        if (packageName.isNotBlank()) {
                            Text(
                                if (matched) "已匹配包名 $packageName" else "未匹配包名 $packageName",
                                color = if (matched) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                        lastError?.let {
                            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                        SelectionContainer {
                            Text(
                                latest?.raw ?: "（空）",
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                        latest?.parsed?.summary?.let {
                            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }
}
