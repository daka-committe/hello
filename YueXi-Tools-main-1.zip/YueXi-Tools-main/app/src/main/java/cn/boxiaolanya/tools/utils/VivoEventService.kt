/**
 * vivo_event_service Binder：注册 PEM 事件回调。
 */
package cn.boxiaolanya.tools.utils

import android.os.Binder
import android.os.IBinder
import android.os.Parcel

object VivoEventService {

    private const val SERVICE_NAME = "vivo_event_service"
    private const val DESCRIPTOR = "vivo.app.pem.IVivoEventService"
    private const val CALLBACK_DESCRIPTOR = "vivo.app.pem.IVivoEventCallback"
    private const val TRANSACTION_REGISTER = 1
    private const val TRANSACTION_UNREGISTER = 2
    private const val TRANSACTION_CALLBACK = 1

    private var mBinder: IBinder? = null
    private var mCallback: EventCallbackBinder? = null

    val isAvailable: Boolean
        get() {
            if (mBinder == null) connect()
            return mBinder != null
        }

    fun connect(): String {
        return try {
            val sm = Class.forName("android.os.ServiceManager")
            val m = sm.getDeclaredMethod("getService", String::class.java)
            mBinder = m.invoke(null, SERVICE_NAME) as? IBinder
            if (mBinder != null) "connected" else "service not found"
        } catch (e: Exception) { "fail: ${e.message}" }
    }

    fun registerEvents(
        tag: String,
        events: Array<String>,
        onEvent: (event: String, content: String) -> Unit
    ): String {
        val b = mBinder ?: return "not connected"
        mCallback = EventCallbackBinder(onEvent)
        return try {
            val data = Parcel.obtain()
            val reply = Parcel.obtain()
            data.writeInterfaceToken(DESCRIPTOR)
            data.writeString(tag)
            data.writeStringArray(events)
            data.writeStrongBinder(mCallback!!)
            b.transact(TRANSACTION_REGISTER, data, reply, 0)
            reply.readException()
            data.recycle(); reply.recycle()
            "registered"
        } catch (e: Exception) { "fail: ${e.message}" }
    }

    fun unregisterEvents(): String {
        val b = mBinder ?: return "not connected"
        val cb = mCallback ?: return "not registered"
        return try {
            val data = Parcel.obtain()
            val reply = Parcel.obtain()
            data.writeInterfaceToken(DESCRIPTOR)
            data.writeStrongBinder(cb)
            b.transact(TRANSACTION_UNREGISTER, data, reply, 0)
            reply.readException()
            data.recycle(); reply.recycle()
            mCallback = null
            "unregistered"
        } catch (e: Exception) { "fail: ${e.message}" }
    }

    private class EventCallbackBinder(
        private val onEvent: (String, String) -> Unit
    ) : Binder() {
        override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
            if (code == TRANSACTION_CALLBACK) {
                data.enforceInterface(CALLBACK_DESCRIPTOR)
                val event = data.readString()
                val content = data.readString()
                onEvent(event ?: "", content ?: "")
                return true
            }
            return super.onTransact(code, data, reply, flags)
        }
    }

    val KNOWN_EVENTS = listOf(
        "POWER_ID_AUDIO_STATE",
        "POWER_ID_VIDEO_STATE",
        "POWER_ID_RECORD_STATE",
        "POWER_ID_GPS",
    )
}
