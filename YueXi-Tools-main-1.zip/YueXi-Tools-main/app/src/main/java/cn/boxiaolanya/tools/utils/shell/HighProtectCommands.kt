package cn.boxiaolanya.tools.utils.shell

object HighProtectCommands {
    val CLOSE_HIGH_PROTECT_PREFIX: String get() = ShellObf.s("hp.close_prefix")
}
