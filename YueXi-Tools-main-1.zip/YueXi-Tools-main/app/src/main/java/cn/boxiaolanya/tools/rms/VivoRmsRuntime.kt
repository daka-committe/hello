/**
 * VIVO-RMS 后台监控与 UI 共享的运行时状态（进程内单例 StateFlow）。
 *
 * [cn.boxiaolanya.tools.service.VivoRmsMonitorService] 轮询后调用 [publish] / [publishWriteCycle]；
 * [cn.boxiaolanya.tools.ui.pages.tools.VivoRmsScreen] collect 这些 Flow 刷新界面。
 *
 * 注意：状态不跨进程；Service 与 Activity 同进程时有效。
 */
package cn.boxiaolanya.tools.rms

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

object VivoRmsRuntime {

    /** 历史快照列表上限，超出丢弃最旧 */
    const val MAX_HISTORY = 50

    /** 默认轮询间隔，与 DataStore 默认一致 */
    const val DEFAULT_INTERVAL_MS = 500L

    private val _serviceRunning = MutableStateFlow(false)
    val serviceRunning: StateFlow<Boolean> = _serviceRunning.asStateFlow()

    private val _latest = MutableStateFlow<RmsSnapshot?>(null)
    /** 最近一次采样或写入后读回的快照 */
    val latest: StateFlow<RmsSnapshot?> = _latest.asStateFlow()

    private val _history = MutableStateFlow<List<RmsSnapshot>>(emptyList())
    val history: StateFlow<List<RmsSnapshot>> = _history.asStateFlow()

    private val _pollCount = MutableStateFlow(0L)
    /** 累计 poll / write 周期次数 */
    val pollCount: StateFlow<Long> = _pollCount.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private val _watchPackage = MutableStateFlow("")
    /** 用户配置的监控目标包名，用于 [matchesPackage] 高亮 */
    val watchPackage: StateFlow<String> = _watchPackage.asStateFlow()

    private val _packageMatched = MutableStateFlow(false)
    /** 当前 raw reason 是否包含 watchPackage 子串 */
    val packageMatched: StateFlow<Boolean> = _packageMatched.asStateFlow()

    private val _lastBurstOk = MutableStateFlow(0)
    val lastBurstOk: StateFlow<Int> = _lastBurstOk.asStateFlow()

    private val _lastBurstTotal = MutableStateFlow(0)
    val lastBurstTotal: StateFlow<Int> = _lastBurstTotal.asStateFlow()

    private val _lastTargetReason = MutableStateFlow("")
    /** 最近一次 burst 试图写入的完整 reason */
    val lastTargetReason: StateFlow<String> = _lastTargetReason.asStateFlow()

    fun setWatchPackage(pkg: String) {
        _watchPackage.value = pkg.trim()
    }

    fun setServiceRunning(running: Boolean) {
        _serviceRunning.value = running
    }

    /**
     * 纯读轮询成功时更新状态。
     * @param appendHistory true 时追加到 history（手动刷新可为 false）
     */
    fun publish(snapshot: RmsSnapshot, watchPkg: String, appendHistory: Boolean) {
        _latest.value = snapshot
        _pollCount.value += 1
        _lastError.value = null
        _packageMatched.value = matchesPackage(snapshot.raw, watchPkg)
        if (appendHistory) {
            _history.update { list ->
                (listOf(snapshot) + list).take(MAX_HISTORY)
            }
        }
    }

    /**
     * burst 写入周期结束：更新连写统计、读回快照、设置不一致/失败错误文案。
     */
    fun publishWriteCycle(result: RmsBurstWriteResult, watchPkg: String) {
        _pollCount.value += 1
        _lastBurstOk.value = result.burst.successCount
        _lastBurstTotal.value = result.burst.attemptCount
        _lastTargetReason.value = result.targetReason
        val snap = RmsSnapshot(
            timestampMs = System.currentTimeMillis(),
            raw = result.verifyRaw,
            parsed = VivoRmsReasonParser.parse(result.verifyRaw),
            mode = RmsReadMode.CONTENT_RESOLVER,
        )
        _latest.value = snap
        _packageMatched.value = matchesPackage(result.verifyRaw, watchPkg)
        if (!result.burst.allOk) {
            _lastError.value = "连写 ${result.burst.successCount}/${result.burst.attemptCount}：${result.burst.lastMessage}"
        } else if (!result.verifyMatchesTarget && result.targetReason.isNotBlank()) {
            _lastError.value = "连写完成但读回不一致，可能被 RMS 覆盖"
        } else {
            _lastError.value = null
        }
        _history.update { list ->
            (listOf(snap) + list).take(MAX_HISTORY)
        }
    }

    fun publishError(message: String) {
        _lastError.value = message
    }

    fun clearHistory() {
        _history.value = emptyList()
        _pollCount.value = 0L
        _lastBurstOk.value = 0
        _lastBurstTotal.value = 0
    }

    /** 简单子串匹配：raw 含 pkg 即视为命中（兼容 pkg/activity 等复合载荷） */
    fun matchesPackage(raw: String?, pkg: String): Boolean {
        val p = pkg.trim()
        if (p.isBlank()) return false
        if (raw.isNullOrBlank()) return false
        return raw.contains(p)
    }
}
