/**
 * GameWatch GPU 切换：调用 [GameWatchCommands.swapModel]。
 *
 * 需模式名与包名列表；广播需 SWAPMODEL 权限声明的 receiver。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.shell.GameWatchCommands
import cn.boxiaolanya.tools.utils.ShizukuExec
import kotlinx.coroutines.launch

@Composable
fun GameWatchGpuSwapScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var packages by remember { mutableStateOf("") }
    var lastResult by remember { mutableStateOf<GpuSwapResult?>(null) }
    var isExecuting by remember { mutableStateOf(false) }

    fun executeSwap(pkgList: String) {
        if (!shizukuGranted) {
            scope.launch { snackbarHostState.showSnackbar("需授予 Shizuku 权限") }
            return
        }
        if (pkgList.isBlank()) {
            scope.launch { snackbarHostState.showSnackbar("包名不能为空") }
            return
        }
        scope.launch {
            isExecuting = true
            val pkgs = pkgList.split(",").map { it.trim() }.filter { it.isNotBlank() }.joinToString(",")
            val cmd = GameWatchCommands.swapModel("unlock", pkgs)
            val (output, success) = ShizukuExec.runShLine(cmd)
            lastResult = GpuSwapResult(success, output)
            isExecuting = false
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(icon = Icons.AutoMirrored.Filled.ArrowBack, title = "游戏配置切换",
                        description = "返回 GameWatch", onClick = { navController.navigateUp() }) {}
                }
            }

            if (!shizukuGranted) {
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(icon = Icons.Default.Clear, title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以使用此功能", isError = true) {}
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "配置切换执行") {
                    item {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = packages,
                                onValueChange = { packages = it },
                                label = { Text("包名列表") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 3,
                                placeholder = { Text("com.tencent.tmgp.sgame") }
                            )
                            Button(
                                onClick = { executeSwap(packages) },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = packages.isNotBlank()
                            ) {
                                Text("执行配置切换")
                            }
                        }
                    }
                }
            }

            lastResult?.let { result ->
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "执行结果") {
                    item {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(if (result.success) "成功" else "错误",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (result.success) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                            if (result.output.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                SelectionContainer {
                                    Text(result.output, style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }

    if (isExecuting) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceBright)) {
                    Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(modifier = Modifier.size(48.dp), strokeWidth = 4.dp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("正在执行切换...", style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
    }
}

data class GpuSwapResult(val success: Boolean, val output: String)
