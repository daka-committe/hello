/**
 * 单 Activity 入口：开发者致谢页、更新拦截、Shizuku 授权、NavHost 路由注册。
 */
package cn.boxiaolanya.tools

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import cn.boxiaolanya.tools.ui.MainViewModel
import cn.boxiaolanya.tools.ui.pages.welcome.DeveloperCreditsScreen
import cn.boxiaolanya.tools.ui.pages.HomeScreen
import cn.boxiaolanya.tools.ui.pages.Screen
import cn.boxiaolanya.tools.ui.pages.tools.CommandScreen

import cn.boxiaolanya.tools.ui.pages.tools.ActivityScreen
import cn.boxiaolanya.tools.ui.pages.tools.CrashScreen
import cn.boxiaolanya.tools.ui.pages.tools.ExperimentalScreen
import cn.boxiaolanya.tools.ui.pages.tools.KillScreen
import cn.boxiaolanya.tools.ui.pages.tools.NetworkPolicyScreen
import cn.boxiaolanya.tools.ui.pages.tools.PerfScreen
import cn.boxiaolanya.tools.ui.pages.tools.SurfaceFlingerScreen
import cn.boxiaolanya.tools.ui.pages.tools.ServiceControlScreen
import cn.boxiaolanya.tools.ui.pages.tools.DeviceIdleScreen
import cn.boxiaolanya.tools.ui.pages.tools.SettingsOptimizerScreen
import cn.boxiaolanya.tools.ui.pages.tools.EventMonitorScreen
import cn.boxiaolanya.tools.ui.pages.tools.ActivityServiceScreen
import cn.boxiaolanya.tools.ui.pages.tools.SmartEngineScreen
import cn.boxiaolanya.tools.ui.pages.tools.SmartEnginePowerScreen
import cn.boxiaolanya.tools.ui.pages.tools.SmartEngineConfigUpdateScreen
import cn.boxiaolanya.tools.ui.pages.tools.SmartEngineThreadScreen
import cn.boxiaolanya.tools.ui.pages.tools.SmartEngineUserReportScreen
import cn.boxiaolanya.tools.ui.pages.tools.SmartEngineAbeSwitchScreen
import cn.boxiaolanya.tools.ui.pages.tools.GameWatchScreen
import cn.boxiaolanya.tools.ui.pages.tools.GameWatchSceneSwitchScreen
import cn.boxiaolanya.tools.ui.pages.tools.GameWatchGpuSwapScreen
import cn.boxiaolanya.tools.ui.pages.tools.GameWatchQualityScreen
import cn.boxiaolanya.tools.ui.pages.tools.GameWatchTargetFpsScreen
import cn.boxiaolanya.tools.ui.pages.tools.GameWatchConfigUpdateScreen
import cn.boxiaolanya.tools.ui.pages.tools.GameWatchBinderIpcScreen
import cn.boxiaolanya.tools.ui.pages.tools.GameWatchBinderTutorialScreen
import cn.boxiaolanya.tools.ui.pages.tools.BatteryGuardScreen
import cn.boxiaolanya.tools.ui.pages.tools.BatteryGuardRestoreScreen
import cn.boxiaolanya.tools.ui.pages.tools.SuperResolutionScreen
import cn.boxiaolanya.tools.ui.pages.tools.SuperResMainScreen
import cn.boxiaolanya.tools.ui.pages.tools.SuperResInterpolationScreen
import cn.boxiaolanya.tools.ui.pages.tools.CloudControlScreen
import cn.boxiaolanya.tools.ui.pages.tools.CloudControlStopScreen
import cn.boxiaolanya.tools.ui.pages.tools.CloudTriggerScreen
import cn.boxiaolanya.tools.ui.pages.tools.PemSystemUpgradeCheckScreen
import cn.boxiaolanya.tools.ui.pages.tools.PemCloudActionScreen
import cn.boxiaolanya.tools.ui.pages.tools.PemTempStateChangeScreen
import cn.boxiaolanya.tools.ui.pages.tools.AudioEnhanceScreen
import cn.boxiaolanya.tools.ui.pages.tools.AudioImmersiveScreen
import cn.boxiaolanya.tools.ui.pages.tools.HighProtectScreen
import cn.boxiaolanya.tools.ui.pages.tools.VivoRmsScreen
import cn.boxiaolanya.tools.ui.pages.tools.FuelSummaryEditorScreen

import cn.boxiaolanya.tools.ui.theme.YueXiToolsTheme
import cn.boxiaolanya.tools.utils.PackageChecker
import cn.boxiaolanya.tools.utils.SettingsPermissionBootstrap
import cn.boxiaolanya.tools.utils.ShizukuHelper
import cn.boxiaolanya.tools.utils.UpdateChecker
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()
    private val REQUEST_CODE_SHIZUKU = 1001

    // Shizuku 授权回调：通过后自动 grant WRITE_SECURE_SETTINGS
    private val shizukuPermissionListener =
        Shizuku.OnRequestPermissionResultListener { _, grantResult ->
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                runSettingsPermissionBootstrap()
            }
        }

    private val requestNotificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val forbiddenApps = PackageChecker.checkForbiddenApps(this)
        if (forbiddenApps.isNotEmpty()) {
            showBlockingDialog(forbiddenApps)
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
        runSettingsPermissionBootstrap()

        setContent {
            var updateInfo by remember { mutableStateOf<UpdateChecker.UpdateInfo?>(null) }
            var isChecking by remember { mutableStateOf(true) }
            var launchStep by remember { mutableStateOf(LaunchStep.Developer) }

            LaunchedEffect(Unit) {
                val info = UpdateChecker.check(this@MainActivity)
                updateInfo = info
                isChecking = false
            }

            YueXiToolsTheme {
                when {
                    isChecking -> LoadingScreen()
                    updateInfo != null -> UpdateBlockScreen(updateInfo!!) {
                        UpdateChecker.showForceDialog(this@MainActivity, updateInfo!!)
                    }
                    launchStep == LaunchStep.Developer -> DeveloperCreditsScreen(
                        onEnterApp = { launchStep = LaunchStep.Main },
                    )
                    else -> MainScreen(
                        onShizukuPermissionRequest = { requestShizukuPermission() },
                    )
                }
            }
        }
    }

    private fun showBlockingDialog(apps: List<String>) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("启动异常")
            .setMessage("检测到冲突应用: ${apps.joinToString(", ")}\n\n请卸载冲突应用后重试")
            .setCancelable(false)
            .setPositiveButton("前往卸载") { _, _ ->
                try {
                    startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${apps[0]}")))
                } catch (e: Exception) {
                    startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${apps[0]}")))
                }
                finish()
            }
            .show()
    }

    override fun onResume() {
        super.onResume()
        runSettingsPermissionBootstrap()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
        super.onDestroy()
    }

    private fun runSettingsPermissionBootstrap() {
        if (!ShizukuHelper.isGranted()) return
        lifecycleScope.launch {
            SettingsPermissionBootstrap.ensure(this@MainActivity)
        }
    }

    private fun requestShizukuPermission() {
        try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                runSettingsPermissionBootstrap()
                return
            }
            Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

@Composable
private fun LoadingScreen() {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(36.dp),
                        strokeWidth = 3.dp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Text(
                    text = "悦玺工具箱",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "正在检查更新...",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun UpdateBlockScreen(info: UpdateChecker.UpdateInfo, onShowDialog: () -> Unit) {
    LaunchedEffect(Unit) { onShowDialog() }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier.padding(24.dp),
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(28.dp),
                            strokeWidth = 2.5.dp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Text(
                        text = "发现新版本",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${info.versionName} (${info.versionCode})",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "更新完成后请重新打开应用",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun MainScreen(
    onShizukuPermissionRequest: () -> Unit
) {
    val navController = rememberNavController()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var shizukuGranted by remember { mutableStateOf(false) }
    var shizukuVersion by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        checkShizukuStatus { granted, version ->
            shizukuGranted = granted
            shizukuVersion = version
        }
    }

    LaunchedEffect(shizukuGranted) {
        if (shizukuGranted) {
            SettingsPermissionBootstrap.ensure(context)
        }
    }

    LaunchedEffect(Unit) {
        val binderReceivedListener = Shizuku.OnBinderReceivedListener {
            checkShizukuStatus { granted, version ->
                shizukuGranted = granted
                shizukuVersion = version
                if (granted) {
                    scope.launch {
                        SettingsPermissionBootstrap.ensure(context)
                    }
                }
            }
        }

        val binderDeadListener = Shizuku.OnBinderDeadListener {
            shizukuGranted = false
            shizukuVersion = null
        }

        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        BackHandler {
            if (navController.previousBackStackEntry != null) {
                navController.popBackStack()
            }
        }

        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.fillMaxSize()
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    shizukuGranted = shizukuGranted,
                    shizukuVersion = shizukuVersion,
                    onRequestPermission = onShizukuPermissionRequest,
                    navController = navController
                )
            }
            composable(Screen.SettingsOptimizer.route) {
                SettingsOptimizerScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }

            composable(Screen.Command.route) {
                CommandScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(Screen.Experimental.route) {
                ExperimentalScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            // 高级调试：Activity / Crash / Kill / 网络策略 / Perf / SF / 服务 / Doze / 事件
            composable(
                route = Screen.ExperimentalActivity.route) {
                ActivityScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.ExperimentalCrash.route) {
                CrashScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.ExperimentalKill.route) {
                KillScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.ExperimentalNetworkPolicy.route) {
                NetworkPolicyScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.ExperimentalPerf.route) {
                PerfScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.ExperimentalSF.route) {
                SurfaceFlingerScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.ExperimentalService.route) {
                ServiceControlScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.ExperimentalDeviceIdle.route) {
                DeviceIdleScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.ExperimentalEventMonitor.route) {
                EventMonitorScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.ExperimentalActivityService.route) {
                ActivityServiceScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.HighProtect.route) {
                HighProtectScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            // 智慧引擎
            composable(
                route = Screen.SmartEngine.route) {
                SmartEngineScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.SmartEnginePower.route) {
                SmartEnginePowerScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.SmartEngineConfigUpdate.route) {
                SmartEngineConfigUpdateScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.SmartEngineThread.route) {
                SmartEngineThreadScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.SmartEngineUserReport.route) {
                SmartEngineUserReportScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.SmartEngineAbeSwitch.route) {
                SmartEngineAbeSwitchScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.CloudTrigger.route) {
                CloudTriggerScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            // GameWatch
            composable(
                route = Screen.GameWatch.route) {
                GameWatchScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.GameWatchSceneSwitch.route) {
                GameWatchSceneSwitchScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.GameWatchGpuSwap.route) {
                GameWatchGpuSwapScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.GameWatchQuality.route) {
                GameWatchQualityScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.GameWatchTargetFps.route) {
                GameWatchTargetFpsScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.GameWatchConfigUpdate.route) {
                GameWatchConfigUpdateScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.GameWatchBinderIpc.route) {
                GameWatchBinderIpcScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.GameWatchBinderTutorial.route) {
                GameWatchBinderTutorialScreen(
                    navController = navController
                )
            }
            composable(
                route = Screen.BatteryGuard.route) {
                BatteryGuardScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            // 电量守护 / PEM
            composable(
                route = Screen.BatteryGuardRestore.route) {
                BatteryGuardRestoreScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.PemSystemUpgradeCheck.route) {
                PemSystemUpgradeCheckScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.PemCloudAction.route) {
                PemCloudActionScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.PemTempStateChange.route) {
                PemTempStateChangeScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            // 超分 / 云控 / 音频 / RMS
            composable(
                route = Screen.SuperResolution.route) {
                SuperResolutionScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.SuperResMain.route) {
                SuperResMainScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.SuperResInterpolation.route) {
                SuperResInterpolationScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.CloudControl.route) {
                CloudControlScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.CloudControlStop.route) {
                CloudControlStopScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.AudioEnhance.route) {
                AudioEnhanceScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(
                route = Screen.AudioImmersive.route) {
                AudioImmersiveScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController
                )
            }
            composable(route = Screen.VivoRms.route) {
                VivoRmsScreen(
                    shizukuGranted = shizukuGranted,
                    navController = navController,
                )
            }
            composable(route = Screen.FuelSummaryEditor.route) {
                FuelSummaryEditorScreen(navController = navController)
            }
        }
    }
}

private enum class LaunchStep {
    Developer,
    Main,
}

private fun checkShizukuStatus(callback: (granted: Boolean, version: String?) -> Unit) {
    try {
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            val version = Shizuku.getVersion()
            callback(true, version.toString())
        } else {
            callback(false, null)
        }
    } catch (e: Exception) {
        callback(false, null)
    }
}

