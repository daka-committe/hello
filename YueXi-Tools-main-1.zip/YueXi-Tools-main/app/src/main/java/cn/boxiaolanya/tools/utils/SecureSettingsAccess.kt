/**
 * [WRITE_SECURE_SETTINGS] 权限与 [Settings.Secure] 标准 API 封装。
 *
 * 与 [SettingsContentAccess] 的分工：
 * - 本对象：权限检测、adb grant 命令生成、Settings.Secure 直读写
 * - ContentAccess：三表 + insert 策略 + burst（RMS 等更依赖后者）
 *
 * 授权路径（优先级）：
 * 1. Shizuku → [SettingsPermissionBootstrap.ensure] → pm grant
 * 2. 用户手动 adb shell pm grant … WRITE_SECURE_SETTINGS
 */
package cn.boxiaolanya.tools.utils

import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import cn.boxiaolanya.tools.utils.shell.ShellObf

object SecureSettingsAccess {

    /** 与 AndroidManifest 中声明一致，用于 pm grant / checkSelfPermission */
    const val WRITE_SECURE_SETTINGS = android.Manifest.permission.WRITE_SECURE_SETTINGS

    /** 当前进程是否已被系统授予 WRITE_SECURE_SETTINGS */
    fun isWriteSecureGranted(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, WRITE_SECURE_SETTINGS) ==
            PackageManager.PERMISSION_GRANTED

    /**
     * 生成供用户复制到 PC 终端的 adb 授权命令。
     * @param packageName 通常为 cn.boxiaolanya.tools
     */
    fun adbGrantCommand(packageName: String): String =
        String.format(ShellObf.s("token.adb_shell_pm_grant"), packageName)

    /**
     * 经 Settings.Secure API 读取（仅 secure 表）。
     * 过滤字面量 `"null"` 字符串。
     */
    fun getSecureString(context: Context, key: String): String? {
        val raw = Settings.Secure.getString(context.contentResolver, key) ?: return null
        if (raw.equals("null", ignoreCase = true)) return null
        return raw
    }

    /**
     * 经 Settings.Secure API 写入。
     * @return Settings API 返回值；无权限时为 false
     */
    fun putSecureString(context: Context, key: String, value: String): Boolean =
        Settings.Secure.putString(context.contentResolver, key, value)
}
