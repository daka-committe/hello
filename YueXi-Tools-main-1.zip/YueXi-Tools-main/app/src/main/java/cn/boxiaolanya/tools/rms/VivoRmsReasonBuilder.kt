/**
 * 构造写入 secure 表 `vivo_rms_active_request_reason` 的 reason 字符串。
 *
 * 与 [VivoRmsReasonParser] 互为逆过程（构造 ↔ 解析）。
 * gameSdk / setting 支持 override、vsyncImd 两个布尔维度，共 2×2=4 种前缀变体。
 */
package cn.boxiaolanya.tools.rms

/** UI 下拉选择的 reason 族；存储在 DataStore 时用 enum name */
enum class RmsBuilderKind(val label: String) {
    /** 游戏 SDK 路径，前缀 gameSdk* */
    GAME_SDK("gameSdk"),
    /** 设置/非 SDK 路径，前缀 setting* */
    SETTING("setting"),
    /** benchMark:pkg */
    BENCH_MARK("benchMark"),
    /** gfx_game:99998|pkg */
    GFX_GAME("gfx_game"),
    /** Thermal:pkg/temp */
    THERMAL("Thermal"),
    /** windowMinFps:pkg/act|fps */
    WINDOW_MIN("windowMinFps"),
    /** windowMaxFps:pkg/act|fps */
    WINDOW_MAX("windowMaxFps"),
}

object VivoRmsReasonBuilder {

    /**
     * 将 UI 上的 override / vsync 勾选映射为完整前缀（仅 GAME_SDK、SETTING 有效）。
     */
    fun resolveKind(base: RmsBuilderKind, override: Boolean, vsync: Boolean): String = when (base) {
        RmsBuilderKind.GAME_SDK -> buildGameSdkPrefix(override, vsync)
        RmsBuilderKind.SETTING -> buildSettingPrefix(override, vsync)
        else -> base.label
    }

    private fun buildGameSdkPrefix(override: Boolean, vsync: Boolean): String = when {
        override && vsync -> "gameSdk_override_vsyncImd"
        override -> "gameSdk_override"
        vsync -> "gameSdk_vsyncImd"
        else -> "gameSdk"
    }

    private fun buildSettingPrefix(override: Boolean, vsync: Boolean): String = when {
        override && vsync -> "setting_override_vsyncImd"
        override -> "setting_override"
        vsync -> "setting_vsyncImd"
        else -> "setting"
    }

    /**
     * 根据类型与参数拼最终 reason。
     *
     * @param packageName 目标应用包名，空白则返回空串（Repository 会拒绝写入）
     * @param activity window* 类型用；空则默认 `pkg.MainActivity`
     * @param temperature Thermal 类型用，默认 38.0
     * @param fps window* 类型管道右侧，默认 120
     */
    fun build(
        kind: RmsBuilderKind,
        packageName: String,
        override: Boolean = false,
        vsync: Boolean = false,
        activity: String = "",
        temperature: String = "38.0",
        fps: String = "120",
    ): String {
        val pkg = packageName.trim()
        if (pkg.isBlank()) return ""
        return when (kind) {
            RmsBuilderKind.GAME_SDK, RmsBuilderKind.SETTING -> {
                "${resolveKind(kind, override, vsync)}:$pkg"
            }
            RmsBuilderKind.BENCH_MARK -> "benchMark:$pkg"
            RmsBuilderKind.GFX_GAME -> "gfx_game:99998|$pkg"
            RmsBuilderKind.THERMAL -> "Thermal:$pkg/${temperature.ifBlank { "38.0" }}"
            RmsBuilderKind.WINDOW_MIN, RmsBuilderKind.WINDOW_MAX -> {
                val prefix = if (kind == RmsBuilderKind.WINDOW_MIN) "windowMinFps" else "windowMaxFps"
                val act = activity.ifBlank { "$pkg.MainActivity" }
                "$prefix:$pkg/$act|${fps.ifBlank { "120" }}"
            }
        }
    }

    /** DataStore 存 enum.name，非法或缺失时回退 GAME_SDK */
    fun kindFromStored(name: String): RmsBuilderKind =
        RmsBuilderKind.entries.firstOrNull { it.name == name } ?: RmsBuilderKind.GAME_SDK
}
