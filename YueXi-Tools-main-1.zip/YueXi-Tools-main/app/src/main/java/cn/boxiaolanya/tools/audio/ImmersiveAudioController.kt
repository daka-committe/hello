/**
 * 沉浸音频：空间音频 / 头部追踪等 API 封装。
 */
package cn.boxiaolanya.tools.audio

import android.content.Context
import android.media.AudioTrack
import android.media.AudioFormat
import android.media.AudioAttributes
import android.media.audiofx.Virtualizer
import android.media.audiofx.BassBoost
import android.media.audiofx.LoudnessEnhancer

class ImmersiveAudioController(context: Context) {

    private var virtualizer: Virtualizer? = null
    private var bassBoost: BassBoost? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var audioTrack: AudioTrack? = null

    var isSupported = true

    var preset: AudioPreset
        get() = try { AudioPreset.valueOf(AudioPreferences.immersivePreset) } catch (_: Exception) { AudioPreset.OFF }
        set(v) { AudioPreferences.immersivePreset = v.name }

    var virtualizerLevel: Int
        get() = AudioPreferences.immersiveVirtualizer
        set(v) { AudioPreferences.immersiveVirtualizer = v.coerceIn(0, 100) }

    var bassLevel: Int
        get() = AudioPreferences.immersiveBass
        set(v) { AudioPreferences.immersiveBass = v.coerceIn(0, 100) }

    var loudnessLevel: Int
        get() = AudioPreferences.immersiveLoudness
        set(v) { AudioPreferences.immersiveLoudness = v.coerceIn(0, 100) }

    var isEnabled: Boolean
        get() = AudioPreferences.immersiveEnabled
        set(v) { AudioPreferences.immersiveEnabled = v }

    enum class AudioPreset(val label: String) {
        OFF("关闭"),
        CINEMA("影院"),
        CONCERT("音乐厅"),
        GAME("游戏"),
        MUSIC("音乐"),
        VOCAL("语音增强"),
        CUSTOM("自定义"),
    }

    init {
        if (isEnabled) {
            initSilentTrack()
            initEffects()
            applyCurrentSettings()
        }
    }

    private fun initSilentTrack() {
        try {
            val sr = 44100
            val ch = AudioFormat.CHANNEL_OUT_STEREO
            val enc = AudioFormat.ENCODING_PCM_16BIT
            val bufSize = AudioTrack.getMinBufferSize(sr, ch, enc)
            if (bufSize <= 0) return

            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build())
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(enc).setSampleRate(sr).setChannelMask(ch)
                    .build())
                .setBufferSizeInBytes(bufSize)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            val silence = ByteArray(bufSize)
            track.write(silence, 0, silence.size)
            track.setLoopPoints(0, bufSize / 4, -1)
            track.play()
            audioTrack = track
        } catch (e: Exception) {}
    }

    private fun stopSilentTrack() {
        try {
            audioTrack?.apply { stop(); release() }
        } catch (_: Exception) {}
        audioTrack = null
    }

    private fun initEffects() {
        try {
            virtualizer = Virtualizer(0, 0).also { it.enabled = true }
        } catch (e: Exception) {
            virtualizer = null
        }
        try {
            bassBoost = BassBoost(0, 0).also { it.enabled = true }
        } catch (e: Exception) {
            bassBoost = null
        }
        try {
            loudnessEnhancer = LoudnessEnhancer(0).also { it.enabled = true }
        } catch (e: Exception) {
            loudnessEnhancer = null
        }
    }

    private fun releaseEffects() {
        virtualizer?.apply { enabled = false; release() }
        bassBoost?.apply { enabled = false; release() }
        loudnessEnhancer?.apply { enabled = false; release() }
        virtualizer = null; bassBoost = null; loudnessEnhancer = null
    }

    fun enable() {
        if (!isSupported) return
        isEnabled = true
        initSilentTrack()
        initEffects()
        applyCurrentSettings()
    }

    fun disable() {
        isEnabled = false
        releaseEffects()
        stopSilentTrack()
    }

    fun applyPreset(p: AudioPreset) {
        preset = p
        val (v, b, l) = presetParams(p)
        virtualizerLevel = v; bassLevel = b; loudnessLevel = l
        applyCurrentSettings()
    }

    fun applyCurrentSettings() {
        if (!isEnabled || !isSupported) return
        try { virtualizer?.setStrength((virtualizerLevel * 10).toShort()) } catch (_: Exception) {}
        try { bassBoost?.setStrength((bassLevel * 10).toShort()) } catch (_: Exception) {}
        try { loudnessEnhancer?.setTargetGain(loudnessLevel * 30) } catch (_: Exception) {}
    }

    fun release() {
        releaseEffects()
        stopSilentTrack()
    }

    private fun presetParams(p: AudioPreset): Triple<Int, Int, Int> {
        return when (p) {
            AudioPreset.OFF -> Triple(0, 0, 0)
            AudioPreset.CINEMA -> Triple(80, 60, 10)
            AudioPreset.CONCERT -> Triple(60, 30, 5)
            AudioPreset.GAME -> Triple(50, 40, 20)
            AudioPreset.MUSIC -> Triple(30, 20, 0)
            AudioPreset.VOCAL -> Triple(20, 0, 30)
            AudioPreset.CUSTOM -> Triple(virtualizerLevel, bassLevel, loudnessLevel)
        }
    }
}