/**
 * Doze 白名单：对包名执行 deviceidle whitelist +/-。
 *
 * 使用 [DeviceIdleCommands]；可帮助后台应用避开 Doze 限制（依 ROM 策略）。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.shell.DeviceIdleCommands
import cn.boxiaolanya.tools.utils.ShizukuExec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun DeviceIdleScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val scope = rememberCoroutineScope()

    var pkg by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    fun runCmd(cmd: String, desc: String) {
        scope.launch {
            isLoading = true
            val r = withContext(Dispatchers.IO) {
                try {
                    ShizukuExec.runShellCommand(cmd)
                } catch (e: Exception) {
                    Triple("", "", false)
                }
            }
            output = if (r.third) "成功" else "错误"
            isLoading = false
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
                )
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "Doze 白名单",
                        description = "返回高级调试",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (!shizukuGranted) {
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.BatteryChargingFull,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以启用 Doze 白名单管理",
                            isError = true
                        ) {}
                    }
                }
            } else {
                SettingSplicedColumnGroup(title = "白名单操作") {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "通过 deviceidle 管理应用 Doze 模式白名单，加入后应用可后台运行",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedTextField(
                                value = pkg,
                                onValueChange = { pkg = it },
                                label = { Text("目标包名") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                placeholder = { Text("com.example.app") }
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        runCmd(
                                            DeviceIdleCommands.add(pkg),
                                            "加入白名单"
                                        )
                                    },
                                    enabled = pkg.isNotBlank(),
                                    modifier = Modifier.weight(1f)
                                ) { Text("加入白名单") }
                                OutlinedButton(
                                    onClick = {
                                        runCmd(
                                            DeviceIdleCommands.remove(pkg),
                                            "移出白名单"
                                        )
                                    },
                                    enabled = pkg.isNotBlank(),
                                    modifier = Modifier.weight(1f)
                                ) { Text("移出白名单") }
                            }
                        }
                    }
                }

                if (output.isNotBlank()) {
                    Spacer(modifier = Modifier.height(16.dp))

                    SettingSplicedColumnGroup(title = "输出结果") {
                        item {
                            Column(modifier = Modifier.padding(16.dp)) {
                                SelectionContainer {
                                    Text(
                                        text = output,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                        item {
                            BaseWidget(
                                icon = Icons.Default.Clear,
                                title = "清空输出",
                                description = "清空当前执行结果",
                                onClick = { output = "" }
                            ) {}
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }

    if (isLoading) {
        Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
                ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceBright
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("正在执行操作...", style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
    }
}
