/**
 * 应用首页：Shizuku 状态卡片、工具分类列表、导航 [Screen] 路由。
 *
 * [Screen] sealed 类定义全部 composable 路由常量，供 MainActivity NavHost 注册。
 */
package cn.boxiaolanya.tools.ui.pages

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Battery6Bar
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.HdrOn
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.MiscellaneousServices
import androidx.compose.material.icons.filled.MonitorHeart
import androidx.compose.material.icons.filled.Pending
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShieldMoon
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

private data class ToolEntry(
    val title: String,
    val desc: String,
    val route: String,
    val icon: ImageVector,
    val enabled: Boolean = true,
)

private data class CategoryEntry(
    val title: String,
    val icon: ImageVector,
    val tools: List<ToolEntry>,
)

sealed class Screen(val route: String, val label: String) {
    object Home : Screen("home", "悦玺工具箱")
    object SettingsOptimizer : Screen("settings_optimizer", "系统设置")
    object Command : Screen("command", "Shell 终端")
    object Experimental : Screen("experimental", "高级调试")
    object ExperimentalActivity : Screen("experimental_activity", "Activity 管理")
    object ExperimentalCrash : Screen("experimental_crash", "崩溃模拟")
    object ExperimentalKill : Screen("experimental_kill", "进程管理")
    object ExperimentalNetworkPolicy : Screen("experimental_network_policy", "网络策略")
    object ExperimentalPerf : Screen("experimental_perf", "性能调度")
    object ExperimentalSF : Screen("experimental_sf", "SurfaceFlinger")
    object ExperimentalService : Screen("experimental_service", "服务控制")
    object ExperimentalDeviceIdle : Screen("experimental_deviceidle", "Doze 白名单")
    object ExperimentalEventMonitor : Screen("experimental_event_monitor", "事件监听")
    object ExperimentalActivityService : Screen("experimental_activity_service", "Activity 服务")
    object SmartEngine : Screen("smart_engine", "智慧引擎")
    object SmartEnginePower : Screen("smart_engine_power", "功耗管控")
    object SmartEngineConfigUpdate : Screen("smart_engine_config_update", "配置更新")
    object SmartEngineThread : Screen("smart_engine_thread", "线程上报")
    object SmartEngineUserReport : Screen("smart_engine_user_report", "用户上报")
    object SmartEngineAbeSwitch : Screen("smart_engine_abe_switch", "ABE 总开关")
    object HighProtect : Screen("high_protect", "电源信息")
    object CloudTrigger : Screen("cloud_trigger", "云控触发")
    object GameWatch : Screen("game_watch", "GameWatch")
    object GameWatchSceneSwitch : Screen("game_watch_scene_switch", "场景切换")
    object GameWatchGpuSwap : Screen("game_watch_gpu_swap", "GPU 切换")
    object GameWatchQuality : Screen("game_watch_quality", "画质通知")
    object GameWatchTargetFps : Screen("game_watch_targetfps", "目标帧率")
    object GameWatchConfigUpdate : Screen("game_watch_config_update", "配置更新")
    object GameWatchBinderIpc : Screen("game_watch_binder_ipc", "Binder IPC")
    object GameWatchBinderTutorial : Screen("game_watch_binder_tutorial", "教程")
    object BatteryGuard : Screen("battery_guard", "电量守护")
    object BatteryGuardRestore : Screen("battery_guard_restore", "恢复耗电")
    object PemSystemUpgradeCheck : Screen("pem_system_upgrade_check", "系统升级优化")
    object PemCloudAction : Screen("pem_cloud_action", "云端数据采集")
    object PemTempStateChange : Screen("pem_temp_state_change", "温度状态")
    object FuelSummaryEditor : Screen("fuel_summary_editor", "电量摘要配置")
    object SuperResolution : Screen("super_resolution", "超分辨率")
    object SuperResMain : Screen("super_res_main", "超分主设置")
    object SuperResInterpolation : Screen("super_res_interpolation", "插帧模式")
    object CloudControl : Screen("cloud_control", "云控控制")
    object CloudControlStop : Screen("cloud_control_stop", "停止云控")
    object AudioEnhance : Screen("audio_enhance", "音效增强")
    object AudioImmersive : Screen("audio_immersive", "沉浸音频")
    object VivoRms : Screen("vivo_rms", "VIVO-RMS")
}

@Composable
fun HomeScreen(
    shizukuGranted: Boolean,
    shizukuVersion: String?,
    onRequestPermission: () -> Unit,
    navController: NavController,
    showCreditsCard: Boolean = true
) {
    val sections = remember {
        listOf(
            CategoryEntry(
                title = "系统优化",
                icon = Icons.Default.Settings,
                tools = listOf(
                    ToolEntry("系统设置", "修改隐藏系统设置", Screen.SettingsOptimizer.route, Icons.Default.Tune),
                    ToolEntry("Shell 终端", "执行自定义 Shell 命令", Screen.Command.route, Icons.Default.Terminal),
                ),
            ),
            CategoryEntry(
                title = "性能调度",
                icon = Icons.Default.FlashOn,
                tools = listOf(
                    ToolEntry("GameWatch", "vivo 游戏加速套件", Screen.GameWatch.route, Icons.Default.Gamepad, true),
                    ToolEntry("智慧引擎", "vivo 功耗与配置管理", Screen.SmartEngine.route, Icons.Default.Memory, true),
                    ToolEntry("高温保护", "关闭高温保护提升性能", Screen.HighProtect.route, Icons.Default.Warning),
                ),
            ),
            CategoryEntry(
                title = "VIVO-RMS",
                icon = Icons.Default.Speed,
                tools = listOf(
                    ToolEntry(
                        "VIVO-RMS",
                        "包名 + Reason 参数，后台轮询监控",
                        Screen.VivoRms.route,
                        Icons.Default.Speed,
                    ),
                ),
            ),
            CategoryEntry(
                title = "电池与电源",
                icon = Icons.Default.Battery6Bar,
                tools = listOf(
                    ToolEntry("电量守护", "修复系统更新后的耗电异常", Screen.BatteryGuard.route, Icons.Default.ShieldMoon),
                    ToolEntry("系统升级优化", "PEM 系统升级优化检查", Screen.PemSystemUpgradeCheck.route, Icons.Default.SystemUpdate),
                    ToolEntry("云端数据采集", "PEM 云端数据采集", Screen.PemCloudAction.route, Icons.Default.Cloud),
                    ToolEntry("温度状态", "PEM 插件引擎温度状态", Screen.PemTempStateChange.route, Icons.Default.Thermostat),
                    ToolEntry(
                        "电量摘要配置",
                        "编辑 fuelsummary_uc.xml 数值并导出",
                        Screen.FuelSummaryEditor.route,
                        Icons.Default.Tune,
                    ),
                ),
            ),
            CategoryEntry(
                title = "显示与图形",
                icon = Icons.Default.HdrOn,
                tools = listOf(
                    ToolEntry("超分辨率", "显示 upscale 与帧率插值", Screen.SuperResolution.route, Icons.Default.HdrOn),
                ),
            ),
            CategoryEntry(
                title = "网络与云控",
                icon = Icons.Default.Cloud,
                tools = listOf(
                    ToolEntry("云控控制", "移除 vivo 云控限制", Screen.CloudControl.route, Icons.Default.Cloud),
                ),
            ),
            CategoryEntry(
                title = "音频",
                icon = Icons.Default.VolumeUp,
                tools = listOf(
                    ToolEntry("音效增强", "AudioController 增强设置", Screen.AudioEnhance.route, Icons.Default.VolumeUp),
                    ToolEntry("沉浸音频", "ImmersiveAudioController 设置", Screen.AudioImmersive.route, Icons.Default.VolumeUp),
                ),
            ),
            CategoryEntry(
                title = "高级调试",
                icon = Icons.Default.MonitorHeart,
                tools = listOf(
                    ToolEntry("Activity 管理", "管理 Android Activity", Screen.ExperimentalActivity.route, Icons.Default.MiscellaneousServices),
                    ToolEntry("服务控制", "启停系统服务", Screen.ExperimentalService.route, Icons.Default.Sync),
                    ToolEntry("进程管理", "查看和结束进程", Screen.ExperimentalKill.route, Icons.Default.Speed),
                    ToolEntry("性能调度", "CPU 与内存调度优化", Screen.ExperimentalPerf.route, Icons.Default.MonitorHeart),
                    ToolEntry("网络策略", "数据节省与网络限制", Screen.ExperimentalNetworkPolicy.route, Icons.Default.Cloud),
                    ToolEntry("Doze 白名单", "电池优化白名单", Screen.ExperimentalDeviceIdle.route, Icons.Default.Battery6Bar),
                    ToolEntry("事件监听", "vivo 事件服务监听", Screen.ExperimentalEventMonitor.route, Icons.Default.Pending),
                    ToolEntry("崩溃模拟", "模拟应用崩溃用于测试", Screen.ExperimentalCrash.route, Icons.Default.MonitorHeart),
                    ToolEntry("SurfaceFlinger", "帧缓冲与合成器", Screen.ExperimentalSF.route, Icons.Default.MonitorHeart),
                    ToolEntry("Activity 服务", "Activity 服务控制", Screen.ExperimentalActivityService.route, Icons.Default.MiscellaneousServices),
                ),
            ),
        )
    }

    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        visible = true
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        val statusBarPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
        val navBarPadding = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

        LazyColumn(
            contentPadding = PaddingValues(bottom = navBarPadding),
            verticalArrangement = Arrangement.spacedBy(0.dp)
        ) {
            item { Spacer(modifier = Modifier.height(statusBarPadding)) }

            item {
                AnimatedVisibility(
                    visible = visible,
                    enter = fadeIn(spring(stiffness = Spring.StiffnessMediumLow)) +
                            scaleIn(spring(stiffness = Spring.StiffnessMediumLow), initialScale = 0.95f)
                ) {
                    AppHeaderSection(
                        shizukuGranted = shizukuGranted,
                        shizukuVersion = shizukuVersion,
                        onClick = onRequestPermission
                    )
                }
            }

            sections.forEachIndexed { sectionIndex, category ->
                item {
                    AnimatedVisibility(
                        visible = visible,
                        enter = fadeIn(spring(stiffness = Spring.StiffnessMediumLow)) +
                                scaleIn(spring(stiffness = Spring.StiffnessMediumLow), initialScale = 0.95f)
                    ) {
                        CategorySection(
                            category = category,
                            shizukuGranted = shizukuGranted,
                            navController = navController
                        )
                    }
                }
            }

            if (showCreditsCard) {
                item {
                    AnimatedVisibility(
                        visible = visible,
                        enter = fadeIn(spring(stiffness = Spring.StiffnessMediumLow))
                    ) {
                        CreditsSection()
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun AppHeaderSection(
    shizukuGranted: Boolean,
    shizukuVersion: String?,
    onClick: () -> Unit
) {
    Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "悦玺工具箱",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "vivo / iQOO 系统优化工具",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            ShizukuStatusBadge(
                shizukuGranted = shizukuGranted,
                shizukuVersion = shizukuVersion,
                onClick = onClick
            )
        }
    }
}

@Composable
private fun ShizukuStatusBadge(
    shizukuGranted: Boolean,
    shizukuVersion: String?,
    onClick: () -> Unit
) {
    val haptic = LocalHapticFeedback.current

    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.ContextClick)
                    if (!shizukuGranted) onClick()
                }
            ),
        color = if (shizukuGranted)
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
        else
            MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (shizukuGranted) {
                CircularProgressIndicator(
                    modifier = Modifier.size(12.dp),
                    strokeWidth = 1.5.dp,
                    color = MaterialTheme.colorScheme.primary
                )
                if (shizukuVersion != null) {
                    Text(
                        text = "Shizuku v$shizukuVersion",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            } else {
                Icon(
                    imageVector = Icons.Default.Pending,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = "授权",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
        }
    }
}

@Composable
private fun CategorySection(
    category: CategoryEntry,
    shizukuGranted: Boolean,
    navController: NavController
) {
    Column(modifier = Modifier.padding(top = 12.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = category.icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = category.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column {
                category.tools.forEachIndexed { index, tool ->
                    val isEnabled = shizukuGranted || tool.enabled

                    ToolItem(
                        tool = tool,
                        enabled = isEnabled,
                        onClick = {
                            if (isEnabled) navController.navigate(tool.route)
                        }
                    )

                    if (index < category.tools.lastIndex) {
                        HorizontalDivider(
                            thickness = 0.5.dp,
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                            modifier = Modifier.padding(start = 68.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolItem(
    tool: ToolEntry,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val interactionSource = remember { MutableInteractionSource() }

    val alpha = if (enabled) 1f else 0.35f

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.ContextClick)
                    onClick()
                }
            )
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f * alpha)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = tool.icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary.copy(alpha = alpha),
                modifier = Modifier.size(22.dp)
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = tool.title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = alpha),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = tool.desc,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alpha * 0.8f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (enabled) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun CreditsSection() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "何必膜拜传奇？当你就是其中之一。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)
        )
    }
}