/**
 * vivo 事件监听：绑定 [VivoEventService] 或 logcat 展示 PEM 事件流。
 *
 * 用于调试 vivo_event_service 上报；需系统存在对应 Binder。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.VivoEventService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun EventMonitorScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val scope = rememberCoroutineScope()
    var output by remember { mutableStateOf("") }
    var events by remember { mutableStateOf(listOf<String>()) }
    var isLoading by remember { mutableStateOf(false) }
    var isRegistered by remember { mutableStateOf(false) }

    fun connectAndListen() {
        scope.launch {
            isLoading = true
            output = withContext(Dispatchers.IO) {
                val conn = VivoEventService.connect()
                if (conn != "connected") return@withContext conn
                val sb = StringBuilder()
                sb.appendLine("已连接到 vivo_event_service")
                sb.appendLine("注册事件监听...")
                val result = VivoEventService.registerEvents("tools", VivoEventService.KNOWN_EVENTS.toTypedArray()) { event, content ->
                    events = listOf("[$event] $content") + events.take(99)
                }
                sb.appendLine(result)
                sb.toString()
            }
            isRegistered = true
            isLoading = false
        }
    }

    fun stopListening() {
        scope.launch {
            isLoading = true
            output = withContext(Dispatchers.IO) {
                VivoEventService.unregisterEvents()
            }
            isRegistered = false
            isLoading = false
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            SettingSplicedColumnGroup {
                item {
                    BaseWidget(icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "vivo 事件监听",
                        description = "返回高级调试",
                        onClick = { navController.navigateUp() }) {}
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            SettingSplicedColumnGroup(title = "系统事件服务") {
                item {
                    Column(modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("通过 Binder IPC 注册到 vivo_event_service\n" +
                                "监听系统级事件：音频、视频、录音、GPS 状态",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (!isRegistered) {
                            Button(onClick = { connectAndListen() },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !isLoading) { Text("连接并监听") }
                        } else {
                            OutlinedButton(onClick = { stopListening() },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !isLoading) { Text("停止监听") }
                        }
                    }
                }
            }

            if (events.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                SettingSplicedColumnGroup(title = "事件记录") {
                    events.take(50).forEach { evt ->
                        item {
                            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                                Text(text = evt, style = MaterialTheme.typography.bodySmall,
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    item {
                        BaseWidget(icon = Icons.Default.Clear, title = "清空",
                            onClick = { events = emptyList() }) {}
                    }
                }
            }

            if (output.isNotBlank() && events.isEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                SettingSplicedColumnGroup(title = "输出") {
                    item {
                        Column(modifier = Modifier.padding(16.dp)) {
                            SelectionContainer {
                                Text(text = output, style = MaterialTheme.typography.bodySmall,
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }

    if (isLoading) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        }
    }
}
