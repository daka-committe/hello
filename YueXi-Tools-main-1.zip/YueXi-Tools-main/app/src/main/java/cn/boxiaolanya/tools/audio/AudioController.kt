/**
 * 音效增强：均衡器与系统音频效果封装。
 */
package cn.boxiaolanya.tools.audio

import android.content.Context
import android.media.AudioManager
import android.media.AudioDeviceInfo
import android.content.BroadcastReceiver
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.media.AudioFocusRequest
import android.content.pm.PackageManager
import android.Manifest
import androidx.core.content.ContextCompat

enum class AudioOutputMode(val label: String) {
    SPEAKER("扬声器"),
    EARPIECE("听筒"),
    SPEAKER_SYSTEM("音响系统"),
    BLUETOOTH("蓝牙通话"),
    BLUETOOTH_A2DP("蓝牙音乐"),
    WIRED_HEADSET("有线耳机"),
    SYSTEM("系统默认")
}

class AudioController(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isReceiverRegistered = false
    private var scoTimeoutRunnable: Runnable? = null
    private var audioFocusRequest: AudioFocusRequest? = null
    private var hasAudioFocus = false
    private var retryCount = 0
    private val maxRetries = 3
    private val retryDelays = longArrayOf(500, 1000, 2000)

    private val switchingLock = Any()
    private var isSwitching = false

    var currentMode = AudioOutputMode.SYSTEM
        private set

    private val scoReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent?.action != AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED) return
            val state = intent.getIntExtra(AudioManager.EXTRA_SCO_AUDIO_STATE, -1)
            when (state) {
                AudioManager.SCO_AUDIO_STATE_CONNECTED -> handleScoConnected()
                AudioManager.SCO_AUDIO_STATE_DISCONNECTED -> {}
                AudioManager.SCO_AUDIO_STATE_CONNECTING -> {}
            }
        }
    }

    private fun ensureScoReceiverRegistered() {
        if (isReceiverRegistered) return
        try {
            context.registerReceiver(scoReceiver, IntentFilter(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED))
            isReceiverRegistered = true
        } catch (e: Exception) {}
    }

    private fun stopScoAndCleanup() {
        cancelScoTimeout()
        if (audioManager.isBluetoothScoOn) {
            audioManager.isBluetoothScoOn = false
        }
        try { audioManager.stopBluetoothSco() } catch (_: Exception) {}
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try { audioManager.clearCommunicationDevice() } catch (_: Exception) {}
        }
    }

    private fun requestAudioFocusForSwitch(): Boolean {
        abandonAudioFocus()
        val result = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build())
                .setOnAudioFocusChangeListener { focusChange ->
                    hasAudioFocus = focusChange == AudioManager.AUDIOFOCUS_GAIN
                }
                .build()
            audioFocusRequest = req
            audioManager.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(
                { focusChange ->
                    hasAudioFocus = focusChange == AudioManager.AUDIOFOCUS_GAIN
                },
                AudioManager.STREAM_VOICE_CALL,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
            ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
        hasAudioFocus = result
        return result
    }

    private fun abandonAudioFocus() {
        audioFocusRequest?.let {
            audioManager.abandonAudioFocusRequest(it)
            audioFocusRequest = null
        }
        hasAudioFocus = false
    }

    fun switchToSpeaker() {
        stopScoAndCleanup()
        requestAudioFocusForSwitch()
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        audioManager.isSpeakerphoneOn = true
        currentMode = AudioOutputMode.SPEAKER
    }

    fun switchToEarpiece() {
        stopScoAndCleanup()
        requestAudioFocusForSwitch()
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        audioManager.isSpeakerphoneOn = false
        currentMode = AudioOutputMode.EARPIECE
    }

    fun switchToSpeakerSystem() {
        stopScoAndCleanup()
        requestAudioFocusForSwitch()
        audioManager.mode = AudioManager.MODE_NORMAL
        audioManager.isSpeakerphoneOn = true
        currentMode = AudioOutputMode.SPEAKER_SYSTEM
    }

    fun resetToSystem() {
        cancelScoTimeout()
        retryCount = 0
        stopScoAndCleanup()
        abandonAudioFocus()
        audioManager.mode = AudioManager.MODE_NORMAL
        audioManager.isSpeakerphoneOn = false
        currentMode = AudioOutputMode.SYSTEM
    }

    fun reassertCurrentMode() {
        when (currentMode) {
            AudioOutputMode.SPEAKER -> {
                audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
                audioManager.isSpeakerphoneOn = true
            }
            AudioOutputMode.EARPIECE -> {
                audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
                audioManager.isSpeakerphoneOn = false
            }
            AudioOutputMode.SPEAKER_SYSTEM -> {
                audioManager.mode = AudioManager.MODE_NORMAL
                audioManager.isSpeakerphoneOn = true
            }
            else -> {}
        }
    }

    fun switchToBluetooth() {
        synchronized(switchingLock) {
            if (isSwitching) return
            isSwitching = true
        }
        try {
            doBluetoothSwitch()
        } catch (e: Exception) {
            releaseSwitchingLock()
        }
    }

    fun switchToBluetoothA2dp() {
        cancelScoTimeout()
        retryCount = 0
        stopScoAndCleanup()
        abandonAudioFocus()
        audioManager.mode = AudioManager.MODE_NORMAL
        audioManager.isSpeakerphoneOn = false
        currentMode = AudioOutputMode.BLUETOOTH_A2DP
    }

    private fun doBluetoothSwitch() {
        if (!checkBluetoothPermissions()) {
            releaseSwitchingLock()
            return
        }
        stopScoAndCleanup()
        if (!requestAudioFocusForSwitch()) {
            releaseSwitchingLock()
            return
        }
        ensureScoReceiverRegistered()
        retryCount = 0
        startScoActivation()
    }

    private fun startScoActivation() {
        synchronized(switchingLock) {
            if (!isSwitching) return
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                val btDevice = devices.find { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO }
                if (btDevice != null) {
                    audioManager.setCommunicationDevice(btDevice)
                }
            }
            audioManager.startBluetoothSco()
            startScoTimeoutWatcher()
        } catch (e: Exception) {
            releaseSwitchingLock()
            abandonAudioFocus()
        }
    }

    private fun handleScoConnected() {
        cancelScoTimeout()
        retryCount = 0
        try {
            audioManager.isBluetoothScoOn = true
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager.isSpeakerphoneOn = false
            currentMode = AudioOutputMode.BLUETOOTH
        } catch (e: Exception) {} finally {
            releaseSwitchingLock()
        }
    }

    private fun startScoTimeoutWatcher() {
        val timeout = if (retryCount == 0) 5000L else 3000L
        scoTimeoutRunnable = Runnable {
            synchronized(switchingLock) {
                if (!isSwitching) return@Runnable
            }
            if (retryCount < maxRetries) {
                retryCount++
                val delay = retryDelays[retryCount - 1]
                audioManager.stopBluetoothSco()
                mainHandler.postDelayed({ startScoActivation() }, delay)
            } else {
                releaseSwitchingLock()
                retryCount = 0
            }
        }
        mainHandler.postDelayed(scoTimeoutRunnable!!, timeout)
    }

    private fun cancelScoTimeout() {
        scoTimeoutRunnable?.let { mainHandler.removeCallbacks(it) }
        scoTimeoutRunnable = null
    }

    private fun releaseSwitchingLock() {
        synchronized(switchingLock) {
            isSwitching = false
        }
    }

    private fun checkBluetoothPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun detectCurrentMode(): AudioOutputMode {
        if (audioManager.isBluetoothScoOn) return AudioOutputMode.BLUETOOTH
        if (audioManager.isSpeakerphoneOn) {
            return if (audioManager.mode == AudioManager.MODE_NORMAL) AudioOutputMode.SPEAKER_SYSTEM
            else AudioOutputMode.SPEAKER
        }
        if (audioManager.mode == AudioManager.MODE_IN_COMMUNICATION && !audioManager.isSpeakerphoneOn) {
            return AudioOutputMode.EARPIECE
        }
        val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        var hasA2dp = false
        for (d in devices) {
            when (d.type) {
                AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> return AudioOutputMode.BLUETOOTH
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> hasA2dp = true
                AudioDeviceInfo.TYPE_WIRED_HEADSET,
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                AudioDeviceInfo.TYPE_USB_HEADSET -> return AudioOutputMode.WIRED_HEADSET
            }
        }
        if (hasA2dp) return AudioOutputMode.BLUETOOTH_A2DP
        return AudioOutputMode.SYSTEM
    }

    fun isBluetoothAvailable(): Boolean {
        return audioManager.isBluetoothScoAvailableOffCall
    }

    fun unregister() {
        try {
            if (isReceiverRegistered) {
                context.unregisterReceiver(scoReceiver)
                isReceiverRegistered = false
            }
            abandonAudioFocus()
        } catch (e: Exception) {}
    }
}