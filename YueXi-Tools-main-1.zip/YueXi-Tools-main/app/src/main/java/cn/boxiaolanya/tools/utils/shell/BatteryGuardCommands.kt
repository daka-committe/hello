package cn.boxiaolanya.tools.utils.shell

object BatteryGuardCommands {
    val REFRESH_CONFIG: String get() = PemCommands.REFRESH_CONFIG
    val IQOO_POWER_SAVE_CHANGED: String get() = ShellObf.s("bg.iqoo_power")
    val PEMR_UPDATE_FINISH: String get() = ShellObf.s("bg.pemr_update")
    val PEMR_CONFIG_UPDATE: String get() = PEMR_UPDATE_FINISH
    val RESTORE_PEM_SERVICE: String get() = ShellObf.s("bg.restore.pem")
    val RESTORE_POWER_SERVICE: String get() = ShellObf.s("bg.restore.power")
}
