/**
 * VIVO-RMS `vivo_rms_active_request_reason` 的读写、构造、解析与运行时状态。
 *
 * secure 键 `vivo_rms_active_request_reason` 描述当前 RMS（资源管理）活跃请求原因；
 * 修改它可影响刷率、GPU 档位等调度（依机型与系统版本而定）。
 *
 * 模块分工：
 * - [VivoRmsReasonBuilder] 按 UI 选项拼 reason 字符串
 * - [VivoRmsReasonParser] 读回后解析为可读字段
 * - [VivoRmsRepository] 持久化配置 + ContentResolver 读写 + burst 验证
 * - [VivoRmsRuntime] 后台 Service 与 UI 共享的 StateFlow
 * - [cn.boxiaolanya.tools.service.VivoRmsMonitorService] 定时轮询
 */
package cn.boxiaolanya.tools.rms

import android.content.Context
import cn.boxiaolanya.tools.ui.settings.AppDataStore
import cn.boxiaolanya.tools.ui.settings.dataStore
import cn.boxiaolanya.tools.utils.SecureSettingsAccess
import cn.boxiaolanya.tools.utils.SettingsContentAccess
import cn.boxiaolanya.tools.utils.shell.VivoRmsCommands
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

/** 当前环境支持的 RMS reason 读取方式（写始终走 ContentResolver）。 */
enum class RmsReadMode {
    /** 已 grant WRITE_SECURE_SETTINGS，可 query secure 表 */
    CONTENT_RESOLVER,
    /** 无 secure 读权限（极少见；读仍可能通过 query 成功，写必失败） */
    NONE,
}

/**
 * 单次采样快照，供 UI 列表与 [VivoRmsRuntime.history] 使用。
 */
data class RmsSnapshot(
    val timestampMs: Long,
    /** secure 表原始字符串，可能为 null */
    val raw: String?,
    val parsed: RmsReasonParseResult,
    val mode: RmsReadMode = RmsReadMode.NONE,
)

/**
 * 从 DataStore 恢复的「写入模板」；[builtReason] 生成最终写入 secure 的字符串。
 */
data class RmsWriteConfig(
    val packageName: String,
    val kind: RmsBuilderKind,
    val useOverride: Boolean,
    val useVsync: Boolean,
    val temperature: String,
    val activity: String,
    val fps: String,
    /** 连写次数，见 [VivoRmsRepository.DEFAULT_BURST_COUNT] */
    val burstCount: Int,
    /** 后台 Service 轮询间隔 ms */
    val intervalMs: Long,
) {
    fun builtReason(): String = VivoRmsReasonBuilder.build(
        kind = kind,
        packageName = packageName,
        override = useOverride,
        vsync = useVsync,
        activity = activity,
        temperature = temperature,
        fps = fps,
    )
}

/**
 * burst 写入后立即读回的对账结果。
 * @param verifyMatchesTarget 读回值是否与 [targetReason] 完全一致（不一致可能被系统 RMS 覆盖）
 */
data class RmsBurstWriteResult(
    val targetReason: String,
    val burst: SettingsContentAccess.BurstResult,
    val verifyRaw: String?,
    val verifyMatchesTarget: Boolean,
)

object VivoRmsRepository {

    /** UI 默认连写次数 */
    const val DEFAULT_BURST_COUNT = 8
    const val MIN_BURST_COUNT = 1
    const val MAX_BURST_COUNT = 32

    /**
     * 根据是否已 grant secure 写权限推断读模式（用于 UI 展示「当前通道」）。
     */
    fun readMode(context: Context): RmsReadMode =
        if (SecureSettingsAccess.isWriteSecureGranted(context)) {
            RmsReadMode.CONTENT_RESOLVER
        } else {
            RmsReadMode.NONE
        }

    /** secure 表读一般无需额外权限，故恒 true */
    fun canRead(context: Context): Boolean = true

    fun canWrite(context: Context): Boolean = SettingsContentAccess.canWrite(context)

    /** 从 DataStore 加载上次保存的 RMS 写入参数（VivoRmsScreen 表单默认值）。 */
    suspend fun loadWriteConfig(context: Context): RmsWriteConfig = withContext(Dispatchers.IO) {
        val prefs = context.dataStore.data.first()
        RmsWriteConfig(
            packageName = prefs[AppDataStore.RMS_TARGET_PACKAGE]?.trim().orEmpty(),
            kind = VivoRmsReasonBuilder.kindFromStored(prefs[AppDataStore.RMS_REASON_KIND] ?: ""),
            useOverride = prefs[AppDataStore.RMS_USE_OVERRIDE] ?: false,
            useVsync = prefs[AppDataStore.RMS_USE_VSYNC] ?: false,
            temperature = prefs[AppDataStore.RMS_THERMAL_TEMP] ?: "38.0",
            activity = prefs[AppDataStore.RMS_ACTIVITY] ?: "",
            fps = prefs[AppDataStore.RMS_FPS] ?: "120",
            burstCount = (prefs[AppDataStore.RMS_BURST_WRITE_COUNT] ?: DEFAULT_BURST_COUNT)
                .coerceIn(MIN_BURST_COUNT, MAX_BURST_COUNT),
            intervalMs = prefs[AppDataStore.RMS_POLL_INTERVAL_MS] ?: VivoRmsRuntime.DEFAULT_INTERVAL_MS,
        )
    }

    /** 读取 secure 键 [VivoRmsCommands.SECURE_KEY] 当前值。 */
    suspend fun readActiveReason(context: Context): Pair<String?, Boolean> = withContext(Dispatchers.IO) {
        SettingsContentAccess.get(context, VivoRmsCommands.SECURE_TABLE, VivoRmsCommands.SECURE_KEY)
    }

    /**
     * 连写 [times] 次 reason 到 secure 表。
     * @return Pair(burst 汇总, burst.allOk)
     */
    suspend fun writeActiveReasonBurst(context: Context, value: String, times: Int): Pair<SettingsContentAccess.BurstResult, Boolean> =
        withContext(Dispatchers.IO) {
            if (!canWrite(context)) {
                return@withContext Pair(
                    SettingsContentAccess.BurstResult(0, times, false, "需要 adb 授予 WRITE_SECURE_SETTINGS"),
                    false,
                )
            }
            val burst = SettingsContentAccess.putBurst(
                context,
                VivoRmsCommands.SECURE_TABLE,
                VivoRmsCommands.SECURE_KEY,
                value,
                times,
            )
            Pair(burst, burst.allOk)
        }

    /**
     * 根据 [config] 构造 reason → burst 写入 → 立即读回验证。
     * 包名为空时短路返回，不发起写入。
     */
    suspend fun writeBurstAndVerify(context: Context, config: RmsWriteConfig): RmsBurstWriteResult =
        withContext(Dispatchers.IO) {
            val target = config.builtReason()
            if (target.isBlank()) {
                return@withContext RmsBurstWriteResult(
                    targetReason = "",
                    burst = SettingsContentAccess.BurstResult(0, config.burstCount, false, "包名为空"),
                    verifyRaw = null,
                    verifyMatchesTarget = false,
                )
            }
            val (burst, _) = writeActiveReasonBurst(context, target, config.burstCount)
            val (verifyRaw, _) = readActiveReason(context)
            RmsBurstWriteResult(
                targetReason = target,
                burst = burst,
                verifyRaw = verifyRaw,
                verifyMatchesTarget = verifyRaw == target,
            )
        }

    /** 读 + 解析 + 打时间戳，供手动刷新与 Service 轮询共用。 */
    suspend fun snapshot(context: Context): RmsSnapshot {
        val mode = readMode(context)
        val (raw, _) = readActiveReason(context)
        return RmsSnapshot(
            System.currentTimeMillis(),
            raw,
            VivoRmsReasonParser.parse(raw),
            mode,
        )
    }
}
