/**
 * GameWatch 模块 dumpsys activity broadcast 命令模板。
 */
package cn.boxiaolanya.tools.utils.shell

object GameWatchCommands {

    private val SWAP_MODEL get() = ShellObf.s("gw.swap_model")
    private val TARGET_FPS get() = ShellObf.s("gw.target_fps")
    private val QUALITY get() = ShellObf.s("gw.quality")
    private val SCENE_STATUS get() = ShellObf.s("gw.scene_status")

    val CONFIG_UPDATE: String
        get() = ShellObf.s("gw.config_update")

    fun swapModel(mode: String, pkgList: String): String = ShellFormat.fmt2(SWAP_MODEL, mode, pkgList)

    fun targetFps(packageName: String, pid: String, fps: String): String =
        ShellFormat.fmt3(TARGET_FPS, packageName, pid, fps)

    fun quality(packageName: String, pid: String, quality: String): String =
        ShellFormat.fmt3(QUALITY, packageName, pid, quality)

    fun sceneStatus(packageName: String, status: String): String =
        ShellFormat.fmt2(SCENE_STATUS, packageName, status)
}
