/**
 * GameWatch Binder IPC 实验室：按 [GameWatchBinder.executors] 动态生成表单并 execute。
 *
 * 支持查看 executor 参数类型、发送 transact、展示成功/失败消息。
 * 教程入口跳转 [GameWatchBinderTutorialScreen]。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.service.GlobalPowerSaveService
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.GameWatchBinder
import cn.boxiaolanya.tools.utils.ShizukuExec
import cn.boxiaolanya.tools.utils.shell.ProcQueries
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private data class AutoStep(
    val name: String,
    val executorName: String,
    val args: List<Pair<String, String>>
)

// ORIGINAL=释放全部性能，BALANCED=均衡省电，SMART=智能省电
private enum class TurboMode(
    val displayName: String,
    val description: String
) {
    ORIGINAL(
        displayName = "释放全部性能",
        description = "激进模式，释放全部CPU/GPU性能，发热严重"
    ),

    BALANCED(
        displayName = "均衡省电",
        description = "均衡模式，限制峰值频率，保持流畅与发热的平衡"
    ),

    SMART(
        displayName = "智能省电",
        description = "智能模式，先均衡再停止，适合轻负载或后台"
    );

    companion object {
        fun fromOrdinal(ordinal: Int): TurboMode =
            entries.getOrElse(ordinal) { ORIGINAL }
    }
}

@Composable
fun GameWatchBinderIpcScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val executors = GameWatchBinder.executors
    var selectedExecutor by remember { mutableStateOf<GameWatchBinder.Executor?>(null) }
    var serviceAvailable by remember { mutableStateOf(GameWatchBinder.isServiceAvailable()) }
    var targetPkg by remember { mutableStateOf("") }
    var resolvedPid by remember { mutableStateOf<Int?>(null) }
    var resolving by remember { mutableStateOf(false) }
    var pidError by remember { mutableStateOf<String?>(null) }

    var autoRunning by remember { mutableStateOf(false) }
    var autoResults by remember { mutableStateOf<List<Pair<String, Boolean>>>(emptyList()) }
    var autoStepIndex by remember { mutableIntStateOf(-1) }
    var showAutoConfirmDialog by remember { mutableStateOf(false) }
    var selectedMode by remember { mutableIntStateOf(0) }
    val context = LocalContext.current
    var globalPowerSaveEnabled by remember { mutableStateOf(GlobalPowerSaveService.isRunning(context)) }
    val scope = rememberCoroutineScope()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "Binder IPC 注入",
                        description = "返回 GameWatch",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            if (!shizukuGranted) {
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.BugReport,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以启用 IPC 功能",
                            isError = true
                        ) {}
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))

                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            if (serviceAvailable) Icons.Default.CheckCircle else Icons.Default.Error,
                            contentDescription = null,
                            tint = if (serviceAvailable)
                                MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.error
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (serviceAvailable)
                                    "gamewatch_server 可用"
                                else "gamewatch_server 不可用",
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Text(
                                text = "com.vivo.gamewatch.common.IGameWatch",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (globalPowerSaveEnabled)
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                if (globalPowerSaveEnabled)
                                    Icons.Default.CheckCircle
                                else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (globalPowerSaveEnabled)
                                    MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "全局省电模式",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (globalPowerSaveEnabled)
                                        "运行中，每5秒自动优化前台应用"
                                    else "后台自动注入均衡参数，关闭冗余功能",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (globalPowerSaveEnabled) {
                                Button(
                                    onClick = {
                                        GlobalPowerSaveService.stop(context)
                                        globalPowerSaveEnabled = false
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.error
                                    ),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Text(
                                        "停止",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            } else {
                                Button(
                                    onClick = {
                                        GlobalPowerSaveService.start(context)
                                        globalPowerSaveEnabled = true
                                    },
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Text(
                                        "启动",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }

                        if (globalPowerSaveEnabled) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "已自动检测前台应用并注入均衡参数，无需手动操作",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(
                            alpha = 0.3f
                        )
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "全自动注入",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = targetPkg,
                            onValueChange = {
                                targetPkg = it
                                resolvedPid = null
                                pidError = null
                            },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("目标包名") },
                            placeholder = { Text("如 com.example.game") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            enabled = !autoRunning
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    if (targetPkg.isBlank()) return@Button
                                    scope.launch {
                                        resolving = true
                                        pidError = null
                                        try {
                                            val pid = ProcQueries.pidOfPackage(targetPkg)
                                            if (pid != null) {
                                                resolvedPid = pid
                                            } else {
                                                pidError = "无法获取 PID，请确认包名是否正确且应用正在运行"
                                                resolvedPid = null
                                            }
                                        } catch (e: Exception) {
                                            pidError = e.message
                                            resolvedPid = null
                                        }
                                        resolving = false
                                    }
                                },
                                enabled = targetPkg.isNotBlank() && !resolving && !autoRunning,
                                modifier = Modifier.height(40.dp)
                            ) {
                                if (resolving) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(
                                        Icons.Default.Search,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("获取 PID")
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            if (resolvedPid != null) {
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.primaryContainer
                                    )
                                ) {
                                    Text(
                                        text = "PID: $resolvedPid",
                                        modifier = Modifier.padding(
                                            horizontal = 12.dp,
                                            vertical = 6.dp
                                        ),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        }

                        if (pidError != null) {
                            Text(
                                text = pidError!!,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "选择注入模式",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TurboMode.entries.forEachIndexed { index, mode ->
                                FilterChip(
                                    selected = selectedMode == index,
                                    onClick = { selectedMode = index },
                                    label = {
                                        Text(
                                            mode.displayName,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    },
                                    enabled = !autoRunning,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        if (selectedMode > 0) {
                            val modeDesc = TurboMode.fromOrdinal(selectedMode).description
                            Text(
                                text = modeDesc,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { showAutoConfirmDialog = true },
                            enabled = serviceAvailable && !autoRunning,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (TurboMode.fromOrdinal(selectedMode) == TurboMode.ORIGINAL)
                                    MaterialTheme.colorScheme.error
                                else MaterialTheme.colorScheme.primary
                            )
                        ) {
                            if (autoRunning) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                            }
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            val stepCount = buildAutoSteps(
                                TurboMode.fromOrdinal(selectedMode),
                                resolvedPid ?: 0,
                                targetPkg
                            ).size
                            Text(
                                if (autoRunning)
                                    "注入中... (${autoResults.size}/? )"
                                else
                                    "${TurboMode.fromOrdinal(selectedMode).displayName} (${stepCount}步)",
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (autoResults.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                "执行结果 (${autoResults.count { it.second }}/${autoResults.size} 成功)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            autoResults.forEachIndexed { i, (name, ok) ->
                                val isCurrent = i == autoStepIndex && autoRunning
                                Row(
                                    modifier = Modifier
                                        .padding(vertical = 1.dp)
                                        .then(
                                            if (isCurrent) Modifier.background(
                                                MaterialTheme.colorScheme.primaryContainer.copy(
                                                    alpha = 0.2f
                                                ),
                                                MaterialTheme.shapes.extraSmall
                                            ) else Modifier
                                        ),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (ok)
                                            Icons.Default.CheckCircle
                                        else Icons.Default.Error,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (ok)
                                            Color(0xFF4CAF50)
                                        else MaterialTheme.colorScheme.error
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isCurrent) "$name ..." else name,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (ok)
                                            Color(0xFF4CAF50)
                                        else if (isCurrent)
                                            MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "选择执行器 (${executors.size} 个)",
                    modifier = Modifier.padding(horizontal = 16.dp),
                    style = MaterialTheme.typography.titleMedium
                )

                Spacer(modifier = Modifier.height(8.dp))

                executors.forEach { executor ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .clickable { selectedExecutor = executor }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = executor.name,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "-> ${executor.returnType}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Text(
                                text = executor.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (executor.params.isNotEmpty()) {
                                Text(
                                    text = executor.params.joinToString(", ") {
                                        "${it.name}:${it.type}"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }

    if (selectedExecutor != null) {
        ExecutorDialog(
            executor = selectedExecutor!!,
            onDismiss = { selectedExecutor = null }
        )
    }

    if (showAutoConfirmDialog) {
        AutoConfirmDialog(
            targetPkg = targetPkg,
            selectedMode = selectedMode,
            onDismiss = { showAutoConfirmDialog = false },
            onConfirm = {
                autoResults = emptyList()
                autoStepIndex = -1
                autoRunning = true
                scope.launch {
                    val steps = buildAutoSteps(
                        mode = TurboMode.fromOrdinal(selectedMode),
                        pid = resolvedPid ?: 0,
                        pkg = targetPkg
                    )
                    steps.forEachIndexed { i, step ->
                        autoStepIndex = i
                        val found = executors.any { it.name == step.executorName }
                        if (found) {
                            val r = GameWatchBinder.execute(step.executorName, step.args)
                            autoResults = autoResults + (step.name to r.first)
                        } else {
                            autoResults = autoResults + (step.name to false)
                        }
                        if (i < steps.lastIndex) delay(100)
                    }
                    autoStepIndex = steps.size
                    autoRunning = false
                }
            }
        )
    }
}

@Composable
private fun AutoConfirmDialog(
    targetPkg: String,
    selectedMode: Int,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    val mode = TurboMode.fromOrdinal(selectedMode)
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                Icons.Default.Warning,
                contentDescription = null,
                tint = if (mode == TurboMode.ORIGINAL)
                    MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text(
                mode.displayName,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column {
                Text(
                    when (mode) {
                        TurboMode.ORIGINAL ->
                            "释放全部性能将导致设备发热严重，电池消耗加速，系统稳定性下降，请谨慎操作。"
                        TurboMode.BALANCED ->
                            "均衡省电模式将在保证流畅的前提下适当限制性能，降低发热，保持续航。"
                        TurboMode.SMART ->
                            "智能省电模式将优先降低频率和帧率，适合轻负载场景或后台运行。"
                    },
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "目标包名：$targetPkg",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = when (mode) {
                        TurboMode.ORIGINAL -> "后果自负，请谨慎操作！"
                        TurboMode.BALANCED -> "建议长时间游戏时使用。"
                        TurboMode.SMART -> "适合挂机或低负载场景。"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = if (mode == TurboMode.ORIGINAL)
                        MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onDismiss()
                    onConfirm()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (mode == TurboMode.ORIGINAL)
                        MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary
                )
            ) {
                Text("确认执行")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消")
            }
        }
    )
}

@Composable
private fun ExecutorDialog(
    executor: GameWatchBinder.Executor,
    onDismiss: () -> Unit
) {
    var results by remember { mutableStateOf<List<String>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    val args = remember { executor.params.map { mutableStateOf("") } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(executor.name) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    text = executor.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))

                executor.params.forEachIndexed { index, param ->
                    OutlinedTextField(
                        value = args[index].value,
                        onValueChange = { args[index].value = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        label = { Text("${param.name} (${param.type})") },
                        placeholder = { Text(param.description) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                    )
                }

                if (results.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        "结果:",
                        style = MaterialTheme.typography.labelMedium
                    )
                    results.forEach { result ->
                        Text(
                            text = result,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (result.startsWith("成功"))
                                MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    isLoading = true
                    val argsList = executor.params.mapIndexed { index, paramDef ->
                        paramDef.name to args[index].value
                    }
                    val (_, message) = GameWatchBinder.execute(executor.name, argsList)
                    isLoading = false
                    results = listOf(message)
                },
                enabled = !isLoading
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp))
                } else {
                    Text("执行")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("关闭")
            }
        }
    )
}

/**
 * 构建自动注入步骤列表
 */
private fun buildAutoSteps(
    mode: TurboMode,
    pid: Int,
    pkg: String
): List<AutoStep> {
    val pids = pid.toString()
    return when (mode) {
        TurboMode.ORIGINAL -> listOf(
            AutoStep("游戏挂起-恢复", "hang_up_game", listOf("pid" to pids, "state" to "0")),
            AutoStep("游戏模式-启动", "turbo", listOf("uid" to "0", "pid" to pids, "cmd" to "1", "pkgName" to pkg)),
            AutoStep("均衡模式-启动", "turbo", listOf("uid" to "0", "pid" to pids, "cmd" to "2", "pkgName" to pkg)),
            AutoStep("高负载Turbo", "turbo", listOf("uid" to "0", "pid" to "60000", "cmd" to "3", "pkgName" to "")),
            AutoStep("长时Turbo", "turbo", listOf("uid" to "0", "pid" to "30000", "cmd" to "11", "pkgName" to "")),
            AutoStep("线程标记", "turbo", listOf("uid" to "0", "pid" to "0", "cmd" to "1000", "pkgName" to pkg)),
            AutoStep("目标FPS-120", "notify_target_fps", listOf("pkgName" to pkg, "uid" to pids, "targetFps" to "0", "minFps" to "60", "maxFps" to "120", "refreshRate" to "144", "mode" to "1", "thermalLevel" to "0", "flags" to "0")),
            AutoStep("渲染线程通知", "notify_render_thread", listOf("pkgName" to pkg, "pid" to pids, "threadName" to "MainThread", "threadId" to pids, "width" to "0", "height" to "0")),
            AutoStep("GPU控制-查询配置", "control_panel", listOf("pkgName" to pkg, "key" to "", "value" to "", "scope" to "")),
            AutoStep("MAGT扩展控制", "magt_extension_control", listOf("targetPid" to pids, "serviceCode" to "1", "arg1" to "0", "arg2" to "0")),
            AutoStep("图形API-Vulkan", "notify_api_type", listOf("apiType" to "2", "pid" to pids, "flags" to "0")),
            AutoStep("性能转储-开启", "perf_tool_dump_begin", listOf("enable" to "true", "pid" to "0", "type" to "0", "outputPath" to "")),
            AutoStep("EcoSDK-就绪", "ecosdk", listOf("jsonCmd" to "{\"cmd\":\"all_surface_ready\",\"status\":true}")),
            AutoStep("游戏空间查询", "game_space", listOf("type" to "0")),
            AutoStep("信息提供-性能", "info_provide", listOf("type" to "2")),
            AutoStep("多线程服务-查询", "turbo2", listOf("uid" to "0", "pid" to pids, "cmd" to "14", "pkgName" to pkg, "intArray1" to "", "intArray2" to "", "strArray1" to "", "strArray2" to "")),
            AutoStep("VAPT-启用查询", "vaptTurbo", listOf("uid" to "0", "pid" to pids, "cmd" to "520", "pkgName" to pkg, "intArray1" to "", "intArray2" to "", "strArray1" to "", "strArray2" to "")),
            AutoStep("网络优化", "net_opt", listOf("key" to "game_mode", "value" to "1")),
            AutoStep("通用通知", "notify_to_app_common", listOf("uid" to "0", "pid" to pids, "pkgName" to pkg, "action" to "game_start", "extras" to "{}", "flags" to "0")),
            AutoStep("VNSS支持查询", "is_support_vnss", listOf("pkgName" to pkg)),
            AutoStep("游戏库状态", "GameLib", listOf("gameId" to "0"))
        )

        TurboMode.BALANCED -> listOf(
            AutoStep("游戏挂起-恢复", "hang_up_game", listOf("pid" to pids, "state" to "0")),
            AutoStep("均衡模式-启动", "turbo", listOf("uid" to "0", "pid" to pids, "cmd" to "2", "pkgName" to pkg)),
            AutoStep("目标FPS-120", "notify_target_fps", listOf("pkgName" to pkg, "uid" to pids, "targetFps" to "0", "minFps" to "60", "maxFps" to "120", "refreshRate" to "144", "mode" to "1", "thermalLevel" to "0", "flags" to "0")),
            AutoStep("渲染线程通知", "notify_render_thread", listOf("pkgName" to pkg, "pid" to pids, "threadName" to "MainThread", "threadId" to pids, "width" to "0", "height" to "0")),
            AutoStep("GPU控制-查询配置", "control_panel", listOf("pkgName" to pkg, "key" to "", "value" to "", "scope" to "")),
            AutoStep("MAGT扩展控制", "magt_extension_control", listOf("targetPid" to pids, "serviceCode" to "1", "arg1" to "0", "arg2" to "0")),
            AutoStep("图形API-Vulkan", "notify_api_type", listOf("apiType" to "2", "pid" to pids, "flags" to "0")),
            AutoStep("EcoSDK-就绪", "ecosdk", listOf("jsonCmd" to "{\"cmd\":\"all_surface_ready\",\"status\":true}")),
            AutoStep("游戏空间查询", "game_space", listOf("type" to "0")),
            AutoStep("信息提供-性能", "info_provide", listOf("type" to "2")),
            AutoStep("turbo2-查询", "turbo2", listOf("uid" to "0", "pid" to pids, "cmd" to "14", "pkgName" to pkg, "intArray1" to "", "intArray2" to "", "strArray1" to "", "strArray2" to "")),
            AutoStep("VAPT-启用查询", "vaptTurbo", listOf("uid" to "0", "pid" to pids, "cmd" to "520", "pkgName" to pkg, "intArray1" to "", "intArray2" to "", "strArray1" to "", "strArray2" to "")),
            AutoStep("网络优化", "net_opt", listOf("key" to "game_mode", "value" to "1")),
            AutoStep("通用通知", "notify_to_app_common", listOf("uid" to "0", "pid" to pids, "pkgName" to pkg, "action" to "game_start", "extras" to "{}", "flags" to "0")),
            AutoStep("VNSS支持查询", "is_support_vnss", listOf("pkgName" to pkg)),
            AutoStep("游戏库状态", "GameLib", listOf("gameId" to "0"))
        )

        TurboMode.SMART -> listOf(
            AutoStep("游戏挂起-恢复", "hang_up_game", listOf("pid" to pids, "state" to "0")),
            AutoStep("均衡模式-启动", "turbo", listOf("uid" to "0", "pid" to pids, "cmd" to "2", "pkgName" to pkg)),
            AutoStep("停止Turbo", "turbo", listOf("uid" to "0", "pid" to "0", "cmd" to "5", "pkgName" to "")),
            AutoStep("目标FPS-120", "notify_target_fps", listOf("pkgName" to pkg, "uid" to pids, "targetFps" to "0", "minFps" to "60", "maxFps" to "120", "refreshRate" to "144", "mode" to "1", "thermalLevel" to "0", "flags" to "0")),
            AutoStep("渲染线程通知", "notify_render_thread", listOf("pkgName" to pkg, "pid" to pids, "threadName" to "MainThread", "threadId" to pids, "width" to "0", "height" to "0")),
            AutoStep("MAGT扩展控制", "magt_extension_control", listOf("targetPid" to pids, "serviceCode" to "1", "arg1" to "0", "arg2" to "0")),
            AutoStep("EcoSDK-取消就绪", "ecosdk", listOf("jsonCmd" to "{\"cmd\":\"all_surface_ready\",\"status\":false}")),
            AutoStep("游戏空间查询", "game_space", listOf("type" to "0")),
            AutoStep("网络优化-关闭", "net_opt", listOf("key" to "game_mode", "value" to "0")),
            AutoStep("通用通知-暂停", "notify_to_app_common", listOf("uid" to "0", "pid" to pids, "pkgName" to pkg, "action" to "game_pause", "extras" to "{}", "flags" to "0")),
            AutoStep("VNSS支持查询", "is_support_vnss", listOf("pkgName" to pkg)),
            AutoStep("游戏库状态", "GameLib", listOf("gameId" to "0"))
        )
    }
}
