/**
 * 性能调度：Monster 广播、[VivoPerfManager] perfLock、[VivoPerfCommands] settings。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.ShizukuExec
import cn.boxiaolanya.tools.utils.VivoPerfManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun PerfScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val scope = rememberCoroutineScope()
    var output by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    val available = remember { VivoPerfManager.isAvailable }

    fun invoke(block: () -> String) {
        scope.launch {
            isLoading = true
            output = withContext(Dispatchers.IO) { try { block() } catch (e: Exception) { "fail" } }
            isLoading = false
        }
    }

    fun runShell(cmd: String) {
        scope.launch {
            isLoading = true
            output = withContext(Dispatchers.IO) {
                try {
                    val r = ShizukuExec.runShellCommand(cmd)
                    if (r.third) "ok" else "fail"
                } catch (e: Exception) { "fail" }
            }
            isLoading = false
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
                )
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "性能调度",
                        description = "返回高级调试",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (!shizukuGranted) {
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(icon = Icons.Default.Speed, title = "Shizuku 未连接", isError = true) {}
                    }
                }
            } else {
                SettingSplicedColumnGroup(title = "性能加速") {
                    item {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (!available) {
                                Text("当前设备不支持此功能", style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error)
                            }

                            OutlinedButton(
                                onClick = { invoke { VivoPerfManager.acquire(600000, *VivoPerfManager.HINT_TURBO) } },
                                enabled = available,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("极致性能") }

                            OutlinedButton(
                                onClick = { invoke { VivoPerfManager.acquire(600000, *VivoPerfManager.HINT_TURBO_SHORT) } },
                                enabled = available,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("瞬时提速") }

                            OutlinedButton(
                                onClick = { invoke { VivoPerfManager.acquire(600000, *VivoPerfManager.HINT_MAX_CPU) } },
                                enabled = available,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("CPU Max") }

                            OutlinedButton(
                                onClick = { invoke { VivoPerfManager.acquire(600000, *VivoPerfManager.HINT_GPU_BOOST) } },
                                enabled = available,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("GPU Boost") }

                            OutlinedButton(
                                onClick = { invoke { VivoPerfManager.release() } },
                                enabled = available,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("恢复默认调度") }
                        }
                    }
                }
            }

            if (output.isNotBlank()) {
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "当前状态") {
                    item {
                        Column(modifier = Modifier.padding(16.dp)) {
                            SelectionContainer {
                                Text(text = output, style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    item {
                        BaseWidget(icon = Icons.Default.Clear, title = "清空", onClick = { output = "" }) {}
                    }
                }
            }
            Spacer(modifier = Modifier.height(WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }

    if (isLoading) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceBright),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)) {
                    Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("请稍等...", style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
    }
}
