/**
 * 云控移除：发送厂商云控相关广播以停用远程管控能力。
 *
 * 具体 action 在界面内组装；需 Shizuku 执行 dumpsys broadcast。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.pages.Screen
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup

@Composable
fun CloudControlScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "去云控",
                        description = "返回高级调试",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            if (!shizukuGranted) {
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Apps,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以启用去云控功能",
                            isError = true
                        ) {}
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "功能列表") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Block,
                            title = "停止云控服务",
                            description = "切断 vivo 云控通道",
                            onClick = { navController.navigate(Screen.CloudControlStop.route) }
                        ) {}
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }
}
