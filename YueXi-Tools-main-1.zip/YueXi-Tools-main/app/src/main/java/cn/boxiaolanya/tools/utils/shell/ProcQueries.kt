/**
 * 通过 Shizuku 执行 pidof，解析目标应用进程 ID。
 *
 * GameWatch 帧率/画质广播要求 `--ei pid` 为运行中进程；
 * UI 在包名输入后协程调用 [pidOfPackage]，取得 PID>0 才允许点击发送。
 */
package cn.boxiaolanya.tools.utils.shell

import cn.boxiaolanya.tools.utils.ShizukuExec
import cn.boxiaolanya.tools.utils.shell.ShellTokens

object ProcQueries {

    /**
     * pidof 可能返回多个 PID（空格分隔，多进程或多实例），取第一个作为「主进程」近似。
     */
    fun parseFirstPid(pidofOutput: String): Int? {
        val token = pidofOutput.trim().split(Regex("\\s+")).firstOrNull() ?: return null
        return token.toIntOrNull()?.takeIf { it > 0 }
    }

    /**
     * @return 有效 PID 或 null（包未运行、Shizuku 失败、输出无法解析）
     */
    suspend fun pidOfPackage(packageName: String): Int? {
        val pkg = packageName.trim()
        if (pkg.isBlank()) return null
        val (output, success) = ShizukuExec.runCommandWithOutput(ShellTokens.pidof, pkg)
        if (!success && output.isBlank()) return null
        return parseFirstPid(output)
    }
}
