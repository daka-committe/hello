package cn.boxiaolanya.tools.utils.shell

object NetworkPolicyCommands {
    private val RESTRICT_BACKGROUND get() = ShellObf.s("net.restrict_bg")
    private val VAL_TRUE get() = ShellObf.s("net.true")
    private val VAL_FALSE get() = ShellObf.s("net.false")

    fun restrict(packageName: String): String = RESTRICT_BACKGROUND + packageName + VAL_TRUE

    fun unrestrict(packageName: String): String = RESTRICT_BACKGROUND + packageName + VAL_FALSE
}
