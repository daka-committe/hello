@file:Suppress("SpellCheckingInspection")

/**
 * VivoPerfManager perfLockAcquire/Release 反射封装。
 * PerfScreen 用于短时 CPU/GPU 提频；不可用时回退 Shell 广播命令。
 */
package cn.boxiaolanya.tools.utils

import cn.boxiaolanya.tools.utils.shell.VivoPerfCommands

object VivoPerfManager {
    private var instance: Any? = null
    private var perfLockAcquire: java.lang.reflect.Method? = null
    private var perfLockRelease: java.lang.reflect.Method? = null

    init {
        try {
            val cls = Class.forName("com.vivo.framework.vperf.VivoPerfManager")
            instance = cls.getConstructor().newInstance()
            val intType = Int::class.javaPrimitiveType!!
            perfLockAcquire = cls.getMethod("perfLockAcquire", intType, IntArray::class.java)
            perfLockRelease = cls.getMethod("perfLockRelease")
        } catch (_: Exception) {}
    }

    val isAvailable: Boolean get() = instance != null && perfLockAcquire != null

    fun acquire(durationMs: Int, vararg hints: Int): String {
        if (!isAvailable) return "unsupported"
        return try {
            val result = perfLockAcquire!!.invoke(instance, durationMs, hints)
            result?.toString() ?: "null"
        } catch (e: Exception) {
            "fail: ${e.message}"
        }
    }

    fun release(): String {
        if (!isAvailable) return "unsupported"
        return try {
            val result = perfLockRelease!!.invoke(instance)
            result?.toString() ?: "null"
        } catch (e: Exception) {
            "fail: ${e.message}"
        }
    }

    val HINT_TURBO = intArrayOf(0x40C00000, 2, 0x40800000, 4095, 0x40800000, 4095, 0x40800000, 4095, 0x40400000, 1, -0xFF00000, 9)
    val HINT_TURBO_SHORT = intArrayOf(0x40C00000, 2, 0x40800000, 1000, 0x40800000, 1000, 0x40800000, 1000)
    val HINT_MAX_CPU = intArrayOf(0x40C00000, 2, 0x40800000, 4095, 0x40800000, 4095)
    val HINT_GPU_BOOST = intArrayOf(0x40800000, 4095, -0xFF00000, 9)

    fun customHint(vararg pairs: Pair<Float, Int>): IntArray {
        val arr = IntArray(pairs.size * 2)
        pairs.forEachIndexed { i, (op, v) -> arr[i * 2] = java.lang.Float.floatToRawIntBits(op); arr[i * 2 + 1] = v }
        return arr
    }

    fun monsterModeOn() = VivoPerfCommands.MONSTER_MODE_ON

    fun monsterModeOff() = VivoPerfCommands.MONSTER_MODE_OFF

    fun monsterPlusOn() =
        VivoPerfCommands.MONSTER_MODE_ON + " && " + VivoPerfCommands.gamePlusOn()

    fun monsterPlusOff() =
        VivoPerfCommands.gamePlusOff() + " && " + VivoPerfCommands.MONSTER_MODE_OFF

    fun monsterMarkerOn() =
        VivoPerfCommands.powerSaveSecure("5") + " && " +
            VivoPerfCommands.powerSaveSystem("5") + " && " +
            VivoPerfCommands.monsterKeyOn() + " && " +
            VivoPerfCommands.ICON_RADIUS_BROADCAST

    fun monsterMarkerOff() =
        VivoPerfCommands.powerSaveSecure("1") + " && " +
            VivoPerfCommands.powerSaveSystem("1") + " && " +
            VivoPerfCommands.monsterKeyOff() + " && " +
            VivoPerfCommands.ICON_RADIUS_BROADCAST
}
