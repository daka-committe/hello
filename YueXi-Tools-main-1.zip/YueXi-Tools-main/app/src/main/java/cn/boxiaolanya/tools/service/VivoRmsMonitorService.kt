/**
 * VIVO-RMS 后台「连写 + 读回验证」前台服务。
 *
 * 用户在 [cn.boxiaolanya.tools.ui.pages.tools.VivoRmsScreen] 开启后台监控后：
 * 1. 按 DataStore 中的 [cn.boxiaolanya.tools.rms.RmsWriteConfig] 构造 reason
 * 2. [cn.boxiaolanya.tools.rms.VivoRmsRepository.writeBurstAndVerify] burst 写入 secure
 * 3. [cn.boxiaolanya.tools.rms.VivoRmsRuntime.publishWriteCycle] 更新 UI 可 collect 的状态
 * 4. 更新低优先级常驻通知展示最近读回值
 *
 * 需要 WRITE_SECURE_SETTINGS；无权限时每轮 publishError 并 delay，不 stopSelf。
 */
package cn.boxiaolanya.tools.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import cn.boxiaolanya.tools.MainActivity
import cn.boxiaolanya.tools.rms.VivoRmsRepository
import cn.boxiaolanya.tools.rms.VivoRmsRuntime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class VivoRmsMonitorService : Service() {

    companion object {
        const val CHANNEL_ID = "vivo_rms_monitor_channel"
        const val CHANNEL_NAME = "VIVO-RMS 连写"
        const val NOTIFICATION_ID = 10002

        const val ACTION_START = "cn.boxiaolanya.tools.action.START_RMS_MONITOR"
        const val ACTION_STOP = "cn.boxiaolanya.tools.action.STOP_RMS_MONITOR"

        fun start(context: Context) {
            val intent = Intent(context, VivoRmsMonitorService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, VivoRmsMonitorService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        /** 通过 ActivityManager 判断本 Service 是否在运行（用于 UI 开关状态） */
        fun isRunning(context: Context): Boolean {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            @Suppress("DEPRECATION")
            return manager.getRunningServices(Int.MAX_VALUE)
                .any { it.service.className == VivoRmsMonitorService::class.java.name }
        }
    }

    private val scope = CoroutineScope(Dispatchers.Default)
    private var pollJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopPolling()
                VivoRmsRuntime.setServiceRunning(false)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                startForeground(NOTIFICATION_ID, createNotification("启动连写…", false, 0, 0))
                VivoRmsRuntime.setServiceRunning(true)
                startPolling()
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopPolling()
        VivoRmsRuntime.setServiceRunning(false)
        super.onDestroy()
    }

    /** 主循环：loadConfig → burst+verify → publish → delay(intervalMs) */
    private fun startPolling() {
        stopPolling()
        pollJob = scope.launch {
            while (isActive) {
                try {
                    if (!VivoRmsRepository.canWrite(applicationContext)) {
                        VivoRmsRuntime.publishError("需要 WRITE_SECURE_SETTINGS（SetEdit 同款 ContentResolver）")
                        delay(VivoRmsRuntime.DEFAULT_INTERVAL_MS)
                        continue
                    }
                    val config = VivoRmsRepository.loadWriteConfig(applicationContext)
                    val watchPkg = config.packageName
                    VivoRmsRuntime.setWatchPackage(watchPkg)
                    if (config.builtReason().isBlank()) {
                        VivoRmsRuntime.publishError("请先配置包名再开启连写")
                        delay(config.intervalMs)
                        continue
                    }
                    val result = VivoRmsRepository.writeBurstAndVerify(applicationContext, config)
                    VivoRmsRuntime.publishWriteCycle(result, watchPkg)
                    val line = result.verifyRaw ?: "null"
                    val burstTag = "${result.burst.successCount}/${result.burst.attemptCount}"
                    updateNotification(
                        line = "$burstTag · $line",
                        matched = result.verifyMatchesTarget || VivoRmsRuntime.matchesPackage(line, watchPkg),
                        burstOk = result.burst.successCount,
                        burstTotal = result.burst.attemptCount,
                    )
                } catch (e: Exception) {
                    VivoRmsRuntime.publishError(e.message ?: "连写失败")
                }
                val interval = try {
                    VivoRmsRepository.loadWriteConfig(applicationContext).intervalMs
                } catch (_: Exception) {
                    VivoRmsRuntime.DEFAULT_INTERVAL_MS
                }
                delay(interval)
            }
        }
    }

    private fun stopPolling() {
        pollJob?.cancel()
        pollJob = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "循环 content 连写 vivo_rms_active_request_reason"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun createNotification(
        line: String,
        matched: Boolean,
        burstOk: Int,
        burstTotal: Int,
    ): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val title = when {
            burstTotal > 0 && burstOk == burstTotal && matched -> "VIVO-RMS · 连写生效"
            burstTotal > 0 -> "VIVO-RMS · 连写 $burstOk/$burstTotal"
            matched -> "VIVO-RMS · 已匹配"
            else -> "VIVO-RMS · 连写中"
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(line.take(80))
            .setStyle(NotificationCompat.BigTextStyle().bigText(line))
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(line: String, matched: Boolean, burstOk: Int, burstTotal: Int) {
        try {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFICATION_ID, createNotification(line, matched, burstOk, burstTotal))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
