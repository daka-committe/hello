/**
 * MainActivity 预留 ViewModel，当前无业务状态。
 */
package cn.boxiaolanya.tools.ui

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel()
