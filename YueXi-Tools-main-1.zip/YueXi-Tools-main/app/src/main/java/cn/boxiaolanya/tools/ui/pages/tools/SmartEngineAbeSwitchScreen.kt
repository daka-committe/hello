/**
 * 智慧引擎 ABE 总开关：读写 secure 表 `abe_unified_switch`。
 * 值为 -1/0/1，Switch 开启=1，关闭=0。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSwitchWidget
import cn.boxiaolanya.tools.utils.SettingsContentAccess
import cn.boxiaolanya.tools.utils.shell.SettingsOptimizerCommands
import cn.boxiaolanya.tools.rms.VivoRmsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SmartEngineAbeSwitchScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var abeSwitchValue by remember { mutableIntStateOf(-1) }
    var isLoading by remember { mutableStateOf(false) }
    var isInitialized by remember { mutableStateOf(false) }

    fun loadCurrentValue() {
        scope.launch {
            isLoading = true
            abeSwitchValue = withContext(Dispatchers.IO) {
                runCatching {
                    val (value, ok) = SettingsContentAccess.get(
                        context,
                        SettingsOptimizerCommands.ABE_UNIFIED_SWITCH.table,
                        SettingsOptimizerCommands.ABE_UNIFIED_SWITCH.key
                    )
                    if (ok) value?.trim()?.toIntOrNull() ?: -1 else -1
                }.getOrDefault(-1)
            }
            isInitialized = true
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadCurrentValue()
    }

    fun applyValue(checked: Boolean) {
        scope.launch {
            isLoading = true
            val newValue = if (checked) 1 else 0
            val burst = withContext(Dispatchers.IO) {
                SettingsContentAccess.putBurst(
                    context,
                    SettingsOptimizerCommands.ABE_UNIFIED_SWITCH.table,
                    SettingsOptimizerCommands.ABE_UNIFIED_SWITCH.key,
                    newValue.toString(),
                    VivoRmsRepository.DEFAULT_BURST_COUNT,
                )
            }
            isLoading = false
            if (burst.allOk) {
                abeSwitchValue = newValue
                snackbarHostState.showSnackbar(
                    if (checked) "ABE 总开关已开启（值为 1）" else "ABE 总开关已关闭（值为 0）"
                )
            } else {
                snackbarHostState.showSnackbar("写入失败，请确认 WRITE_SECURE_SETTINGS 已授予")
            }
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
                )
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "ABE 总开关",
                        description = "返回智慧引擎",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            if (!shizukuGranted) {
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Info,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以使用此功能",
                            isError = true
                        ) {}
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "说明") {
                    item {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = "abe_unified_switch 是 ABE 智慧引擎的全局总开关。",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "值含义：1 = 开启，0 = 关闭，-1 = 无效/未配置",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "关闭后智慧引擎所有功能（省电、消息、异常处理等）将全部失效，请谨慎操作。",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (isInitialized) {
                    SettingSplicedColumnGroup(title = "ABE 全局开关") {
                        item {
                            SettingSwitchWidget(
                                title = "ABE 智慧引擎总开关",
                                description = when (abeSwitchValue) {
                                    1 -> "当前状态：已开启"
                                    0 -> "当前状态：已关闭"
                                    else -> "当前状态：未配置（-1）"
                                },
                                checked = abeSwitchValue == 1,
                                iconPlaceholder = false,
                                onCheckedChange = { applyValue(it) }
                            )
                        }
                    }
                } else {
                    Spacer(modifier = Modifier.height(16.dp))
                    SettingSplicedColumnGroup {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(32.dp),
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Text(
                                        text = "正在读取当前值…",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }

    if (isLoading) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceBright
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(48.dp),
                            strokeWidth = 4.dp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "正在写入…",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }
}