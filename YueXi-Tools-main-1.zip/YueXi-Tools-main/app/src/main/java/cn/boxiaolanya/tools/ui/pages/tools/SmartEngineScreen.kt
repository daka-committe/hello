/**
 * 智慧引擎 hub：功耗、配置更新、线程异常、用户上报子入口。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.pages.Screen
import cn.boxiaolanya.tools.ui.theme.AppIcons
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup

@Composable
fun SmartEngineScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "智慧引擎",
                        description = "返回高级调试",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            if (!shizukuGranted) {
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Apps,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以启用智慧引擎功能",
                            isError = true
                        ) {}
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "用户上报") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Person,
                            title = "用户上报",
                            description = "向智慧引擎发送用户 kill 广播",
                            onClick = { navController.navigate(Screen.SmartEngineUserReport.route) }
                        ) {}
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "功耗管控") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.BatteryAlert,
                            title = "不允许某应用高耗电",
                            description = "限制指定应用的高耗电行为",
                            onClick = { navController.navigate(Screen.SmartEnginePower.route) }
                        ) {}
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "ABE 总开关") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Settings,
                            title = "智慧引擎全局开关",
                            description = "ABE 总开关（省电、消息、异常处理等），关闭后智慧引擎所有功能失效",
                            onClick = { navController.navigate(Screen.SmartEngineAbeSwitch.route) }
                        ) {}
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "配置管理") {
                    item {
                        BaseWidget(
                            iconSpec = AppIcons.Refresh,
                            title = "强制更新所有配置项",
                            description = "刷新智慧引擎全部配置",
                            onClick = { navController.navigate(Screen.SmartEngineConfigUpdate.route) }
                        ) {}
                    }
                    item {
                        BaseWidget(
                            icon = Icons.Default.BugReport,
                            title = "线程异常上报",
                            description = "获取应用线程并上报异常",
                            onClick = { navController.navigate(Screen.SmartEngineThread.route) }
                        ) {}
                    }
                    item {
                        BaseWidget(
                            icon = Icons.Default.CloudSync,
                            title = "云控触发",
                            description = "强制从云端拉取最新配置",
                            onClick = { navController.navigate(Screen.CloudTrigger.route) }
                        ) {}
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }
}
