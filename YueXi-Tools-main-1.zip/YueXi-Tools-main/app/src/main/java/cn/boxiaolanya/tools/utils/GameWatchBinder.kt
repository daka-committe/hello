/**
 * 通过 `gamewatch_server` Binder 调用 `IGameWatch.execute`（AIDL transact code = [EXECUTE_CODE]）。
 *
 * ## 协议概要（逆向自 vivo GameWatch）
 * 1. `ServiceManager.getService("gamewatch_server")`
 * 2. data.writeInterfaceToken([DESCRIPTOR])
 * 3. data.writeString(executorName)
 * 4. [buildArgPack]：参数类型 byte[] + 各参数 Parcel 序列化
 * 5. binder.transact(5, data, reply, 0)
 *
 * [executors] 元数据驱动 [cn.boxiaolanya.tools.ui.pages.tools.GameWatchBinderIpcScreen] 动态表单；
 * 详细说明见 assets/GameWatch-Binder.md。
 *
 * 与 [GameWatchCommands] 广播方式互补：Binder 可调用更多内部 executor。
 */
package cn.boxiaolanya.tools.utils

import android.os.IBinder
import android.os.Parcel
import android.util.Log

object GameWatchBinder {
    private const val TAG = "GameWatchBinder"

    /** ServiceManager 注册名 */
    private const val SERVER_NAME = "gamewatch_server"

    /** transact 前 writeInterfaceToken 使用 */
    private const val DESCRIPTOR = "com.vivo.gamewatch.common.IGameWatch"

    /** IGameWatch.execute 的事务码 */
    private const val EXECUTE_CODE = 5

    /** 参数类型名 → GameWatch 协议 type id；未知类型默认按 int(4) */
    private val TYPE_MAP = mapOf(
        "void" to 0, "null" to 1, "boolean" to 2, "byte" to 3,
        "int" to 4, "long" to 5, "String" to 6, "IBinder" to 7,
        "byte[]" to 8, "String[]" to 9, "int[]" to 10, "long[]" to 11,
        "float" to 13, "float[]" to 14
    )

    /** 单个 executor 形参描述，供 UI 生成输入框 label */
    data class ExecutorParam(val type: String, val name: String, val description: String)

    /** 可调用 executor 定义：名称、参数列表、返回类型、中文说明 */
    data class Executor(val name: String, val params: List<ExecutorParam>, val returnType: String, val description: String)

    /** 已收录的 executor _catalog；新增项需同步 Binder 教程文档 */
    val executors = listOf(
        Executor("hang_up_game", listOf(
            ExecutorParam("int", "pid", "进程 ID"),
            ExecutorParam("int", "state", "状态 (0=恢复, 1=挂起)")
        ), "int", "游戏挂起管理"),
        Executor("vgt_server_register", listOf(
            ExecutorParam("String", "serverName", "服务器名称"),
            ExecutorParam("IBinder", "binder", "Binder 对象 (留空使用空Binder)"),
            ExecutorParam("boolean", "isServer", "是否服务器")
        ), "void", "VGT 服务器注册"),
        Executor("callback_register", listOf(
            ExecutorParam("int", "flags", "标志位"),
            ExecutorParam("IBinder", "callbackBinder", "回调 Binder (留空使用空Binder)")
        ), "void", "多线程回调注册"),
        Executor("sdkinfo_getter_register", listOf(
            ExecutorParam("String", "jsonConfig", "JSON 配置字符串"),
            ExecutorParam("IBinder", "callbackBinder", "回调 Binder (留空使用空Binder)")
        ), "void", "SDK 信息获取器注册"),
        Executor("dual_resume", listOf(
            ExecutorParam("int", "pid", "进程 ID"),
            ExecutorParam("String", "pkgName", "包名"),
            ExecutorParam("int", "flags", "标志位")
        ), "void", "双分辨率恢复"),
        Executor("notify_render_thread", listOf(
            ExecutorParam("String", "pkgName", "包名"),
            ExecutorParam("int", "pid", "进程 ID"),
            ExecutorParam("String", "threadName", "线程名"),
            ExecutorParam("int", "threadId", "线程 ID"),
            ExecutorParam("int", "width", "宽度"),
            ExecutorParam("int", "height", "高度")
        ), "void", "渲染线程通知"),
        Executor("notify_target_fps", listOf(
            ExecutorParam("String", "pkgName", "包名"),
            ExecutorParam("int", "uid", "用户 ID"),
            ExecutorParam("int", "targetFps", "目标帧率"),
            ExecutorParam("int", "minFps", "最小帧率"),
            ExecutorParam("int", "maxFps", "最大帧率"),
            ExecutorParam("int", "refreshRate", "刷新率"),
            ExecutorParam("int", "mode", "模式"),
            ExecutorParam("int", "thermalLevel", "温控等级"),
            ExecutorParam("int", "flags", "标志位")
        ), "void", "目标 FPS 通知"),
        Executor("net_opt", listOf(
            ExecutorParam("String", "key", "键"),
            ExecutorParam("String", "value", "值")
        ), "void", "网络优化"),
        Executor("game_space", listOf(
            ExecutorParam("int", "type", "类型 (0=性能状态)")
        ), "int[]", "游戏空间查询"),
        Executor("info_provide", listOf(
            ExecutorParam("int", "type", "类型 (1=版本, 2=性能, 3=FPS列表, 4=GPU配置, 5=AI VRS配置)")
        ), "Object", "信息提供"),
        Executor("notify_game_hang", listOf(
            ExecutorParam("String", "pkgName", "包名"),
            ExecutorParam("String", "action", "动作"),
            ExecutorParam("int", "value", "值 (可选)")
        ), "void", "游戏挂起通知"),
        Executor("checkPermission", listOf(
            ExecutorParam("String", "permissionName", "权限名")
        ), "boolean", "权限检查"),
        Executor("turbo", listOf(
            ExecutorParam("int", "uid", "用户 ID"),
            ExecutorParam("int", "pid", "进程 ID"),
            ExecutorParam("int", "cmd", "命令"),
            ExecutorParam("String", "pkgName", "包名")
        ), "Object", "多线程服务"),
        Executor("turbo2", listOf(
            ExecutorParam("int", "uid", "用户 ID"),
            ExecutorParam("int", "pid", "进程 ID"),
            ExecutorParam("int", "cmd", "命令"),
            ExecutorParam("String", "pkgName", "包名"),
            ExecutorParam("int[]", "intArray1", "int数组1 (格式: 1,2,3)"),
            ExecutorParam("int[]", "intArray2", "int数组2 (格式: 1,2,3)"),
            ExecutorParam("String[]", "strArray1", "字符串数组1 (格式: a,b,c)"),
            ExecutorParam("String[]", "strArray2", "字符串数组2 (格式: a,b,c)")
        ), "Object", "扩展多线程服务"),
        Executor("vaptTurbo", listOf(
            ExecutorParam("int", "uid", "用户 ID"),
            ExecutorParam("int", "pid", "进程 ID"),
            ExecutorParam("int", "cmd", "命令"),
            ExecutorParam("String", "pkgName", "包名"),
            ExecutorParam("int[]", "intArray1", "int数组1 (格式: 1,2,3)"),
            ExecutorParam("int[]", "intArray2", "int数组2 (格式: 1,2,3)"),
            ExecutorParam("String[]", "strArray1", "字符串数组1 (格式: a,b,c)"),
            ExecutorParam("String[]", "strArray2", "字符串数组2 (格式: a,b,c)")
        ), "Object", "VAPT 多线程服务"),
        Executor("netcallback", listOf(
            ExecutorParam("int", "pid", "进程 ID"),
            ExecutorParam("String", "url", "URL"),
            ExecutorParam("String", "responseBody", "响应体")
        ), "void", "网络回调"),
        Executor("control_panel", listOf(
            ExecutorParam("String", "pkgName", "包名"),
            ExecutorParam("String", "key", "配置键 (可选)"),
            ExecutorParam("String", "value", "配置值 (可选)"),
            ExecutorParam("String", "scope", "作用域 (可选)")
        ), "Object", "GPU 控制面板"),
        Executor("vsync_imd", emptyList(), "Object", "V-Sync 即时模式"),
        Executor("notify_to_app_common", listOf(
            ExecutorParam("int", "uid", "用户 ID"),
            ExecutorParam("int", "pid", "进程 ID"),
            ExecutorParam("String", "pkgName", "包名"),
            ExecutorParam("String", "action", "动作"),
            ExecutorParam("String", "extras", "额外数据"),
            ExecutorParam("int", "flags", "标志位")
        ), "void", "通用应用通知"),
        Executor("magt_extension_control", listOf(
            ExecutorParam("int", "targetPid", "目标 PID"),
            ExecutorParam("int", "serviceCode", "服务代码"),
            ExecutorParam("int", "arg1", "参数1"),
            ExecutorParam("int", "arg2", "参数2")
        ), "int", "MAGT 扩展控制"),
        Executor("GameLib", listOf(
            ExecutorParam("int", "gameId", "游戏 ID")
        ), "String", "游戏库状态"),
        Executor("perf_tool_dump_begin", listOf(
            ExecutorParam("boolean", "enable", "启用"),
            ExecutorParam("int", "pid", "进程 ID"),
            ExecutorParam("int", "type", "类型"),
            ExecutorParam("String", "outputPath", "输出路径")
        ), "void", "VCS 性能转储"),
        Executor("is_support_vnss", listOf(
            ExecutorParam("String", "pkgName", "包名")
        ), "boolean", "VNSS 游戏支持检查"),
        Executor("notify_api_type", listOf(
            ExecutorParam("int", "apiType", "API 类型"),
            ExecutorParam("int", "pid", "进程 ID"),
            ExecutorParam("int", "flags", "标志位")
        ), "void", "图形 API 类型通知"),
        Executor("ecosdk", listOf(
            ExecutorParam("String", "jsonCmd", "JSON 命令")
        ), "void", "Eco SDK Q3 配置")
    )

    /** 从 ServiceManager 获取 gamewatch_server。 */
    fun getService(): IBinder? {
        return try {
            val sm = Class.forName("android.os.ServiceManager")
            val m = sm.getDeclaredMethod("getService", String::class.java)
            m.invoke(null, SERVER_NAME) as? IBinder
        } catch (e: Exception) {
            Log.e(TAG, "getService failed: ${e.message}")
            null
        }
    }

    fun isServiceAvailable(): Boolean {
        return getService() != null
    }

    /** 按 executor 名与参数列表发起 IPC；参数顺序须与 [Executor.params] 一致。 */
    fun execute(executorName: String, args: List<Pair<String, String>>): Pair<Boolean, String> {
        val service = getService() ?: return Pair(false, "gamewatch_server not found")
        return try {
            val executor = executors.find { it.name == executorName } ?: return Pair(false, "Unknown executor: $executorName")
            val data = Parcel.obtain()
            val reply = Parcel.obtain()
            try {
                data.writeInterfaceToken(DESCRIPTOR)
                data.writeString(executorName)
                buildArgPack(data, executor.params, args)
                service.transact(EXECUTE_CODE, data, reply, 0)
                Pair(true, "execute success")
            } finally {
                reply.recycle()
                data.recycle()
            }
        } catch (e: Exception) {
            Log.e(TAG, "execute failed: ${e.message}")
            Pair(false, e.message ?: "unknown error")
        }
    }

    /** 将参数值按 TYPE_MAP 编码写入 Parcel（与 GameWatch 服务端协议对齐）。 */
    private fun buildArgPack(data: Parcel, paramDefs: List<ExecutorParam>, args: List<Pair<String, String>>) {
        if (paramDefs.isEmpty()) {
            data.writeByteArray(byteArrayOf(0))
            return
        }
        val types = paramDefs.map { TYPE_MAP[it.type] ?: 4 }
        data.writeByteArray(types.map { it.toByte() }.toByteArray())
        for (i in paramDefs.indices) {
            val argValue = args.getOrNull(i)?.second ?: ""
            when (paramDefs[i].type) {
                "int" -> data.writeInt(argValue.toIntOrNull() ?: 0)
                "long" -> data.writeLong(argValue.toLongOrNull() ?: 0L)
                "boolean" -> data.writeInt(if (argValue.toBoolean() || argValue == "1") 1 else 0)
                "String" -> data.writeString(argValue)
                "float" -> data.writeFloat(argValue.toFloatOrNull() ?: 0f)
                "int[]" -> {
                    val arr = argValue.split(",").mapNotNull { it.trim().toIntOrNull() }.toIntArray()
                    data.writeIntArray(arr)
                }
                "long[]" -> {
                    val arr = argValue.split(",").mapNotNull { it.trim().toLongOrNull() }.toLongArray()
                    data.writeLongArray(arr)
                }
                "String[]" -> data.writeStringArray(argValue.split(",").map { it.trim() }.toTypedArray())
                "byte" -> data.writeByte(argValue.toByteOrNull() ?: 0)
                "IBinder" -> {
                    if (argValue.isEmpty()) {
                        data.writeStrongBinder(null)
                    }
                }
            }
        }
    }
}