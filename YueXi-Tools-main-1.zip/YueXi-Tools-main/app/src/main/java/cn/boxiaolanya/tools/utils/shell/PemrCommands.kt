package cn.boxiaolanya.tools.utils.shell

object PemrCommands {
    val UPDATE_FINISH: String get() = ShellObf.s("pemr.update")
    val TRIGGER_CONFIG_UPDATE: String get() = UPDATE_FINISH
}
