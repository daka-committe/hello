/**
 * Shizuku Binder 存活与运行时权限状态探测。
 *
 * 不包含命令执行（见 [ShizukuExec]）。
 * [isAvailable]：用户是否已启动 Shizuku 服务
 * [isGranted]：服务可用且本应用已获得 Shizuku 授权
 */
package cn.boxiaolanya.tools.utils

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuHelper {

    fun isAvailable(): Boolean = try {
        Shizuku.pingBinder()
    } catch (_: Exception) {
        false
    }

    fun isGranted(): Boolean = try {
        isAvailable() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Exception) {
        false
    }
}
