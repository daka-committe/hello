/**
 * iQOO / vivo 性能模式、Monster、省电类型相关命令。
 */
package cn.boxiaolanya.tools.utils.shell

object VivoPerfCommands {

    val MONSTER_MODE_ON: String
        get() = ShellObf.s("perf.power_1011")

    val MONSTER_MODE_OFF: String
        get() = ShellObf.s("perf.power_1004")

    private val SET_GAME_PLUS get() = ShellObf.s("perf.set_game_plus")
    private val SET_PWR_SECURE get() = ShellObf.s("perf.set_pwr_secure")
    private val SET_PWR_SYSTEM get() = ShellObf.s("perf.set_pwr_system")
    private val SET_MONSTER_KEY get() = ShellObf.s("perf.set_monster")

    val ICON_RADIUS_BROADCAST: String
        get() = ShellObf.s("perf.icon_radius")

    fun gamePlusOn(): String = SET_GAME_PLUS + "1"

    fun gamePlusOff(): String = SET_GAME_PLUS + "0"

    fun powerSaveSecure(value: String): String = SET_PWR_SECURE + value

    fun powerSaveSystem(value: String): String = SET_PWR_SYSTEM + value

    fun monsterKeyOn(): String = SET_MONSTER_KEY + "1"

    fun monsterKeyOff(): String = SET_MONSTER_KEY + "0"
}
