/**
 * 远程 update.json 版本检查与强制更新对话框。
 */
package cn.boxiaolanya.tools.utils

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.appcompat.app.AlertDialog
import cn.boxiaolanya.tools.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object UpdateChecker {

    private const val UPDATE_URL = "https://raw.giteeusercontent.com/boxiaolanya2008/update/raw/master/update.json"

    suspend fun check(context: Context): UpdateInfo? = withContext(Dispatchers.IO) {
        try {
            val client = OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .build()
            val request = Request.Builder().url(UPDATE_URL).get().build()
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) return@withContext null

            val body = response.body?.string() ?: return@withContext null
            val json = JSONObject(body)

            val remoteVersion = json.optInt("versionCode", 0)
            if (remoteVersion <= BuildConfig.VERSION_CODE) return@withContext null

            UpdateInfo(
                versionCode = remoteVersion,
                versionName = json.optString("versionName", ""),
                forceUpdate = json.optBoolean("forceUpdate", false),
                title = json.optString("title", "发现新版本"),
                message = json.optString("message", ""),
                url = json.optString("url", ""),
                md5 = json.optString("md5", "")
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun showForceDialog(activity: Activity, info: UpdateInfo) {
        AlertDialog.Builder(activity)
            .setTitle(info.title)
            .setMessage("""
                当前版本：${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})
                最新版本：${info.versionName} (${info.versionCode})
                
                ${info.message}
                
                必须更新后方可继续使用。""".trimIndent())
            .setCancelable(false)
            .setPositiveButton("立即更新") { _, _ ->
                if (info.url.isNotBlank()) {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(info.url))
                        activity.startActivity(intent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                activity.finish()
            }
            .setNegativeButton("退出应用") { _, _ ->
                activity.finish()
            }
            .show()
    }

    data class UpdateInfo(
        val versionCode: Int,
        val versionName: String,
        val forceUpdate: Boolean,
        val title: String,
        val message: String,
        val url: String,
        val md5: String
    )
}
