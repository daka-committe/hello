/**
 * 启动前检测不可共存的冲突包（如 com.viqitos.tools）。
 */
package cn.boxiaolanya.tools.utils

import android.content.Context
import android.content.pm.PackageManager

object PackageChecker {
    private val FORBIDDEN_PACKAGES = listOf(
        "com.viqitos.tools",
        "com.viqitos.tool"
    )

    fun checkForbiddenApps(context: Context): List<String> {
        val foundApps = mutableListOf<String>()
        val packageManager = context.packageManager

        for (packageName in FORBIDDEN_PACKAGES) {
            try {
                packageManager.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES)
                foundApps.add(packageName)
            } catch (e: PackageManager.NameNotFoundException) {
            } catch (e: Exception) {
            }
        }

        return foundApps
    }

    fun hasForbiddenApps(context: Context): Boolean {
        return checkForbiddenApps(context).isNotEmpty()
    }
}
