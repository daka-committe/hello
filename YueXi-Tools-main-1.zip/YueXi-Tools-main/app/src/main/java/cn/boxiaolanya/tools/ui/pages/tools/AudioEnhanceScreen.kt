/**
 * 音效增强 UI：均衡器频段、响度、输出设备切换。
 *
 * 不依赖 Shizuku，经 [cn.boxiaolanya.tools.audio.AudioController] 调用系统 AudioEffect API。
 * 部分机型需连接耳机或扬声器路由后才显示效果选项。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import cn.boxiaolanya.tools.audio.AudioController
import cn.boxiaolanya.tools.audio.AudioOutputMode
import cn.boxiaolanya.tools.audio.AudioPreferences
import cn.boxiaolanya.tools.audio.ImmersiveAudioController
import cn.boxiaolanya.tools.ui.pages.Screen
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AudioEnhanceScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val context = LocalContext.current
    val activity = context as? Activity
    var audioController by remember { mutableStateOf<AudioController?>(null) }
    var immersiveController by remember { mutableStateOf<ImmersiveAudioController?>(null) }
    var currentMode by remember { mutableStateOf(AudioOutputMode.SYSTEM) }
    var isRefreshing by remember { mutableStateOf(false) }
    var hasBluetoothPermission by remember { mutableStateOf(false) }

    val bluetoothPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        hasBluetoothPermission = allGranted
        if (allGranted) {
            Toast.makeText(context, "蓝牙权限已授予", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "蓝牙权限被拒绝，蓝牙音频功能可能无法使用", Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(Unit) {
        AudioPreferences.init(context)
        audioController = AudioController(context)
        immersiveController = ImmersiveAudioController(context)
        currentMode = audioController?.detectCurrentMode() ?: AudioOutputMode.SYSTEM
    }

    LaunchedEffect(audioController) {
        while (true) {
            delay(1000L)
            if (!isRefreshing) {
                currentMode = audioController?.detectCurrentMode() ?: AudioOutputMode.SYSTEM
            }
        }
    }

    fun requestBluetoothPermission(onGranted: () -> Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) {
                hasBluetoothPermission = true
                onGranted()
            } else {
                bluetoothPermissionLauncher.launch(arrayOf(
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
                ))
            }
        } else {
            hasBluetoothPermission = true
            onGranted()
        }
    }

    fun switchMode(mode: AudioOutputMode) {
        if (mode == AudioOutputMode.BLUETOOTH || mode == AudioOutputMode.BLUETOOTH_A2DP) {
            if (!hasBluetoothPermission) {
                requestBluetoothPermission { switchMode(mode) }
                return
            }
        }

        isRefreshing = true
        when (mode) {
            AudioOutputMode.SPEAKER -> audioController?.switchToSpeaker()
            AudioOutputMode.EARPIECE -> audioController?.switchToEarpiece()
            AudioOutputMode.SPEAKER_SYSTEM -> audioController?.switchToSpeakerSystem()
            AudioOutputMode.BLUETOOTH -> audioController?.switchToBluetooth()
            AudioOutputMode.BLUETOOTH_A2DP -> audioController?.switchToBluetoothA2dp()
            AudioOutputMode.SYSTEM, AudioOutputMode.WIRED_HEADSET -> audioController?.resetToSystem()
        }
        MainScope().launch {
            delay(800L)
            currentMode = audioController?.detectCurrentMode() ?: AudioOutputMode.SYSTEM
            isRefreshing = false
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "音效增强",
                        description = "返回悦玺工具箱",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            if (!shizukuGranted) {
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Apps,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以启用音效增强",
                            isError = true
                        ) {}
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "当前输出") {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = currentMode.label,
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                val modes = listOf(
                    AudioOutputMode.SPEAKER to Pair(Icons.Default.SpeakerGroup, "扬声器"),
                    AudioOutputMode.SPEAKER_SYSTEM to Pair(Icons.Default.Speaker, "音响系统"),
                    AudioOutputMode.EARPIECE to Pair(Icons.Default.PhoneInTalk, "听筒"),
                    AudioOutputMode.SYSTEM to Pair(Icons.Default.Smartphone, "系统默认"),
                    AudioOutputMode.BLUETOOTH to Pair(Icons.Default.Bluetooth, "蓝牙通话"),
                    AudioOutputMode.BLUETOOTH_A2DP to Pair(Icons.Default.Bluetooth, "蓝牙音乐")
                )

                SettingSplicedColumnGroup(title = "音频输出") {
                    item {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            modes.chunked(2).forEach { row ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    row.forEach { (mode, iconLabel) ->
                                        AudioModeCard(
                                            icon = iconLabel.first,
                                            label = iconLabel.second,
                                            isSelected = currentMode == mode,
                                            onClick = { switchMode(mode) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    if (row.size == 1) {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "音效设置") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Equalizer,
                            title = "沉浸式音效",
                            description = "虚拟环绕、低音增强、音量提升",
                            onClick = { navController.navigate(Screen.AudioImmersive.route) }
                        ) {}
                    }
                    item {
                        BaseWidget(
                            icon = Icons.Default.SpeakerGroup,
                            title = "音效增强",
                            description = "音频输出模式切换",
                            onClick = { navController.navigate(Screen.AudioEnhance.route) }
                        ) {}
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }
}

@Composable
private fun AudioModeCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        modifier = modifier.height(80.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                icon,
                contentDescription = label,
                modifier = Modifier.size(28.dp),
                tint = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.titleMedium,
                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
