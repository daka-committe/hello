/**
 * 电量摘要各配置项的通俗名称与说明（对照 fuelsummary_uc.xml）。
 */
package cn.boxiaolanya.tools.fuel

data class FuelFieldGuide(
    val friendlyName: String,
    val intro: String,
    val slotHints: List<String> = emptyList(),
)

data class FuelSectionGuide(
    val title: String,
    val summary: String,
)

object FuelSummaryFieldGuide {

    val sectionGuides = mapOf(
        "normal_params" to FuelSectionGuide(
            title = "日常使用与待机",
            summary = "管平时待机、掉电快慢、什么时候关机等，和充电无关。",
        ),
        "driver_params" to FuelSectionGuide(
            title = "电池基本信息",
            summary = "告诉手机这块电池有多大容量，影响剩余电量显示。",
        ),
        "charging_params" to FuelSectionGuide(
            title = "充电分档",
            summary = "不同电量区间用不同充电力度，一行代表一档，数字顺序不要打乱。",
        ),
        "battery_curve" to FuelSectionGuide(
            title = "电量曲线",
            summary = "给系统用的电量换算数据，改错可能导致电量显示不准。",
        ),
    )

    fun resolve(
        sectionKey: String,
        displayLabel: String,
        slotIndex: Int? = null,
    ): FuelFieldGuide {
        val base = lookup(sectionKey, displayLabel)
        if (slotIndex == null) return base

        val slotIntro = base.slotHints.getOrNull(slotIndex)
            ?: "这一组里的第 ${slotIndex + 1} 个数，按原来顺序填。"

        return base.copy(
            intro = "${base.intro}\n\n本项：$slotIntro",
        )
    }

    fun fullConfigPath(sectionKey: String, displayLabel: String, slotIndex: Int?): String {
        val slotSuffix = slotIndex?.let { " · 第 ${it + 1} 个数" }.orEmpty()
        return "$sectionKey / $displayLabel$slotSuffix"
    }

    private fun lookup(sectionKey: String, displayLabel: String): FuelFieldGuide {
        fieldRegistry[displayLabel]?.let { return it }

        if (displayLabel.startsWith("hex-array")) {
            return FuelFieldGuide(
                friendlyName = "电量曲线十六进制数据",
                intro = "电池厂商写入的曲线片段，显示为两位十六进制。改错可能导致电量百分比不准。",
            )
        }

        if (displayLabel.startsWith("integer-array")) {
            return chargingArrayGuides[sectionKey to displayLabel]
                ?: normalArrayGuides[sectionKey to displayLabel]
                ?: FuelFieldGuide(
                    friendlyName = displayLabel,
                    intro = "一组按顺序排列的数字，改之前建议先记下原值。",
                )
        }

        return FuelFieldGuide(
            friendlyName = displayLabel,
            intro = "系统里的自定义配置，不清楚作用时请先备份再改。",
        )
    }

    private val fieldRegistry = mapOf(
        "CONFIG.version" to FuelFieldGuide(
            friendlyName = "配置文件版本",
            intro = "整套规则的版本号。不懂的话保持默认即可，乱改可能导致系统不认这份配置。",
        ),
        "pw_standby_capacity" to FuelFieldGuide(
            friendlyName = "待机还剩多少电",
            intro = "屏幕长时间关闭、几乎不用手机时，用这个数判断算不算进入「待机省电」状态。",
        ),
        "pw_standby_seconds" to FuelFieldGuide(
            friendlyName = "多久算真正待机",
            intro = "手机要安静、不用多久（单位：秒），才按上面的待机规则来算电量。3600 大约是 1 小时。",
        ),
        "pw_drop_levels" to FuelFieldGuide(
            friendlyName = "掉多少格才算掉电",
            intro = "电量显示往下掉几格，系统才认为真的在耗电，可以减少数字来回跳。",
        ),
        "vddmin_seconds" to FuelFieldGuide(
            friendlyName = "低压持续多久才动作",
            intro = "电池电压偏低要持续多少秒，才会触发相关的保护或提醒。",
        ),
        "fcc_too_low" to FuelFieldGuide(
            friendlyName = "电池容量太低提醒线",
            intro = "觉得电池「满充容量」低于这个值时，可能按老化或需要校准来处理。",
        ),
        "sf_shutdown_vbat" to FuelFieldGuide(
            friendlyName = "软件关机电压",
            intro = "电量快用完时，系统打算在多少电压（毫伏）让你关机，比硬件那条线温和一些。",
        ),
        "hw_shutdown_vbat" to FuelFieldGuide(
            friendlyName = "硬件关机电压",
            intro = "最后一道防线，电压低到这个数字，硬件会直接断电，一般比软件那条更低。",
        ),
        "full_drop_seconds" to FuelFieldGuide(
            friendlyName = "满电后多久算开始掉",
            intro = "显示满电之后，要等多少秒才承认电量开始往下走。",
        ),
        "low_drop_seconds" to FuelFieldGuide(
            friendlyName = "低电量时掉电确认时间",
            intro = "电量已经不高时，往下掉要持续多少秒，才算真的在掉电。",
        ),
        "plug_interval_seconds" to FuelFieldGuide(
            friendlyName = "插电后多久查一次",
            intro = "插上充电器后，隔多少秒看一次充电状态。数字小查得更勤，可能更准但略费一点电。",
        ),
        "unconditional_report" to FuelFieldGuide(
            friendlyName = "是否总是上报电量",
            intro = "填 0 表示按平常规则上报；填 1 表示更勤快地告诉系统当前电量。",
        ),
        "uspace_cycle" to FuelFieldGuide(
            friendlyName = "用户侧上报周期",
            intro = "一般保持 0。只有你知道厂商特殊用途时再动。",
        ),
        "board_thermal_thresholds" to FuelFieldGuide(
            friendlyName = "主板温度分档",
            intro = "三个数，用来划分主板凉、温、热几档，配合省电或限性能。",
            slotHints = listOf(
                "第一档：偏凉时的分界",
                "第二档：偏温时的分界",
                "第三档：偏热时的分界",
            ),
        ),
        "vivo,capacity-mAh" to FuelFieldGuide(
            friendlyName = "电池标称容量",
            intro = "这块电池标称多少毫安时（mAh），例如 4500 就是常见的大电池。填错会影响剩余电量和续航估算。",
        ),
        "vivo,normal-tc-data" to FuelFieldGuide(
            friendlyName = "普通充电温控",
            intro = "三个数，和普通充电时的温度保护有关，按原厂顺序填写。",
            slotHints = listOf(
                "第一个数：温控开关或模式",
                "第二个数：偏热时的限制",
                "第三个数：更热时的限制",
            ),
        ),
        "qcom,fg-profile-data" to FuelFieldGuide(
            friendlyName = "电量换算配置",
            intro = "三个数，给电量计换算用，和下面十六进制数据是一套，不要乱改顺序。",
            slotHints = listOf(
                "第一个数",
                "第二个数",
                "第三个数",
            ),
        ),
    )

    private val normalArrayGuides = mapOf(
        ("normal_params" to "integer-array #1") to FuelFieldGuide(
            friendlyName = "温度或电量参考三档",
            intro = "三个参考值，常用来划分不同温度或电量区间，按顺序填写。",
            slotHints = listOf(
                "第一个参考值",
                "第二个参考值",
                "第三个参考值",
            ),
        ),
    )

    private val chargingSevenSlotHints = listOf(
        "这一档从多少电量（%）开始算",
        "这一档到多少电量（%）结束",
        "这一档充多快的限制值",
        "目标充电电压（大数字，按原厂填）",
        "附加限制 1",
        "附加限制 2",
        "附加限制 3",
    )

    private val chargingArrayGuides = mapOf(
        ("charging_params" to "integer-array #1") to FuelFieldGuide(
            friendlyName = "充电 · 极高电量或特殊档",
            intro = "电量很高或特殊情况下用这一行，一共 7 个数，顺序不能乱。",
            slotHints = chargingSevenSlotHints,
        ),
        ("charging_params" to "integer-array #2") to FuelFieldGuide(
            friendlyName = "充电 · 电量大约 45%～55%",
            intro = "中等偏高电量时怎么充，一共 7 个数。",
            slotHints = chargingSevenSlotHints,
        ),
        ("charging_params" to "integer-array #3") to FuelFieldGuide(
            friendlyName = "充电 · 电量大约 15%～45%",
            intro = "中等偏低电量时的充电力度。",
            slotHints = chargingSevenSlotHints,
        ),
        ("charging_params" to "integer-array #4") to FuelFieldGuide(
            friendlyName = "充电 · 电量大约 10%～15%",
            intro = "电量偏低时的充电设置。",
            slotHints = chargingSevenSlotHints,
        ),
        ("charging_params" to "integer-array #5") to FuelFieldGuide(
            friendlyName = "充电 · 电量大约 5%～10%",
            intro = "电量很低时的充电设置。",
            slotHints = chargingSevenSlotHints,
        ),
        ("charging_params" to "integer-array #6") to FuelFieldGuide(
            friendlyName = "充电 · 电量大约 0%～5%",
            intro = "快没电时的充电设置。",
            slotHints = chargingSevenSlotHints,
        ),
        ("charging_params" to "integer-array #7") to FuelFieldGuide(
            friendlyName = "充电 · 占位或关闭用的一行",
            intro = "通常是给系统留的特殊行，负数表示关闭或不用，不懂就保持原样。",
            slotHints = chargingSevenSlotHints,
        ),
    )

    fun guideForConfigVersion(): FuelFieldGuide = fieldRegistry["CONFIG.version"]!!

    fun guideForHexArray(slotIndex: Int, totalSlots: Int): FuelFieldGuide {
        val hints = (0 until totalSlots).map { idx ->
            "第 ${idx + 1} 段十六进制数据（两位，如 A9），共 $totalSlots 段，顺序不要打乱。"
        }
        return FuelFieldGuide(
            friendlyName = "电量曲线十六进制数据",
            intro = "电池厂商写入的曲线片段，显示为两位十六进制。改错可能导致电量百分比不准。",
            slotHints = hints,
        ).let { base ->
            val slotIntro = hints.getOrElse(slotIndex) { "第 ${slotIndex + 1} 段数据" }
            base.copy(intro = "${base.intro}\n\n本项：$slotIntro")
        }
    }
}
