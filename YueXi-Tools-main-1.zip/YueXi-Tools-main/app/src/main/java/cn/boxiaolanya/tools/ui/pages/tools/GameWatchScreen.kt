/**
 * GameWatch 功能 hub：导航至 GPU 切换、帧率、画质、Binder IPC、配置更新等子页。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.pages.Screen
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup

@Composable
fun GameWatchScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "GameWatch",
                        description = "返回高级调试",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            if (!shizukuGranted) {
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Apps,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以启用 GameWatch 功能",
                            isError = true
                        ) {}
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "Binder IPC") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Code,
                            title = "Binder IPC 注入",
                            description = "gamewatch_server 执行器调用",
                            onClick = { navController.navigate(Screen.GameWatchBinderIpc.route) }
                        ) {}
                    }
                    item {
                        BaseWidget(
                            icon = Icons.Default.MenuBook,
                            title = "教程",
                            description = "25个命令参数填表教程",
                            onClick = { navController.navigate(Screen.GameWatchBinderTutorial.route) }
                        ) {}
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "场景管理") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.SwapHoriz,
                            title = "场景切换",
                            description = "管理应用游戏场景状态",
                            onClick = { navController.navigate(Screen.GameWatchSceneSwitch.route) }
                        ) {}
                    }
                    item {
                        BaseWidget(
                            icon = Icons.Default.Memory,
                            title = "配置切换",
                            description = "动态切换游戏配置方案",
                            onClick = { navController.navigate(Screen.GameWatchGpuSwap.route) }
                        ) {}
                    }
                    item {
                        BaseWidget(
                            icon = Icons.Default.HdrStrong,
                            title = "画质通知",
                            description = "通知 GameCube 画质变化",
                            onClick = { navController.navigate(Screen.GameWatchQuality.route) }
                        ) {}
                    }
                    item {
                        BaseWidget(
                            icon = Icons.Default.Speed,
                            title = "目标帧率通知",
                            description = "通知 GameCube 目标帧率变化",
                            onClick = { navController.navigate(Screen.GameWatchTargetFps.route) }
                        ) {}
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "配置管理") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Sync,
                            title = "GameWatch 配置更新",
                            description = "自动重载 vge_configs.zip",
                            onClick = { navController.navigate(Screen.GameWatchConfigUpdate.route) }
                        ) {}
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }
}
