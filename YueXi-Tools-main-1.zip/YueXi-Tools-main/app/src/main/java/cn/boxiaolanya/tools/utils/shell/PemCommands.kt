package cn.boxiaolanya.tools.utils.shell

object PemCommands {
    val REFRESH_CONFIG: String get() = ShellObf.s("pem.refresh")
    val SYSTEM_UPGRADE_CHECK: String get() = ShellObf.s("pem.upgrade_check")
    val CLOUD_ACTION: String get() = ShellObf.s("pem.cloud")
    val TEMP_STATE_CHANGE: String get() = ShellObf.s("pem.temp_state")
}
