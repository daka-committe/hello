/**
 * GameCube / vivo 图形与性能相关系统 Binder 封装。
 *
 * 通过 ServiceManager 获取系统服务后直接使用 Parcel transact（无公开 SDK）。
 * 各 nested object 懒加载 binder；获取失败时 [isAvailable] 为 false，调用返回 "unavailable"。
 *
 * 消费者：
 * - [SuperResMainScreen] → [SurfaceFlinger.toggle]
 * - 实验/诊断页 → [RMS]、[VBoost]
 */
package cn.boxiaolanya.tools.utils

import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.Parcel

object GameCubeManager {

    /**
     * SurfaceFlinger 私有事务：超分辨率等 GameCube 能力开关。
     * transact code 120002，token `android.ui.ISurfaceComposer`。
     */
    object SurfaceFlinger {
        private var binder: IBinder? = null
        init {
            try {
                val sm = Class.forName("android.os.ServiceManager")
                binder = sm.getMethod("getService", String::class.java).invoke(null, "SurfaceFlinger") as? IBinder
                    ?: sm.getMethod("checkService", String::class.java).invoke(null, "SurfaceFlinger") as? IBinder
            } catch (_: Exception) {}
        }
        val isAvailable get() = binder != null

        /** @param enabled true 开启超分相关能力（依 ROM 语义） */
        fun toggle(enabled: Boolean): String {
            val b = binder ?: return "unavailable"
            return try {
                val p = Parcel.obtain(); val r = Parcel.obtain()
                p.writeInterfaceToken("android.ui.ISurfaceComposer")
                p.writeInt(if (enabled) 1 else 0)
                p.writeString("com.vivo.gamecube")
                val ok = b.transact(120002, p, r, 0)
                val result = if (ok) {
                    try { r.readException(); "code=" + r.readInt() }
                    catch (_: Exception) { "transact ok (no reply)" }
                } else "transact failed"
                p.recycle(); r.recycle()
                result
            } catch (e: Exception) { "fail: ${e.message}" }
        }
    }

    /**
     * 系统 RMS Binder（`ServiceManager.checkService("rms")`）。
     * acquireV2 / release 与 secure settings reason 为不同调度通道，可配合使用。
     */
    object RMS {
        private var binder: IBinder? = null
        init {
            try {
                val sm = Class.forName("android.os.ServiceManager")
                binder = sm.getMethod("checkService", String::class.java).invoke(null, "rms") as? IBinder
                    ?: sm.getMethod("getService", String::class.java).invoke(null, "rms") as? IBinder
            } catch (_: Exception) {}
        }
        val isAvailable get() = binder != null

        /** transact 25：创建命名场景 */
        fun createScene(name: String, priority: Int = 0, reserved: Boolean = false): String {
            val b = binder ?: return "unavailable"
            return try {
                val d = Parcel.obtain(); val r = Parcel.obtain()
                d.writeString(name); d.writeInt(priority); d.writeInt(if (reserved) 1 else 0)
                b.transact(25, d, r, 0)
                r.readException(); val code = r.readInt(); d.recycle(); r.recycle()
                "code=$code"
            } catch (e: Exception) { "fail: ${e.message}" }
        }

        /** transact 26：读取当前 active refresh rate */
        fun getActiveRate(): Float {
            val b = binder ?: return -1f
            return try {
                val d = Parcel.obtain(); val r = Parcel.obtain()
                b.transact(26, d, r, 0)
                r.readException(); val f = r.readFloat(); d.recycle(); r.recycle(); f
            } catch (_: Exception) { -1f }
        }

        /**
         * transact 31：V2 _acquire，参数顺序与系统 AIDL 对齐。
         * pid 固定写当前进程；reason 字符串可与 VIVO-RMS settings 区分使用。
         */
        fun acquireV2(
            scene: String, reason: String = "tools",
            minDuration: Int = 0, minFps: Int = 60, fps: Int = 120,
            dfps: Int = 120, maxRate: Int = 120, powerMode: Int = 1,
            framePacingFps: Int = 0, framePacingFlags: Int = 0,
            adjusterPriority: Int = 0, flags: Int = 0
        ): String {
            val b = binder ?: return "unavailable"
            return try {
                val d = Parcel.obtain(); val r = Parcel.obtain()
                d.writeLong(System.nanoTime())
                d.writeString(scene); d.writeString(reason)
                d.writeInt(minDuration); d.writeInt(minFps); d.writeInt(fps)
                d.writeInt(dfps); d.writeInt(maxRate); d.writeInt(powerMode)
                val pid = android.os.Process.myPid()
                d.writeInt(pid); d.writeInt(0)
                d.writeInt(0); d.writeInt(framePacingFps)
                d.writeInt(framePacingFlags); d.writeInt(adjusterPriority)
                d.writeInt(flags)
                val ok = b.transact(31, d, r, 0)
                val result = if (ok) {
                    try { r.readException(); "code=" + r.readInt() }
                    catch (_: Exception) { "transact ok (no reply)" }
                } else "transact failed"
                d.recycle(); r.recycle()
                result
            } catch (e: Exception) { "fail: ${e.message}" }
        }

        /** transact 24：按 pid 释放 acquire */
        fun release(): String {
            val b = binder ?: return "unavailable"
            return try {
                val d = Parcel.obtain(); val r = Parcel.obtain()
                d.writeInt(android.os.Process.myPid()); d.writeLong(0L)
                val ok = b.transact(24, d, r, 0)
                val result = if (ok) {
                    try { r.readException(); "code=" + r.readInt() }
                    catch (_: Exception) { "transact ok (no reply)" }
                } else "transact failed"
                d.recycle(); r.recycle()
                result
            } catch (e: Exception) { "fail: ${e.message}" }
        }
    }

    /**
     * vivo VBoost 服务：featureId + command + Bundle 扩展参数。
     * Android 15+ 需在 parcel 头 writeInterfaceToken。
     */
    object VBoost {
        private var binder: IBinder? = null
        init {
            try {
                val sm = Class.forName("android.os.ServiceManager")
                binder = sm.getMethod("getService", String::class.java).invoke(null, "vboost") as? IBinder
                    ?: sm.getMethod("checkService", String::class.java).invoke(null, "vboost") as? IBinder
            } catch (_: Exception) {}
        }
        val isAvailable get() = binder != null

        /**
         * @param command 2 时需传 level/timeout 写入 Bundle
         */
        fun invoke(featureId: Int, command: Int, level: Int = 0, timeout: Int = 0): String {
            val b = binder ?: return "unavailable"
            return try {
                val d = Parcel.obtain(); val r = Parcel.obtain()
                if (Build.VERSION.SDK_INT >= 35) {
                    d.writeInterfaceToken(b.interfaceDescriptor ?: "")
                }
                d.writeInt(featureId); d.writeInt(command)
                val bundle = Bundle().apply {
                    putBoolean("isWill", false)
                    putString("pkgName", "cn.boxiaolanya.tools")
                    putLong("appVersion", 1L); putInt("sdkVersion", 1)
                    if (command == 2) { putInt("level", level); putInt("timeout", timeout) }
                }
                d.writeBundle(bundle)
                b.transact(1, d, r, 0)
                r.readException()
                val code = r.readInt(); d.recycle(); r.recycle()
                "code=$code"
            } catch (e: Exception) { "fail: ${e.message}" }
        }

        /** 探测 transact 是否可达，输出 binder 类名与 reply 大小 */
        fun diagnose(): String {
            val b = binder ?: return "binder null"
            val sb = StringBuilder("binder=${b.javaClass.name}\n")
            try {
                val d = Parcel.obtain(); val r = Parcel.obtain()
                d.writeInt(3); d.writeInt(1)
                val bundle = Bundle().apply { putBoolean("isWill", false); putString("pkgName", "cn.boxiaolanya.tools") }
                d.writeBundle(bundle)
                val ok = b.transact(1, d, r, 0)
                sb.appendLine("transact ok=$ok replySize=${r.dataSize()}")
                d.recycle(); r.recycle()
            } catch (e: Exception) { sb.appendLine("err: ${e.message}") }
            return sb.toString()
        }
    }
}
