/**
 * PEM 温度状态变更： [PemCommands.TEMP_STATE_CHANGE] 模拟 rear_flash_temp 等 scene。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.shell.PemCommands
import cn.boxiaolanya.tools.utils.ShizukuExec
import kotlinx.coroutines.launch

@Composable
fun PemTempStateChangeScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf<String?>(null) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "模拟插件引擎发送温度状态",
                        description = "返回",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (!shizukuGranted) {
                SettingSplicedColumnGroup(title = "状态") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.CheckCircle,
                            title = "Shizuku 未连接",
                            description = "无法执行命令",
                            isError = true
                        ) {}
                    }
                }
            } else {
                SettingSplicedColumnGroup(title = "操作") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.CheckCircle,
                            title = "执行命令",
                            description = "点击发送温度状态广播",
                            onClick = {
                                scope.launch {
                                    val result = ShizukuExec.runShellCommand(PemCommands.TEMP_STATE_CHANGE)
                                    status = if (result.third) "执行成功" else "执行失败"
                                }
                            }
                        ) {}
                    }
                }

                status?.let {
                    Spacer(modifier = Modifier.height(16.dp))
                    SettingSplicedColumnGroup(title = "结果") {
                        item {
                            BaseWidget(
                                icon = Icons.Default.CheckCircle,
                                title = it,
                                description = ""
                            ) {}
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }
}