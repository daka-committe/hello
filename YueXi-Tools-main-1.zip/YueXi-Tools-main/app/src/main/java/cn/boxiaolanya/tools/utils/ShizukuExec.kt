/**
 * 通过 Shizuku 反射调用隐藏 API [Shizuku.newProcess] 执行 Shell / 系统命令。
 *
 * 项目内几乎所有「需要 adb / root 等效权限」的操作都经此对象：
 * - dumpsys activity broadcast（GameWatch、智慧引擎、PEM…）
 * - pidof、settings put、cmd netpolicy…
 * - 自定义 Shell 终端 [cn.boxiaolanya.tools.ui.pages.tools.CommandScreen]
 *
 * ## 线程
 * - [runCommand] 可在任意线程调用，但会阻塞至 Process 创建完成
 * - 带 suspend 的方法内部使用 [Dispatchers.IO]
 *
 * ## 前置条件
 * Shizuku 服务已启动且本应用已授权；否则 [runCommand] 返回 null。
 *
 * @see ShizukuHelper.isGranted
 */
package cn.boxiaolanya.tools.utils

import cn.boxiaolanya.tools.utils.shell.ShellTokens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

object ShizukuExec {

    /**
     * 创建以 shell UID 运行的子进程。
     *
     * Shizuku 13.x 未公开 newProcess，故反射获取：
     * `newProcess(String[] cmd, String[] env, String dir)`
     *
     * @param args  argv 数组，如 `arrayOf("pidof", "com.example.app")`
     * @return 子进程；反射失败、无权限或未连接时 null
     */
    fun runCommand(vararg args: String): Process? {
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            method.invoke(null, args, null, null) as Process
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * 执行命令并阻塞等待结束，一次性读完 stdout/stderr。
     *
     * 适用于短命令（pidof、单次 broadcast）；长输出可能占内存。
     *
     * @return Pair(成功时为 stdout，失败时为 stderr, exitValue==0)
     */
    /** 经 `sh -c` 执行单行命令并返回合并输出。 */
    suspend fun runShLine(command: String): Pair<String, Boolean> =
        runCommandWithOutput(ShellTokens.sh, ShellTokens.dashC, command)

    suspend fun runCommandWithOutput(vararg args: String): Pair<String, Boolean> = withContext(Dispatchers.IO) {
        try {
            val process = runCommand(*args)
            if (process == null) {
                return@withContext Pair("无法创建进程", false)
            }

            val output = process.inputStream.bufferedReader().readText()
            val error = process.errorStream.bufferedReader().readText()
            process.waitFor()

            val success = process.exitValue() == 0
            val result = if (success) output else error
            Pair(result, success)
        } catch (e: Exception) {
            Pair(e.message ?: "Shell 命令执行失败", false)
        }
    }

    /**
     * 经 `sh -c` 执行整行 Shell（可含管道、重定向）。
     *
     * stdout/stderr 各开线程读取，避免管道缓冲区塞满导致子进程阻塞；
     * 等待结束后 join 读取线程最多 5s。
     *
     * @return Triple(stdout, stderr, 是否视为成功)
     *         成功条件：exit 0，或 stdout 非空且 stderr 为空（兼容部分 dumpsys 非零但仍输出）
     */
    suspend fun runShellCommand(command: String): Triple<String, String, Boolean> = withContext(Dispatchers.IO) {
        try {
            val process = runCommand(ShellTokens.sh, ShellTokens.dashC, command)
            if (process == null) {
                return@withContext Triple("无法创建进程", "Shizuku 未连接或无权限", false)
            }

            val outputBuilder = StringBuilder()
            val errorBuilder = StringBuilder()

            val outputThread = Thread {
                process.inputStream.bufferedReader().use { reader ->
                    reader.forEachLine { line ->
                        outputBuilder.appendLine(line)
                    }
                }
            }
            val errorThread = Thread {
                process.errorStream.bufferedReader().use { reader ->
                    reader.forEachLine { line ->
                        errorBuilder.appendLine(line)
                    }
                }
            }

            outputThread.start()
            errorThread.start()

            val exitCode = process.waitFor()

            outputThread.join(5000)
            errorThread.join(5000)

            val output = outputBuilder.toString().trimEnd()
            val error = errorBuilder.toString().trimEnd()

            val success = exitCode == 0 || (output.isNotEmpty() && error.isEmpty())
            Triple(output, error, success)
        } catch (e: Exception) {
            Triple("", e.message ?: "Shizuku 命令执行失败", false)
        }
    }

    /**
     * 持续 tail 式读取 logcat，每行回调 [onLine]。
     *
     * 用于 [cn.boxiaolanya.tools.ui.pages.tools.EventMonitorScreen] 等；
     * 协程取消（[isActive] false）或 readLine 返回 null 时 destroy 子进程。
     *
     * @param buffer logcat -b 参数，如 main、system、crash
     */
    suspend fun readLogcat(buffer: String, onLine: suspend (String) -> Unit) = withContext(Dispatchers.IO) {
        try {
            val process = runCommand(ShellTokens.logcat, "-b", buffer, "-v", "time")
                ?: return@withContext

            val reader = process.inputStream.bufferedReader()

            while (isActive) {
                val line = reader.readLine() ?: break
                onLine(line)
            }

            process.destroy()
        } catch (e: Exception) {
            onLine("Error: ${e.message}")
        }
    }
}
