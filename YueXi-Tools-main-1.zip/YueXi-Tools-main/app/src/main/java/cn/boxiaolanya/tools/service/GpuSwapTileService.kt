/**
 * 快捷设置磁贴：GameWatch GPU 切换。
 */
package cn.boxiaolanya.tools.service

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import cn.boxiaolanya.tools.ui.settings.dataStore
import cn.boxiaolanya.tools.utils.shell.GameWatchCommands
import cn.boxiaolanya.tools.utils.ShizukuExec
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class GpuSwapTileService : TileService() {

    companion object {
        const val CHANNEL_TILE = "gpu_swap_tile"
        const val NOTIFY_ID = 2001
        val GPU_SWAP_PACKAGES = stringPreferencesKey("gpu_swap_packages")
        val GPU_SWAP_AUTO_ENABLED = booleanPreferencesKey("gpu_swap_auto_enabled")
        val GPU_SWAP_AUTO_INTERVAL = stringPreferencesKey("gpu_swap_auto_interval")
        var forcedActive = false
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onStartListening() {
        updateTileState()
    }

    override fun onClick() {
        if (!isLocked()) {
            performSwap()
            return
        }
        unlockAndRun {
            performSwap()
        }
    }

    @SuppressLint("MissingPermission")
    private fun performSwap() {
        scope.launch {
            val data = dataStore.data.first()
            val packages = data[GPU_SWAP_PACKAGES] ?: ""
            val selectedGpu = data[stringPreferencesKey("gpu_swap_selected")] ?: "sm8850"

            if (packages.isBlank()) return@launch

            val pkgList = packages.split(",").map { it.trim() }.filter { it.isNotBlank() }.joinToString(",")
            val command = GameWatchCommands.swapModel("unlock", pkgList)
            val (output, success) = ShizukuExec.runShLine(command)

            val channelName = "配置切换磁贴"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = android.app.NotificationChannel(
                    CHANNEL_TILE,
                    channelName,
                    android.app.NotificationManager.IMPORTANCE_LOW
                )
                val nm = getSystemService(android.app.NotificationManager::class.java)
                nm.createNotificationChannel(channel)
            }

            val notification = NotificationCompat.Builder(this@GpuSwapTileService, CHANNEL_TILE)
                .setSmallIcon(android.R.drawable.ic_popup_sync)
                .setContentTitle("配置切换 ${if (success) "成功" else "失败"}")
                .setContentText(packages)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setAutoCancel(true)
                .build()

            try {
                NotificationManagerCompat.from(this@GpuSwapTileService).notify(NOTIFY_ID, notification)
            } catch (_: Exception) {}

            delay(3000)
            try {
                NotificationManagerCompat.from(this@GpuSwapTileService).cancel(NOTIFY_ID)
            } catch (_: Exception) {}

            forcedActive = true
            updateTileState()
        }
    }

    private fun updateTileState() {
        val tile = qsTile ?: return
        if (forcedActive) {
            tile.state = Tile.STATE_ACTIVE
            tile.label = "配置运行中"
            tile.contentDescription = "配置切换已启用"
        } else {
            tile.state = Tile.STATE_INACTIVE
            tile.label = "配置切换"
            tile.contentDescription = "点击执行配置切换"
        }
        tile.updateTile()
    }

    override fun onTileRemoved() {
        forcedActive = false
    }
}
