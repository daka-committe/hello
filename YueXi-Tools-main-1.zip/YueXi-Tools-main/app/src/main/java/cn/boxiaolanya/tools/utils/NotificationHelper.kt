/**
 * 通知渠道与 RMS / 编译进度等前台提示的统一封装。
 */
package cn.boxiaolanya.tools.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object NotificationHelper {

    const val CHANNEL_ID_COMPILE = "compile_progress"
    const val NOTIFICATION_ID_COMPILE = 1001

    const val CHANNEL_ID_RMS_STATUS = "rms_status"
    const val NOTIFICATION_ID_RMS_TIP = 10003

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val compileChannel = NotificationChannel(
                CHANNEL_ID_COMPILE,
                "编译进度",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "显示应用编译进度"
                setShowBadge(false)
            }
            val rmsChannel = NotificationChannel(
                CHANNEL_ID_RMS_STATUS,
                "VIVO-RMS",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "VIVO-RMS 权限与监控状态"
                setShowBadge(false)
            }

            val notificationManager = context.getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(compileChannel)
            notificationManager.createNotificationChannel(rmsChannel)
        }
    }

    private fun showRmsTip(context: Context, title: String, text: String) {
        if (!hasNotificationPermission(context)) return
        val notification = NotificationCompat.Builder(context, CHANNEL_ID_RMS_STATUS)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_RMS_TIP, notification)
    }

    fun showRmsShizukuBackgroundTip(context: Context) {
        showRmsTip(
            context,
            "VIVO-RMS · Shizuku 后台监控",
            "已通过 Shizuku 使用 content 命令轮询 secure 设置。",
        )
    }

    fun showRmsNeedShizukuTip(context: Context) {
        showRmsTip(
            context,
            "VIVO-RMS · 无法监控",
            "未连接 Shizuku，请先授予 Shizuku 权限。",
        )
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            NotificationManagerCompat.from(context).areNotificationsEnabled()
        } else {
            true
        }
    }

    fun showCompileProgressNotification(
        context: Context,
        current: Int,
        total: Int,
        appName: String
    ) {
        val progress = (current * 100 / total)
        val notification = NotificationCompat.Builder(context, CHANNEL_ID_COMPILE)
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle("正在编译应用")
            .setContentText("($current/$total) $appName")
            .setProgress(100, progress, false)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_COMPILE, notification)
    }

    fun updateCompileProgress(
        context: Context,
        current: Int,
        total: Int,
        appName: String
    ) {
        showCompileProgressNotification(context, current, total, appName)
    }

    fun showCompileCompleteNotification(
        context: Context,
        successCount: Int,
        failCount: Int,
        total: Int
    ) {
        val contentText = if (failCount == 0) {
            "全部编译成功 ($successCount/$total)"
        } else {
            "成功: $successCount  失败: $failCount"
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID_COMPILE)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("编译完成")
            .setContentText(contentText)
            .setProgress(0, 0, false)
            .setOngoing(false)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_COMPILE, notification)
    }

    fun cancelCompileNotification(context: Context) {
        NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID_COMPILE)
    }
}
