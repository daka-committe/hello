/**
 * 全局未捕获异常处理器：写入内部/外部存储 crash_logs。
 */
package cn.boxiaolanya.tools.utils

import android.content.Context
import android.os.Build
import android.os.Environment
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileWriter
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CrashHandler private constructor(private val context: Context) : Thread.UncaughtExceptionHandler {

    private val TAG = "CrashHandler"
    private var defaultHandler: Thread.UncaughtExceptionHandler? = null

    companion object {
        @Volatile
        private var instance: CrashHandler? = null

        fun init(context: Context) {
            if (instance == null) {
                synchronized(this) {
                    if (instance == null) {
                        instance = CrashHandler(context.applicationContext)
                        instance!!.register()
                    }
                }
            }
        }
    }

    private fun register() {
        defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler(this)
        Log.d(TAG, "崩溃日志处理器已注册")
    }

    override fun uncaughtException(thread: Thread, throwable: Throwable) {
        Log.e(TAG, "应用发生崩溃", throwable)

        GlobalScope.launch(Dispatchers.IO) {
            saveCrashLog(thread, throwable)
        }

        defaultHandler?.uncaughtException(thread, throwable)
    }

    private fun saveCrashLog(thread: Thread, throwable: Throwable) {
        try {
            val crashInfo = buildCrashInfo(thread, throwable)
            val fileName = generateFileName()

            saveToInternalStorage(fileName, crashInfo)
            saveToExternalStorage(fileName, crashInfo)
        } catch (e: Exception) {
            Log.e(TAG, "保存崩溃日志失败", e)
        }
    }

    private fun buildCrashInfo(thread: Thread, throwable: Throwable): String {
        val stringBuilder = StringBuilder()
        val separator = "=".repeat(60)

        stringBuilder.appendLine(separator)
        stringBuilder.appendLine("应用崩溃日志")
        stringBuilder.appendLine(separator)
        stringBuilder.appendLine()

        val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        stringBuilder.appendLine("崩溃时间: ${timeFormat.format(Date())}")
        stringBuilder.appendLine()

        stringBuilder.appendLine("设备信息:")
        stringBuilder.appendLine("  品牌: ${Build.BRAND}")
        stringBuilder.appendLine("  型号: ${Build.MODEL}")
        stringBuilder.appendLine("  设备: ${Build.DEVICE}")
        stringBuilder.appendLine("  Android版本: ${Build.VERSION.RELEASE}")
        stringBuilder.appendLine("  SDK版本: ${Build.VERSION.SDK_INT}")
        stringBuilder.appendLine("  制造商: ${Build.MANUFACTURER}")
        stringBuilder.appendLine("  产品: ${Build.PRODUCT}")
        stringBuilder.appendLine()

        try {
            val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            stringBuilder.appendLine("应用信息:")
            stringBuilder.appendLine("  包名: ${context.packageName}")
            stringBuilder.appendLine("  版本名: ${packageInfo.versionName}")
            stringBuilder.appendLine("  版本号: ${packageInfo.longVersionCode}")
            stringBuilder.appendLine()
        } catch (e: Exception) {
            stringBuilder.appendLine("应用信息: 获取失败")
            stringBuilder.appendLine()
        }

        stringBuilder.appendLine("线程信息:")
            stringBuilder.appendLine("  线程名: ${thread.name}")
        stringBuilder.appendLine("  线程ID: ${thread.id}")
        stringBuilder.appendLine()

        stringBuilder.appendLine("崩溃信息:")
        stringBuilder.appendLine("  异常类型: ${throwable.javaClass.name}")
        stringBuilder.appendLine("  异常消息: ${throwable.message}")
        stringBuilder.appendLine()

        stringBuilder.appendLine("堆栈跟踪:")
        stringBuilder.appendLine(separator)
        val stringWriter = StringWriter()
        val printWriter = PrintWriter(stringWriter)
        throwable.printStackTrace(printWriter)
        stringBuilder.appendLine(stringWriter.toString())

        stringBuilder.appendLine(separator)
        stringBuilder.appendLine("日志结束")
        stringBuilder.appendLine(separator)

        return stringBuilder.toString()
    }

    private fun generateFileName(): String {
        val timeFormat = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault())
        return "crash_${timeFormat.format(Date())}.txt"
    }

    private fun saveToInternalStorage(fileName: String, content: String) {
        try {
            val crashDir = File(context.getExternalFilesDir(null), "crash_logs")
            if (!crashDir.exists()) {
                crashDir.mkdirs()
            }

            val file = File(crashDir, fileName)
            FileWriter(file).use { writer ->
                writer.write(content)
            }
            Log.d(TAG, "崩溃日志已保存到内部存储: ${file.absolutePath}")
        } catch (e: Exception) {
            Log.e(TAG, "保存到内部存储失败", e)
        }
    }

    private fun saveToExternalStorage(fileName: String, content: String) {
        try {
            if (Environment.getExternalStorageState() != Environment.MEDIA_MOUNTED) {
                Log.w(TAG, "外部存储不可用")
                return
            }

            val externalDir = File(Environment.getExternalStorageDirectory(), "悦玺Tools/crash_logs")
            if (!externalDir.exists()) {
                externalDir.mkdirs()
            }

            val file = File(externalDir, fileName)
            FileWriter(file).use { writer ->
                writer.write(content)
            }
            Log.d(TAG, "崩溃日志已保存到外部存储: ${file.absolutePath}")
        } catch (e: Exception) {
            Log.e(TAG, "保存到外部存储失败", e)
        }
    }

    fun getCrashLogDir(): File {
        return File(context.getExternalFilesDir(null), "crash_logs")
    }

    fun getCrashLogFiles(): List<File> {
        val dir = getCrashLogDir()
        if (!dir.exists()) {
            return emptyList()
        }
        return dir.listFiles { file ->
            file.isFile && file.name.startsWith("crash_") && file.name.endsWith(".txt")
        }?.sortedByDescending { it.lastModified() } ?: emptyList()
    }

    fun clearCrashLogs(): Boolean {
        val dir = getCrashLogDir()
        if (!dir.exists()) {
            return true
        }
        return dir.listFiles()?.all { it.delete() } ?: true
    }
}
