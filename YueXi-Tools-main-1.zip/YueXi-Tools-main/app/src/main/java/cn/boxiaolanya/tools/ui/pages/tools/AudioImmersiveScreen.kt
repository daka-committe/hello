/**
 * 沉浸音频 UI：空间音频、头部追踪相关开关。
 *
 * 经 [cn.boxiaolanya.tools.audio.ImmersiveAudioController]；标准 Android 音频 API。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.audio.AudioPreferences
import cn.boxiaolanya.tools.audio.ImmersiveAudioController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup

@Composable
fun AudioImmersiveScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val context = LocalContext.current
    var immersiveController by remember { mutableStateOf<ImmersiveAudioController?>(null) }

    var isEnabled by remember { mutableStateOf(false) }
    var selectedPreset by remember { mutableStateOf(ImmersiveAudioController.AudioPreset.OFF) }
    var virtualizerVal by remember { mutableIntStateOf(0) }
    var bassVal by remember { mutableIntStateOf(0) }
    var loudnessVal by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        AudioPreferences.init(context)
        immersiveController = ImmersiveAudioController(context)
        isEnabled = immersiveController?.isEnabled ?: false
        selectedPreset = immersiveController?.preset ?: ImmersiveAudioController.AudioPreset.OFF
        virtualizerVal = immersiveController?.virtualizerLevel ?: 0
        bassVal = immersiveController?.bassLevel ?: 0
        loudnessVal = immersiveController?.loudnessLevel ?: 0
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "沉浸式音效",
                        description = "返回音效增强",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            if (!shizukuGranted) {
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Clear,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以使用此功能",
                            isError = true
                        ) {}
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "音效开关") {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("开启沉浸式音效", style = MaterialTheme.typography.bodyLarge)
                            Switch(
                                checked = isEnabled,
                                onCheckedChange = { checked ->
                                    isEnabled = checked
                                    if (checked) {
                                        immersiveController?.enable()
                                    } else {
                                        immersiveController?.disable()
                                    }
                                }
                            )
                        }
                    }
                }

                if (isEnabled) {
                    Spacer(modifier = Modifier.height(16.dp))

                    val allPresets = ImmersiveAudioController.AudioPreset.entries
                    val chipRows = allPresets.chunked(3)

                    SettingSplicedColumnGroup(title = "预设方案") {
                        item {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                chipRows.forEach { row ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        row.forEach { p ->
                                            FilterChip(
                                                onClick = {
                                                    selectedPreset = p
                                                    immersiveController?.applyPreset(p)
                                                    virtualizerVal = immersiveController?.virtualizerLevel ?: 0
                                                    bassVal = immersiveController?.bassLevel ?: 0
                                                    loudnessVal = immersiveController?.loudnessLevel ?: 0
                                                },
                                                label = { Text(p.label) },
                                                selected = selectedPreset == p,
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    SettingSplicedColumnGroup(title = "自定义调节") {
                        item {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                                Text("环绕强度: $virtualizerVal%", style = MaterialTheme.typography.bodyMedium)
                                Slider(
                                    value = virtualizerVal.toFloat(),
                                    onValueChange = { v ->
                                        virtualizerVal = v.toInt()
                                        selectedPreset = ImmersiveAudioController.AudioPreset.CUSTOM
                                        immersiveController?.preset = selectedPreset
                                        immersiveController?.virtualizerLevel = virtualizerVal
                                        immersiveController?.applyCurrentSettings()
                                    },
                                    valueRange = 0f..100f,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Text("低音增强: $bassVal%", style = MaterialTheme.typography.bodyMedium)
                                Slider(
                                    value = bassVal.toFloat(),
                                    onValueChange = { v ->
                                        bassVal = v.toInt()
                                        selectedPreset = ImmersiveAudioController.AudioPreset.CUSTOM
                                        immersiveController?.preset = selectedPreset
                                        immersiveController?.bassLevel = bassVal
                                        immersiveController?.applyCurrentSettings()
                                    },
                                    valueRange = 0f..100f,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Text("音量提升: $loudnessVal%", style = MaterialTheme.typography.bodyMedium)
                                Slider(
                                    value = loudnessVal.toFloat(),
                                    onValueChange = { v ->
                                        loudnessVal = v.toInt()
                                        selectedPreset = ImmersiveAudioController.AudioPreset.CUSTOM
                                        immersiveController?.preset = selectedPreset
                                        immersiveController?.loudnessLevel = loudnessVal
                                        immersiveController?.applyCurrentSettings()
                                    },
                                    valueRange = 0f..100f,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "说明") {
                    item {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("基于 Android AudioEffect API", style = MaterialTheme.typography.bodySmall)
                            Text("影院=强环绕+低音，音乐厅=中度环绕，游戏=低音+响度", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }
}
