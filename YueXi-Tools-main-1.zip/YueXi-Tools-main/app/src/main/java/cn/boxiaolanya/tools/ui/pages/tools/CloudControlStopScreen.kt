/**
 * 云控停止：停止 vivo 云控服务/采集的广播命令。
 *
 * 可与 [CloudControlScreen] 配合使用；定义见 [ExtraScreens] 或本文件内常量。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.ShizukuExec
import kotlinx.coroutines.launch

data class CloudControlResult(val success: Boolean, val output: String)

@Composable
fun CloudControlStopScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var isExecuting by remember { mutableStateOf(false) }
    var lastResult by remember { mutableStateOf<CloudControlResult?>(null) }

    val commands = listOf(
        cn.boxiaolanya.tools.utils.shell.ShellObf.s("cloud.stop.1"),
        cn.boxiaolanya.tools.utils.shell.ShellObf.s("cloud.stop.2"),
        cn.boxiaolanya.tools.utils.shell.ShellObf.s("cloud.stop.3"),
        cn.boxiaolanya.tools.utils.shell.ShellObf.s("cloud.stop.4"),
        cn.boxiaolanya.tools.utils.shell.ShellObf.s("cloud.stop.5"),
        cn.boxiaolanya.tools.utils.shell.ShellObf.s("cloud.stop.6"),
        cn.boxiaolanya.tools.utils.shell.ShellObf.s("cloud.stop.7"),
        cn.boxiaolanya.tools.utils.shell.ShellObf.s("cloud.stop.8"),
        cn.boxiaolanya.tools.utils.shell.ShellObf.s("cloud.stop.9"),
        cn.boxiaolanya.tools.utils.shell.ShellObf.s("cloud.stop.10"),
    )

    fun executeStopAll() {
        if (!shizukuGranted) {
            scope.launch { snackbarHostState.showSnackbar("需授予 Shizuku 权限") }
            return
        }

        scope.launch {
            isExecuting = true
            val results = mutableListOf<String>()
            var allSuccess = true

            for (cmd in commands) {
                val (output, success) = ShizukuExec.runShLine(cmd)
                if (!success) {
                    allSuccess = false
                    results.add("$cmd: $output")
                }
            }

            lastResult = CloudControlResult(allSuccess, if (results.isEmpty()) "全部服务已停止" else results.joinToString("\n"))
            isExecuting = false
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
                )
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "停止云控服务",
                        description = "返回去云控",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            if (!shizukuGranted) {
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Clear,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以使用此功能",
                            isError = true
                        ) {}
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "操作") {
                    item {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                "将停止 10 个云控相关服务，执行后云控将无法控制设备",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Button(
                                onClick = { executeStopAll() },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("停止所有云控服务") }
                        }
                    }
                }
            }

            lastResult?.let { result ->
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "执行结果") {
                    item {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = if (result.success) "成功" else "部分失败",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (result.success) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                            if (result.output.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                SelectionContainer {
                                    Text(
                                        text = result.output,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }

    if (isExecuting) {
        Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
                ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceBright
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(48.dp),
                            strokeWidth = 4.dp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "正在停止云控服务...",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }
}
