package cn.boxiaolanya.tools.utils.shell

object DeviceIdleCommands {
    private val WHITELIST_ADD get() = ShellObf.s("idle.whitelist_add")
    private val WHITELIST_REMOVE get() = ShellObf.s("idle.whitelist_remove")

    fun add(packageName: String): String = WHITELIST_ADD + packageName

    fun remove(packageName: String): String = WHITELIST_REMOVE + packageName
}
