/**
 * vivo 智慧引擎（AppBehaviorEngine / ABE）相关 dumpsys 广播。
 */
package cn.boxiaolanya.tools.utils.shell

object SmartEngineCommands {

    private val NO_ALLOW_PREFIX get() = ShellObf.s("se.no_allow_prefix")
    private val NO_ALLOW_SUFFIX get() = ShellObf.s("se.no_allow_suffix")

    val UPDATE_CONFIG: String
        get() = ShellObf.s("se.update_config")

    val EXCEPTION_THREAD_PREFIX: String
        get() = ShellObf.s("se.exception_prefix")

    val EXCEPTION_THREAD_PID: String
        get() = ShellObf.s("se.exception_pid")

    val EXCEPTION_THREAD_NAME: String
        get() = ShellObf.s("se.exception_name")

    fun noAllowBroadcast(packageName: String): String = NO_ALLOW_PREFIX + packageName + NO_ALLOW_SUFFIX

    fun userKillBroadcast(packageName: String): String =
        String.format(ShellObf.s("se.user_kill"), packageName)
}
