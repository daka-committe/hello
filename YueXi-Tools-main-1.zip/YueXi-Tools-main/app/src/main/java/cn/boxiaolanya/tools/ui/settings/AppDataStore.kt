/**
 * DataStore Preferences 键名与读写封装。
 */
package cn.boxiaolanya.tools.ui.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class AppDataStore(private val context: Context) {

    companion object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val KEEP_ALIVE_ENABLED = booleanPreferencesKey("keep_alive_enabled")
        val RMS_BG_MONITOR_ENABLED = booleanPreferencesKey("rms_bg_monitor_enabled")
        val RMS_POLL_INTERVAL_MS = longPreferencesKey("rms_poll_interval_ms")
        val RMS_TARGET_PACKAGE = stringPreferencesKey("rms_target_package")
        val RMS_REASON_KIND = stringPreferencesKey("rms_reason_kind")
        val RMS_USE_OVERRIDE = booleanPreferencesKey("rms_use_override")
        val RMS_USE_VSYNC = booleanPreferencesKey("rms_use_vsync_imd")
        val RMS_BURST_WRITE_COUNT = intPreferencesKey("rms_burst_write_count")
        val RMS_THERMAL_TEMP = stringPreferencesKey("rms_thermal_temp")
        val RMS_ACTIVITY = stringPreferencesKey("rms_activity")
        val RMS_FPS = stringPreferencesKey("rms_fps")
    }

    fun getBoolean(key: Preferences.Key<Boolean>, defaultValue: Boolean): Flow<Boolean> {
        return context.dataStore.data.map { preferences ->
            preferences[key] ?: defaultValue
        }
    }

    suspend fun setBoolean(key: Preferences.Key<Boolean>, value: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[key] = value
        }
    }

    fun getString(key: Preferences.Key<String>, defaultValue: String): Flow<String> {
        return context.dataStore.data.map { preferences ->
            preferences[key] ?: defaultValue
        }
    }

    suspend fun setString(key: Preferences.Key<String>, value: String) {
        context.dataStore.edit { preferences ->
            preferences[key] = value
        }
    }
}
