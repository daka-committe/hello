/**
 * 全局省电模式相关前台服务。
 */
package cn.boxiaolanya.tools.service

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import cn.boxiaolanya.tools.MainActivity
import cn.boxiaolanya.tools.utils.GameWatchBinder
import cn.boxiaolanya.tools.utils.ShizukuExec
import cn.boxiaolanya.tools.utils.shell.ProcQueries
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@SuppressLint("MissingPermission")
class GlobalPowerSaveService : Service() {

    companion object {
        const val CHANNEL_ID = "global_power_save_channel"
        const val CHANNEL_NAME = "全局省电模式"
        const val NOTIFICATION_ID = 10002
        const val ACTION_START = "cn.boxiaolanya.tools.action.START_GLOBAL_POWER_SAVE"
        const val ACTION_STOP = "cn.boxiaolanya.tools.action.STOP_GLOBAL_POWER_SAVE"
        const val POLLING_INTERVAL = 5000L

        fun start(context: Context) {
            val intent = Intent(context, GlobalPowerSaveService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, GlobalPowerSaveService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        fun isRunning(context: Context): Boolean {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            return manager.getRunningServices(Integer.MAX_VALUE)
                .any { it.service.className == GlobalPowerSaveService::class.java.name }
        }
    }

    private var pollingJob: Job? = null
    private val serviceScope = CoroutineScope(Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                val notification = createNotification("全局省电运行中")
                startForeground(NOTIFICATION_ID, notification)
                startPolling()
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        stopPolling()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = "全局省电模式后台运行中"
                setShowBadge(false)
                enableLights(false)
                enableVibration(false)
                setSound(null, null)
            }
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(status: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            0,
            Intent(this, GlobalPowerSaveService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("全局省电")
            .setContentText(status)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setAutoCancel(false)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setSilent(true)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "停止",
                stopIntent
            )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            try {
                builder.javaClass.getMethod("setHideForegroundIcon", Boolean::class.javaPrimitiveType)
                    .invoke(builder, true)
            } catch (e: Exception) {
            }
        }

        return builder.build()
    }

    private fun startPolling() {
        stopPolling()
        pollingJob = serviceScope.launch {
            while (isActive) {
                val (pkg, pid) = detectForegroundApp()
                if (pkg != null && pid > 0) {
                    executeBalancedInjection(pkg, pid)
                    updateNotification("$pkg (后台运行)")
                } else {
                    updateNotification("全局省电运行中")
                }
                delay(POLLING_INTERVAL)
            }
        }
    }

    private fun stopPolling() {
        pollingJob?.cancel()
        pollingJob = null
    }

    private fun updateNotification(status: String) {
        try {
            val notification = createNotification(status)
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.notify(NOTIFICATION_ID, notification)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private suspend fun detectForegroundApp(): Pair<String?, Int> {
        try {
            val (output, _, _) = ShizukuExec.runShellCommand(
                cn.boxiaolanya.tools.utils.shell.ShellObf.s("misc.activities"),
            )
            val lines = output.lines()

            var foundPkg: String? = null
            var foundPid = 0

            for (line in lines) {
                val trimmed = line.trim()
                if (trimmed.contains("mResumedActivity") || trimmed.contains("mFocusedApp")) {
                    val part = trimmed
                        .substringAfter("}")
                        .substringAfter(":")
                        .trim()
                        .substringBefore(" ")
                        .substringBefore("/")
                    if (part.contains(".") && part.length > 6) {
                        foundPkg = part
                    }
                }
                if (trimmed.contains("mPid=") && foundPid == 0) {
                    val pidStr = trimmed
                        .substringAfter("mPid=")
                        .take(10)
                        .filter { it.isDigit() }
                    foundPid = pidStr.toIntOrNull() ?: 0
                }
            }

            if (foundPkg != null && foundPid > 0) {
                return Pair(foundPkg, foundPid)
            }

            if (foundPkg != null) {
                val pid = ProcQueries.pidOfPackage(foundPkg) ?: 0
                if (pid > 0) return Pair(foundPkg, pid)
            }

            if (foundPkg == null) {
                for (line in lines) {
                    val stripped = line.replace(" ", "")
                    if (stripped.contains("/") && stripped.contains(".")) {
                        val comp = stripped.substringBefore("/")
                        if (comp.contains(".") && comp.length > 6 && !comp.startsWith("com.android")) {
                            val pid = ProcQueries.pidOfPackage(comp) ?: 0
                            if (pid > 0) return Pair(comp, pid)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return Pair(null, 0)
    }

    private suspend fun executeBalancedInjection(pkg: String, pid: Int) {
        val pids = pid.toString()
        val steps = listOf(
            "hang_up_game" to listOf("pid" to pids, "state" to "0"),
            "turbo" to listOf("uid" to "0", "pid" to pids, "cmd" to "2", "pkgName" to pkg),
            "notify_target_fps" to listOf(
                "pkgName" to pkg, "uid" to pids, "targetFps" to "0",
                "minFps" to "60", "maxFps" to "120", "refreshRate" to "144",
                "mode" to "1", "thermalLevel" to "0", "flags" to "0"
            ),
            "notify_to_app_common" to listOf(
                "uid" to "0", "pid" to pids, "pkgName" to pkg,
                "action" to "game_pause", "extras" to "{}", "flags" to "0"
            ),
            "net_opt" to listOf("key" to "game_mode", "value" to "0")
        )
        steps.forEach { (name, args) ->
            try {
                GameWatchBinder.execute(name, args)
            } catch (e: Exception) {
            }
        }
    }
}
