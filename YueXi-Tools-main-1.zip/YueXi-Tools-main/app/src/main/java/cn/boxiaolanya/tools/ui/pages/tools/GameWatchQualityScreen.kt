/**
 * GameWatch 画质： [GameWatchCommands.quality]，需包名 + [ProcQueries.pidOfPackage]。
 */
package cn.boxiaolanya.tools.ui.pages.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cn.boxiaolanya.tools.ui.widgets.setting.BaseWidget
import cn.boxiaolanya.tools.ui.widgets.setting.SettingSplicedColumnGroup
import cn.boxiaolanya.tools.utils.shell.GameWatchCommands
import cn.boxiaolanya.tools.utils.shell.ProcQueries
import cn.boxiaolanya.tools.utils.ShizukuExec
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class QualityOption(val value: Int, val label: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameWatchQualityScreen(
    shizukuGranted: Boolean,
    navController: NavController
) {
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var isExecuting by remember { mutableStateOf(false) }
    var lastResult by remember { mutableStateOf<GameWatchConfigResult?>(null) }
    var packageName by remember { mutableStateOf("") }
    var pid by remember { mutableStateOf("") }
    var pidMsg by remember { mutableStateOf("") }
    var pidFetching by remember { mutableStateOf(false) }
    var selectedQuality by remember { mutableIntStateOf(2) }
    var qualityExpanded by remember { mutableStateOf(false) }

    val qualityOptions = listOf(
        QualityOption(0, "低"),
        QualityOption(1, "中"),
        QualityOption(2, "高"),
        QualityOption(3, "极致")
    )

    LaunchedEffect(packageName, shizukuGranted) {
        if (packageName.isBlank() || !shizukuGranted) {
            pid = ""
            pidMsg = ""
            return@LaunchedEffect
        }
        delay(500)
        pidFetching = true
        pidMsg = ""
        val parsed = ProcQueries.pidOfPackage(packageName)
        if (parsed != null) {
            pid = parsed.toString()
            pidMsg = ""
        } else {
            pid = ""
            pidMsg = "进程未运行或包名不正确"
        }
        pidFetching = false
    }

    fun executeQuality() {
        if (!shizukuGranted) {
            scope.launch { snackbarHostState.showSnackbar("需授予 Shizuku 权限") }
            return
        }
        val pkg = packageName.trim()
        if (pkg.isBlank()) {
            scope.launch { snackbarHostState.showSnackbar("请输入包名") }
            return
        }
        val pidInt = pid.toIntOrNull()
        if (pidInt == null || pidInt <= 0) {
            scope.launch { snackbarHostState.showSnackbar("未获取到有效 PID，请确认应用正在运行") }
            return
        }

        scope.launch {
            isExecuting = true
            val command = GameWatchCommands.quality(
                pkg,
                pidInt.toString(),
                selectedQuality.toString()
            )
            val (output, success) = ShizukuExec.runShLine(command)
            lastResult = GameWatchConfigResult(success, output)
            isExecuting = false
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
                )
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            SettingSplicedColumnGroup {
                item {
                    BaseWidget(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        title = "画质通知",
                        description = "返回 GameWatch",
                        onClick = { navController.navigateUp() }
                    ) {}
                }
            }

            if (!shizukuGranted) {
                Spacer(modifier = Modifier.height(16.dp))
                SettingSplicedColumnGroup(title = "授权中心") {
                    item {
                        BaseWidget(
                            icon = Icons.Default.Clear,
                            title = "Shizuku 未连接",
                            description = "授予 Shizuku 权限以使用此功能",
                            isError = true
                        ) {}
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "画质通知") {
                    item {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = packageName,
                                onValueChange = { packageName = it },
                                label = { Text("应用包名") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                placeholder = { Text("com.tencent.tmgp.sgame") }
                            )

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (pidFetching) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                    Spacer(Modifier.width(8.dp))
                                    Text("正在获取 PID...", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                } else if (pid.isNotBlank()) {
                                    Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("PID: $pid", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                } else if (pidMsg.isNotBlank()) {
                                    Icon(Icons.Default.Warning, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text(pidMsg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                                }
                            }

                            ExposedDropdownMenuBox(
                                expanded = qualityExpanded,
                                onExpandedChange = { qualityExpanded = !qualityExpanded }
                            ) {
                                OutlinedTextField(
                                    value = qualityOptions.find { it.value == selectedQuality }?.label ?: "",
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("画质等级") },
                                    modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable, true),
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = qualityExpanded) }
                                )
                                ExposedDropdownMenu(
                                    expanded = qualityExpanded,
                                    onDismissRequest = { qualityExpanded = false }
                                ) {
                                    qualityOptions.forEach { option ->
                                        DropdownMenuItem(
                                            text = { Text(option.label) },
                                            onClick = {
                                                selectedQuality = option.value
                                                qualityExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            Button(
                                onClick = { executeQuality() },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = packageName.isNotBlank() &&
                                    (pid.toIntOrNull()?.let { it > 0 } == true)
                            ) { Text("发送画质通知") }
                        }
                    }
                }
            }

            lastResult?.let { result ->
                Spacer(modifier = Modifier.height(16.dp))

                SettingSplicedColumnGroup(title = "执行结果") {
                    item {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = if (result.success) "成功" else "错误",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (result.success) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                            if (result.output.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                SelectionContainer {
                                    Text(
                                        text = result.output,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(
                WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()))
        }
    }

    if (isExecuting) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceBright
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(48.dp),
                            strokeWidth = 4.dp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "正在发送通知...",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }
}
