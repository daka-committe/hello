package cn.boxiaolanya.tools.utils.shell

object ServiceControlCommands {
    private val START_SERVICE get() = ShellObf.s("svc.start")
    private val STOP_SERVICE get() = ShellObf.s("svc.stop")

    fun start(component: String): String = START_SERVICE + component

    fun stop(component: String): String = STOP_SERVICE + component
}
