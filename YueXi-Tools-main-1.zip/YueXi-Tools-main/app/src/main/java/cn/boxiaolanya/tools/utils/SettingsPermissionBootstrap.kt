/**
 * Shizuku 授权后自动 `pm grant WRITE_SECURE_SETTINGS`。
 *
 * 调用时机：
 * - [cn.boxiaolanya.tools.MainActivity.onCreate] / onResume
 * - 首页 Shizuku Binder 就绪回调
 *
 * grant 成功后 [SecureSettingsAccess.isWriteSecureGranted] 为 true，
 * RMS / 系统设置优化等 ContentResolver 写入方可进行。
 */
package cn.boxiaolanya.tools.utils

import android.content.Context
import cn.boxiaolanya.tools.utils.shell.ShellTokens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object SettingsPermissionBootstrap {

    /**
     * 若已 Shizuku 授权则尝试 pm grant；返回最终是否持有 WRITE_SECURE_SETTINGS。
     * 已 grant 时 runCommand 可能仍返回非 0，故以 checkSelfPermission 为准。
     */
    suspend fun ensure(context: Context): Boolean = withContext(Dispatchers.IO) {
        if (!ShizukuHelper.isGranted()) return@withContext false
        val pkg = context.packageName
        val (_, ok) = ShizukuExec.runCommandWithOutput(
            ShellTokens.pm,
            ShellTokens.grant,
            pkg,
            SecureSettingsAccess.WRITE_SECURE_SETTINGS,
        )
        ok || SecureSettingsAccess.isWriteSecureGranted(context)
    }
}
