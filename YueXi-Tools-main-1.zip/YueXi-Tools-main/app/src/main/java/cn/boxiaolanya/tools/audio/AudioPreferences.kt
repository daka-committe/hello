/**
 * 音频相关偏好持久化（DataStore）。
 */
package cn.boxiaolanya.tools.audio

import android.content.Context
import android.content.SharedPreferences

object AudioPreferences {
    private const val PREFS_NAME = "audio_preferences"
    private const val KEY_IMMERSIVE_ENABLED = "immersive_enabled"
    private const val KEY_IMMERSIVE_PRESET = "immersive_preset"
    private const val KEY_IMMERSIVE_VIRTUALIZER = "immersive_virtualizer"
    private const val KEY_IMMERSIVE_BASS = "immersive_bass"
    private const val KEY_IMMERSIVE_LOUDNESS = "immersive_loudness"

    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    var immersiveEnabled: Boolean
        get() = prefs.getBoolean(KEY_IMMERSIVE_ENABLED, false)
        set(value) { prefs.edit().putBoolean(KEY_IMMERSIVE_ENABLED, value).apply() }

    var immersivePreset: String
        get() = prefs.getString(KEY_IMMERSIVE_PRESET, "OFF") ?: "OFF"
        set(value) { prefs.edit().putString(KEY_IMMERSIVE_PRESET, value).apply() }

    var immersiveVirtualizer: Int
        get() = prefs.getInt(KEY_IMMERSIVE_VIRTUALIZER, 0)
        set(value) { prefs.edit().putInt(KEY_IMMERSIVE_VIRTUALIZER, value.coerceIn(0, 100)).apply() }

    var immersiveBass: Int
        get() = prefs.getInt(KEY_IMMERSIVE_BASS, 0)
        set(value) { prefs.edit().putInt(KEY_IMMERSIVE_BASS, value.coerceIn(0, 100)).apply() }

    var immersiveLoudness: Int
        get() = prefs.getInt(KEY_IMMERSIVE_LOUDNESS, 0)
        set(value) { prefs.edit().putInt(KEY_IMMERSIVE_LOUDNESS, value.coerceIn(0, 100)).apply() }
}