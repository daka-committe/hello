package cn.boxiaolanya.tools.utils

import android.util.Base64
import cn.boxiaolanya.tools.BuildConfig
import kotlin.math.abs

/**
 * Release 构建将 Shell 敏感字面量加密进 [cn.boxiaolanya.tools.utils.shell.ShellObfTable]，
 * 运行时经本类还原后再交给 Shizuku 执行。
 */
internal object ShellCipher {

    private const val MARK = "\uE001"

    fun wrap(plain: String, keySeed: Int): String {
        val key = deriveKey(keySeed)
        val src = plain.toByteArray(Charsets.UTF_8)
        val out = ByteArray(src.size)
        for (i in src.indices) {
            val rot = (key ushr ((i and 3) shl 3)) and 0xFF
            out[i] = (src[i].toInt() xor rot xor (i * 31 + keySeed)).toByte()
        }
        return MARK + Base64.encodeToString(out, Base64.NO_WRAP)
    }

    fun unwrap(payload: String): String {
        if (!payload.startsWith(MARK)) return payload
        val keySeed = BuildConfig.SHELL_XOR_KEY
        val key = deriveKey(keySeed)
        val src = Base64.decode(payload.substring(MARK.length), Base64.NO_WRAP)
        val out = ByteArray(src.size)
        for (i in src.indices) {
            val rot = (key ushr ((i and 3) shl 3)) and 0xFF
            out[i] = (src[i].toInt() xor rot xor (i * 31 + keySeed)).toByte()
        }
        return out.toString(Charsets.UTF_8)
    }

    private fun deriveKey(seed: Int): Int {
        var x = seed xor 0x9E3779B9.toInt()
        x = (x xor (x shl 13)) * 0x5BD1E995
        x = x xor (x ushr 15)
        return abs(x)
    }
}
