# Shell 解密：保留入口，允许 R8 混淆实现类名
-keepclassmembers class cn.boxiaolanya.tools.utils.ShellCipher {
    public static java.lang.String unwrap(java.lang.String);
}
-keepclassmembers class cn.boxiaolanya.tools.utils.shell.ShellObfTable {
    public static java.lang.String get(java.lang.String);
}
-keepclassmembers class cn.boxiaolanya.tools.utils.shell.ShellObf {
    public static java.lang.String s(java.lang.String);
}
