import java.util.Base64
import kotlin.math.abs

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

private val shellXorKey = 0x52A9C31Du.toInt()

private fun encodeShellLiteral(plain: String, seed: Int): String {
    val mark = "\uE001"
    var x = seed.toInt() xor 0x9E3779B9.toInt()
    x = (x xor (x shl 13)) * 0x5BD1E995
    x = x xor (x ushr 15)
    val key = abs(x)
    val src = plain.toByteArray(Charsets.UTF_8)
    val out = ByteArray(src.size)
    for (i in src.indices) {
        val rot = (key ushr ((i and 3) shl 3)) and 0xFF
        out[i] = (src[i].toInt() xor rot xor (i * 31 + seed.toInt())).toByte()
    }
    return mark + Base64.getEncoder().encodeToString(out)
}

private val shellGeneratedDir = layout.buildDirectory.dir("generated/shellObf/kotlin")

tasks.register("generateShellObf") {
    val registry = file("shell/registry.json")
    val outFile = shellGeneratedDir.map { it.file("cn/boxiaolanya/tools/utils/shell/ShellObfTable.kt") }
    inputs.file(registry)
    outputs.file(outFile)
    doLast {
        @Suppress("UNCHECKED_CAST")
        val json = groovy.json.JsonSlurper().parseText(registry.readText()) as Map<String, String>
        val sb = StringBuilder()
        sb.appendLine("package cn.boxiaolanya.tools.utils.shell")
        sb.appendLine()
        sb.appendLine("import cn.boxiaolanya.tools.utils.ShellCipher")
        sb.appendLine()
        sb.appendLine("internal object ShellObfTable {")
        sb.appendLine("    private val encoded: Map<String, String> = mapOf(")
        json.entries.sortedBy { it.key }.forEach { (key, value) ->
            val enc = encodeShellLiteral(value, shellXorKey)
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
            sb.appendLine("        \"$key\" to \"$enc\",")
        }
        sb.appendLine("    )")
        sb.appendLine()
        sb.appendLine("    fun get(key: String): String =")
        sb.appendLine("        encoded[key]?.let(ShellCipher::unwrap) ?: error(\"Unknown shell key: \" + key)")
        sb.appendLine("}")
        val target = outFile.get().asFile
        target.parentFile.mkdirs()
        target.writeText(sb.toString())
    }
}

android {
    namespace = "cn.boxiaolanya.tools"
    compileSdk = 36

    defaultConfig {
        applicationId = "cn.boxiaolanya.tools"
        minSdk = 31
        targetSdk = 36
        versionCode = 11
        versionName = "11.0.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("int", "SHELL_XOR_KEY", shellXorKey.toString())
        buildConfigField("boolean", "SHELL_OBFUSCATE", "true")
    }

    signingConfigs {
        create("release") {
            storeFile = rootProject.file("tool123.jks")
            storePassword = "tool123"
            keyAlias = "tool123"
            keyPassword = "tool123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("release")
        }
        release {
            isMinifyEnabled = true
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

    kotlin {
        jvmToolchain(21)
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    sourceSets {
        getByName("main") {
            kotlin.srcDir(shellGeneratedDir)
        }
    }
}

tasks.named("preBuild") {
    dependsOn("generateShellObf")
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.process)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.dev.rikka.shizuku.api)
    implementation(libs.dev.rikka.shizuku.provider)
    implementation(libs.squareup.okhttp)
    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.m3color)
    implementation(platform(libs.koin.bom))
    implementation(libs.koin.core)
    implementation(libs.koin.android)
    implementation(libs.koin.compose)
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.palette)
    implementation(libs.hiddenapibypass)
    implementation(libs.org.commonmark)
    implementation(libs.org.commonmark.ext.gfm.tables)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    debugImplementation(libs.androidx.compose.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}
