# 悦玺工具箱 YueXi-Tools

> **项目状态：开源**  
> 作者 [柏小澜呀](https://github.com/boxiaolanya2008) 已宣布暂别 Android 开发（详见[告别宣言](告别宣言.txt)）。  
> 本仓库仅作为学习与研究的**历史快照**保留，**不再接受功能迭代**。  
> 欢迎 Fork 与二次开发，但请勿用于商业分发（签名密钥与作者原意均已公开）。  
> 修改与分发须遵守 [悦玺署名许可证](LICENSE)，**未携带原开发者署名即视为版权侵权**。

| | |
|---|---|
| 包名 | `cn.boxiaolanya.tools` |
| 当前版本 | **11.0.0**（versionCode 11） |
| 系统要求 | Android 12+（API 31），目标 SDK 36 |
| 语言 / 构建 | Kotlin 2.0.21 / JDK 21 / AGP 8.13.2 / Gradle Wrapper |
| UI 框架 | Jetpack Compose + Material 3 |
| 高权限来源 | [Shizuku](https://shizuku.rikka.app/) 13.1.5 + `WRITE_SECURE_SETTINGS` |
| 目标平台 | **vivo / iQOO**（依赖厂商私有接口） |
| 许可证 | [悦玺署名许可证 v1.0](LICENSE)（自制；强制署名，详见 LICENSE 第 3、5 条） |

---

## 项目简介

悦玺工具箱是一款**面向 vivo / iQOO 设备的 Android 系统调优工具**。它通过 [Shizuku](https://shizuku.rikka.app/) 获得 shell 级权限，在**无需 Root** 的前提下调用厂商隐藏能力：

- 系统隐藏 `settings` 读写
- GameWatch 游戏加速广播与 Binder IPC
- 智慧引擎（ABE）功耗与云控管理
- PEM 插件引擎 / 电量摘要
- VIVO-RMS reason 调度
- 超分辨率 / 帧插 / 沉浸音频等显示与音频能力

> **风险提示**：修改系统设置、写入 `secure` 键、向系统进程发送私有广播，可能导致系统不稳定、异常耗电、失去保修，**使用前请评估风险并备份数据**（详见[免责声明](#免责声明)）。

---

## 核心特色

### 1. 构建期 Shell 命令加密

`app/shell/registry.json` 中的 75 条命令模板，在 Gradle 预编译阶段（`generateShellObf` Task）被加密为密文字面量写入生成的 `ShellObfTable.kt`：

```
registry.json (明文) ──[XOR + Base64]──► 生成的 .kt (密文)
                                          │
                            运行时 ShellCipher.unwrap()
                                          │
                              ShellObf.s("token.sh")  ──► "sh"
```

- 密钥通过 `BuildConfig.SHELL_XOR_KEY` 注入；
- 字节级 `xor (key shift) xor (i*31+seed)`，配合 `\uE001` 标识前缀；
- 配合 R8 压缩后，反编译者无法直接看到 `dumpsys activity broadcast` 模板原文。

### 2. GameWatch Binder 协议逆向

`utils/GameWatchBinder.kt` 实现了对 vivo `gamewatch_server` 服务 25 个 executor 的完整调用：

| | | |
|---|---|---|
| 协议入口 | `ServiceManager.getService("gamewatch_server")` | 通过 `HiddenApiBypass` 豁免 |
| 调用方式 | `transact(code=5, data, reply, 0)` | 即 `IGameWatch.execute` |
| 参数打包 | 写 `typeArray` 字节数组 + 各参数 Parcel | 完整支持 15 种类型 |
| 文档 | `assets/GameWatch-Binder.md` | 569 行含「废参数速查表」 |

25 个 executor 元数据驱动 UI 表单生成，可在 `GameWatchBinderIpcScreen` 中直接调用。

### 3. 厂商隐藏 API 全面覆盖

- `VivoPerfManager`：Monster 模式、省电类型
- `VivoEventService`：vivo 事件服务
- `SettingsContentAccess` / `SecureSettingsAccess` / `SettingsResolverAccess`：三种 settings 写入路径
- `GameCubeManager`：超分 / 帧插生态
- `ImmersiveAudioController`：沉浸音频

### 4. 可选前台保活 + QS 磁贴

- `KeepAliveService`：低优先级通知 + WakeLock 心跳（DataStore 可关）
- `GpuSwapTileService`：快捷设置磁贴，一键 GPU 交换
- `GlobalPowerSaveService` / `VivoRmsMonitorService`：RMS 后台轮询

### 5. 冲突包检测与强制更新

- 与 `com.viqitos.tools` / `com.viqitos.tool` 不可共存（启动拦截）
- 启动时拉取 Gitee 上的 `update.json`，支持强制更新拦截

---

## 功能列表

功能按应用首页分类排列；带「子页」的入口在应用内还有二级菜单。

### 系统优化

| 功能 | 说明 |
|------|------|
| 系统设置 | 读写隐藏 `settings`（系统更新提示、AI 加速、ART、刷新率匹配、Native Flags 等） |
| Shell 终端 | 自定义执行 Shell，内置常用命令预设 |

### 性能调度

| 功能 | 说明 |
|------|------|
| GameWatch | 游戏加速套件（7 个子项，见下表） |
| 智慧引擎 | 功耗管控、ABE 总开关、配置刷新、线程上报、用户上报、云控触发（6 个子项） |
| 高温保护 | 电源/高温保护相关广播 |

**GameWatch 子功能**

| 子功能 | 说明 |
|--------|------|
| 场景切换 | 切换应用游戏场景 |
| 配置切换 | GPU / 游戏配置方案切换 |
| 画质通知 | 向目标进程发送画质广播 |
| 目标帧率 | 设置目标 FPS（需有效 PID） |
| 配置更新 | 强制刷新 GameWatch 配置 |
| Binder IPC | 经 `gamewatch_server` 调用内部 executor（25 个） |
| 教程 | 内置 Markdown 参数填表说明 |

**智慧引擎子功能**

| 子功能 | 说明 |
|--------|------|
| 功耗管控 | 限制指定应用高耗电 |
| ABE 总开关 | 智慧引擎全局开关 |
| 配置更新 | 强制刷新全部配置项 |
| 线程异常上报 | 获取线程并上报异常 |
| 用户上报 | 用户 kill 相关广播 |
| 云控触发 | 从云端拉取最新配置 |

### VIVO-RMS

读写 `secure` 键 `vivo_rms_active_request_reason`，按包名与 Reason 参数构造调度字符串；支持前台服务轮询、历史采样与 burst 验证。详见 `app/.../rms/` 模块：

- `VivoRmsReasonBuilder` / `VivoRmsReasonParser` / `VivoRmsRepository` / `VivoRmsRuntime`

### 电池与电源

| 功能 | 说明 |
|------|------|
| 电量守护 | 缓解系统更新后异常耗电 |
| 恢复耗电 | 电量守护相关恢复操作 |
| PEM · 系统升级优化 | 系统升级优化检查广播 |
| PEM · 云端数据采集 | 云端数据采集 |
| PEM · 温度状态 | 插件引擎温度状态变更 |
| 电量摘要配置 | 编辑 `fuelsummary_uc.xml` 数值槽位并导出 |

### 显示与图形

| 功能 | 说明 |
|------|------|
| 超分辨率 | 超分主设置 |
| 帧插模式 | GameCube 生态帧插相关设置 |

### 网络与云控

| 功能 | 说明 |
|------|------|
| 云控控制 | 移除 / 停止 vivo 云控相关能力 |

### 音频

| 功能 | 说明 |
|------|------|
| 音效增强 | 标准 Audio API，不依赖 Shizuku |
| 沉浸音频 | Immersive Audio 相关设置 |

### 高级调试

| 功能 | 说明 |
|------|------|
| Activity 管理 | Activity 栈与组件操作 |
| 服务控制 | 启停系统服务 |
| 进程管理 | 查看与结束进程 |
| 性能调度 | VivoPerfManager（Monster 模式、省电类型等） |
| 网络策略 | 数据节省与网络限制 |
| Doze 白名单 | 电池优化白名单 |
| 事件监听 | vivo 事件服务 |
| 崩溃模拟 | 用于测试的崩溃触发 |
| SurfaceFlinger | 帧缓冲与合成器调试 |
| Activity 服务 | Activity 服务控制 |

### 系统能力

- Shizuku 授权引导；授权后自动尝试授予 `WRITE_SECURE_SETTINGS`
- 远程版本检查（`update.json`，支持强制更新拦截）
- 可选前台保活（`KeepAliveService`，DataStore 可关）
- 快捷设置磁贴：GPU 交换（`GpuSwapTileService`）
- 冲突包检测：与 `com.viqitos.tools` / `com.viqitos.tool` 不可共存
- 未捕获异常日志（`CrashHandler`）

---

## 使用前准备

1. **机型**：vivo 或 iQOO，Android 12 及以上。
2. **Shizuku**：安装并启动服务（无线调试或 Root 配对均可），在本应用中授予权限。
3. **目标进程**：GameWatch 帧率、画质等能力需要目标应用**正在运行**；界面会通过 `pidof` 解析 PID，无有效 PID 时不发送广播。部分超分/帧插命令仅需包名。
4. **WRITE_SECURE_SETTINGS**：首次启动时应用会尝试通过 Shizuku 自动 `pm grant`；如失败，请在 Shizuku 主应用中手动授权。

---

## 从源码构建

**环境要求**

- JDK 21（推荐 Android Studio 自带 JBR）
- Android SDK 36 / Build-Tools
- Gradle Wrapper（仓库已包含）

> Windows 用户可在 `gradle.properties` 中将 `org.gradle.java.home` 指向 Studio 自带 JBR：
> `C:/Program Files/Android/Android Studio/jbr`

**构建命令**

```bash
# Debug
gradlew.bat assembleDebug        # Windows
./gradlew assembleDebug          # macOS / Linux

# Release（已启用 R8 压缩）
gradlew.bat assembleRelease
```

**APK 输出目录**：`app/build/outputs/apk/`

**签名说明**：仓库内含示例 keystore（`tool123.jks`）仅供本地调试。**对外发布请使用自有签名，不要把密钥提交到公开仓库。**

---

## 项目结构

```
YueXi-Tools/
├── app/
│   ├── build.gradle.kts          # 含 generateShellObf 任务（构建期 Shell 加密）
│   ├── shell/
│   │   └── registry.json         # 75 条命令模板源数据
│   ├── proguard-rules.pro        # 仅保留 ShellCipher / ShellObfTable 入口
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── assets/
│       │   │   ├── GameWatch-Binder.md
│       │   │   ├── fuelsummary_uc.xml
│       │   │   ├── vivo_rms_active_request_reason.md
│       │   │   ├── fengqinglianyin.jpg
│       │   │   └── yingying.jpg
│       │   ├── res/              # xml(backup/network_security_config)、mipmap、values
│       │   └── java/cn/boxiaolanya/tools/
│       │       ├── App.kt                # Application 入口、保活、Hidden API 豁免
│       │       ├── MainActivity.kt       # 单 Activity + NavHost
│       │       ├── audio/                # 3 文件：AudioController / ImmersiveAudio / Preferences
│       │       ├── fuel/                 # 2 文件：fuelsummary_uc.xml 编解码
│       │       ├── rms/                  # 4 文件：VIVO-RMS 读写解析
│       │       ├── service/              # 4 文件：保活 / RMS 监控 / QS 磁贴
│       │       ├── ui/
│       │       │   ├── pages/            # HomeScreen + Screen 路由 + tools/ (47 Screen) + welcome/
│       │       │   ├── settings/         # DataStore 封装
│       │       │   ├── theme/            # Material 3 主题
│       │       │   ├── widgets/setting/  # 通用设置组件
│       │       │   └── MainViewModel.kt
│       │       └── utils/
│       │           ├── ShizukuExec.kt        # 核心 Shell 执行入口
│       │           ├── ShizukuHelper.kt      # Binder 状态探测
│       │           ├── ShellCipher.kt        # 命令加密/解密
│       │           ├── GameWatchBinder.kt    # 25 executor Binder 协议
│       │           ├── GameCubeManager.kt
│       │           ├── VivoPerfManager.kt    # 反射调用厂商 API
│       │           ├── VivoEventService.kt
│       │           ├── UpdateChecker.kt
│       │           ├── CrashHandler.kt
│       │           ├── NotificationHelper.kt
│       │           ├── PackageChecker.kt
│       │           ├── Settings*Access.kt    # settings 写入三路径
│       │           ├── SettingsPermissionBootstrap.kt
│       │           ├── AbeDiagnostics.kt
│       │           └── shell/                # 16 个按领域拆分的命令模块
│       │               ├── ShellObf.kt / ShellFormat.kt / ProcQueries.kt
│       │               ├── GameWatchCommands.kt
│       │               ├── SmartEngineCommands.kt
│       │               ├── SettingsOptimizerCommands.kt
│       │               ├── VivoRmsCommands.kt
│       │               ├── VivoPerfCommands.kt
│       │               ├── PemCommands.kt / PemrCommands.kt
│       │               ├── BatteryGuardCommands.kt
│       │               ├── HighProtectCommands.kt
│       │               ├── ActivityCommands.kt
│       │               ├── ServiceControlCommands.kt
│       │               ├── NetworkPolicyCommands.kt
│       │               ├── DeviceIdleCommands.kt
│       │               └── CommandTerminalPresets.kt
│       ├── test/    （仅默认 ExampleUnitTest）
│       └── androidTest/ （仅默认 ExampleInstrumentedTest）
├── gradle/
│   ├── libs.versions.toml        # 版本目录
│   └── wrapper/
├── build.gradle.kts              # 根项目配置
├── settings.gradle.kts
├── gradle.properties             # 锁定 JBR
├── tool123.jks                   # 示例签名（已公开，慎用）
├── update.json                   # 远程更新元数据
├── 告别宣言.txt                  
└── README.md
```

### `utils/shell/` 命令模块一览

| 模块 | 职责 |
|------|------|
| `ShellObf` / `ShellTokens` | 运行时解密入口（`s("key")`） |
| `ShellFormat` | 命令模板占位符替换 |
| `ProcQueries` | `pidof` 等进程查询 |
| `CommandTerminalPresets` | Shell 终端常用命令预设 |
| `GameWatchCommands` | 场景/画质/帧率/配置更新广播 |
| `SmartEngineCommands` | ABE 功耗 / 配置刷新 / 线程上报 / 用户 kill |
| `SettingsOptimizerCommands` | 隐藏 `settings` 读写 |
| `VivoRmsCommands` | RMS reason 调度 |
| `VivoPerfCommands` | Monster 模式 / 省电类型 |
| `PemCommands` / `PemrCommands` | PEM 插件引擎 |
| `BatteryGuardCommands` | 电量守护与恢复 |
| `HighProtectCommands` | 高温保护 |
| `ActivityCommands` | Activity 栈与组件操作 |
| `ServiceControlCommands` | 系统服务启停 |
| `NetworkPolicyCommands` | 网络策略与数据节省 |
| `DeviceIdleCommands` | Doze 白名单 |

---

## 技术选型

| 层级 | 选型 |
|------|------|
| UI | Jetpack Compose、Material 3、Navigation Compose |
| 高权限执行 | Shizuku 13.1.5，反射 `Shizuku.newProcess` |
| Binder | `GameWatchBinder` + `HiddenApiBypass` |
| 异步 | Kotlin Coroutines（含 `Dispatchers.IO` / `SupervisorJob`） |
| 配置 | DataStore Preferences |
| DI | Koin（已声明依赖，按需使用） |
| 网络 | OkHttp 4.12 |
| Markdown | CommonMark + GFM Tables |
| 更新 | OkHttp + 远程 JSON |

**架构总览**

- 单 `Activity` + 多路由 Compose 页（Navigation Compose）
- 业务页 → `ShizukuExec` 或 `utils/shell/*Commands.kt`
- VIVO-RMS 与电量摘要具备独立的解析/持久化模块（`rms/`、`fuel/`）
- 前台服务（保活 / RMS 监控 / 省电）与 UI 解耦，仅通过 DataStore 共享配置

---

## 应用更新

启动时会请求 Gitee 上的 `update.json`（见 `UpdateChecker.kt`）。当远程 `versionCode` 大于当前安装版本时弹出更新提示；`forceUpdate` 为 `true` 时不可跳过。

发布新版本时请同步更新：
- 仓库根目录 `update.json`
- `app/build.gradle.kts` 中的 `versionCode` / `versionName`

当前 `update.json` 示例：

```json
{
  "versionCode": 11,
  "versionName": "11.0.0",
  "forceUpdate": true,
  "title": "发现新版本",
  "message": "自己去QQ群下载。",
  "url": "QQ群",
  "md5": "a1b2c3d4e5f678901234567890123456"
}
```

---

## 常见问题

**提示「进程未运行或包名不正确」**  
确认包名完整（如 `com.tencent.tmgp.sgame`），且游戏已在后台或前台运行。部分 ROM 上 `pidof` 对包名的匹配行为不一致。

**Shizuku 未连接**  
在 Shizuku 主应用中确认服务已启动，返回本应用重新授权。

**无法启动，提示冲突应用**  
卸载 `com.viqitos.tools` 或 `com.viqitos.tool` 后重试。

**RMS 写入无效**  
确认已通过 Shizuku 完成授权，且 `WRITE_SECURE_SETTINGS` 已授予（首次授权后会自动 bootstrap）。

**`fuelsummary_uc.xml` 解析失败**  
确认 XML 结构未被修改；可使用应用内「恢复默认」功能复位。

**Fork 后能否改包名、换 logo、重新发布？**  
**可以**。但必须同时满足以下全部条件（详见 [LICENSE](LICENSE) 第 3.1-3.4 条）：

- 在源码、二进制包「关于」页、商店描述等**用户可主动查看的位置**完整保留原开发者署名；
- 不得使用与原项目相同或高度近似的名称（如 `YueXi-Tools` / `悦玺工具箱`）；如确需沿用，须额外标注「非官方修改版」字样；
- 不得暗示派生作品由原开发者官方发布、认可或赞助；
- 修改过的文件须以显著方式标注修改内容与修改日期。

**仅去除署名、换皮后独立发布 → 视为侵权**，原开发者保留追责权利。

---

## 致谢与背景

本项目由 [柏小澜呀](https://github.com/boxiaolanya2008)（开发者昵称「风情恋吟」）维护两年。软件历经三代：Viqitos → Viqitos-Tools → YueXi-Tools，每一代都刻着作者的成长。

2026 年，作者宣布暂别 Android 开发，转向更广义的计算机领域；源码以宽松协议开源，欢迎大家延续它的生命。

**开发**：柏小澜呀（`boxiaolanya2008`）  

> 小心官方！！（作者原话）

---

## 免责声明

本项目仅供学习与技术研究。修改系统设置、写入 secure 键、发送厂商广播可能导致系统不稳定、耗电异常或影响保修。**使用前请自行评估风险并备份重要数据**；作者不对使用本工具造成的任何损失负责。

---

## 许可证

本项目采用**自制「悦玺署名许可证 v1.0」**（`LICENSE`）。要点：

- 允许复制、修改、fork、分发（含二改）；
- 分发时**必须**完整保留「原开发者署名」（含原开发者姓名、原项目名、原仓库地址、许可证链接）；
- 二进制包、应用商店描述、About 页均需可见署名；
- 移除或修改署名后分发，**构成版权侵权**，原开发者保留追责权利；
- 严禁用于违法活动、隐私窃取、恶意软件分发等。

详细条款见 [LICENSE](LICENSE)。
